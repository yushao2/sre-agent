# AI SRE Agent

AI-powered SRE agent for incident management and support triage.

## Features

- **Custom LLM Integration**: Skeleton for any model server (OpenAI-compatible, vLLM, TGI, Ollama)
- **MCP Servers**: Read-only integrations for Jira DC, Confluence DC, GitLab (self-hosted)
- **RAG**: ChromaDB-based similarity search for incidents and runbooks
- **Async Processing**: Celery workers for background LLM operations
- **Kubernetes Ready**: Helm chart with MCP sidecar pattern

## Quick Start

### Prerequisites

- Python 3.11+
- [UV](https://docs.astral.sh/uv/) package manager
- Your LLM server URL and API key

### Installation

```bash
# Install UV (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Clone and setup
git clone https://github.com/your-org/ai-sre-agent.git
cd ai-sre-agent

# Install dependencies
uv sync                    # Minimal install
uv sync --all-extras       # All features

# Configure
cp .env.example .env
# Edit .env with your LLM server URL
```

### Configuration

```bash
# Required: Your LLM server
export LLM_BASE_URL=https://your-model-server.com
export LLM_API_KEY=your-api-key

# Optional: External integrations
export JIRA_URL=https://jira.company.com
export JIRA_USERNAME=your-username
export JIRA_TOKEN=your-token
```

### Customize LLM Integration

Edit `src/agent/llm_custom.py` - look for `>>> CUSTOMIZE` markers:

```python
# 5 methods to customize:
# 1. _get_endpoint()      - API URL path
# 2. _get_headers()       - Authentication headers
# 3. _convert_messages()  - Message format
# 4. _build_request_body() - Request JSON structure
# 5. _parse_response()    - Extract generated text
```

Test your configuration:
```bash
uv run python -m agent.llm_custom
```

### Run Locally

```bash
# Interactive chat
uv run sre-agent interactive

# Summarize an incident
uv run sre-agent summarize --key INC-123 --summary "DB connection pool exhausted"

# Run demo with sample data
uv run sre-agent demo
```

## Architecture

### Local Development (stdio)

```
┌─────────────────┐     ┌─────────────────┐
│  SRE Agent CLI  │────▶│  Your LLM       │
│                 │     │  Server         │
└─────────────────┘     └─────────────────┘
        │
        │ subprocess (stdio)
        ▼
┌─────────────────┐
│  MCP Servers    │───▶ Jira / Confluence / GitLab
└─────────────────┘
```

### Kubernetes (Unix Socket Sidecar)

```
┌─────────────────────────────────────────────────────────────────┐
│                         Kubernetes Pod                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────┐     Unix Socket      ┌──────────────────┐ │
│  │   API Server     │   /sockets/jira.sock │  Sidecar: Jira   │ │
│  │   (FastAPI)      │◄───────────────────►│  MCP Server      │ │
│  │                  │   /sockets/conf.sock │                  │ │
│  │                  │◄───────────────────►│  Sidecar: Conf   │ │
│  │                  │   /sockets/gl.sock   │                  │ │
│  │                  │◄───────────────────►│  Sidecar: GitLab │ │
│  └──────────────────┘                      └──────────────────┘ │
│                                                                  │
│           emptyDir volume: /sockets                              │
└─────────────────────────────────────────────────────────────────┘
```

This architecture keeps MCP's native stdio protocol without building a custom HTTP transport.

See [docs/MCP_STDIO_KUBERNETES.md](docs/MCP_STDIO_KUBERNETES.md) for details.

## Project Structure

```
ai-sre-agent/
├── src/
│   ├── agent/                 # Core agent module
│   │   ├── llm_custom.py      # ⭐ CUSTOMIZE THIS
│   │   ├── agent.py           # Main agent class
│   │   ├── mcp_client.py      # MCP client (socket/subprocess)
│   │   ├── rag.py             # ChromaDB RAG
│   │   ├── server.py          # FastAPI production server
│   │   ├── tasks.py           # Celery workers
│   │   └── local.py           # CLI for local dev
│   │
│   └── mcp_servers/           # MCP servers (all read-only)
│       ├── socket_bridge.py   # Unix socket wrapper
│       ├── jira/              # Jira Data Center
│       ├── confluence/        # Confluence Data Center
│       └── gitlab/            # GitLab self-hosted
│
├── helm/                      # Kubernetes deployment
│   └── ai-sre-agent/
│       ├── values.yaml        # Configuration
│       └── templates/         # K8s manifests (with sidecars)
│
├── docs/                      # Documentation
│   └── MCP_STDIO_KUBERNETES.md
│
├── examples/                  # Usage examples
└── tests/                     # Test suite
```

## MCP Servers

All MCP servers are **read-only** by design.

| Server | Tools |
|--------|-------|
| Jira | `search_issues`, `get_issue`, `get_issue_comments`, `list_projects` |
| Confluence | `search_pages`, `get_page`, `get_page_by_title`, `list_spaces` |
| GitLab | `list_projects`, `get_project`, `list_merge_requests`, `get_merge_request`, `list_pipelines`, `get_file_content` |

### Run MCP Servers Locally

```bash
# Stdio mode (local development)
uv run mcp-jira

# Socket mode (for testing K8s setup)
uv run mcp-jira --socket /tmp/jira.sock
```

## Production Deployment

### Docker Compose

```bash
cp .env.example .env
# Edit .env with your configuration

docker-compose up -d
```

### Kubernetes with Helm

```bash
# Add Bitnami repo for subcharts
helm repo add bitnami https://charts.bitnami.com/bitnami

# Create namespace and secrets
kubectl create namespace ai-sre-agent
kubectl create secret generic ai-sre-agent-secrets \
  --namespace ai-sre-agent \
  --from-literal=LLM_BASE_URL=https://your-llm.com \
  --from-literal=LLM_API_KEY=your-key \
  --from-literal=JIRA_URL=https://jira.company.com \
  --from-literal=JIRA_USERNAME=user \
  --from-literal=JIRA_TOKEN=token

# Install
helm install ai-sre-agent ./helm/ai-sre-agent \
  --namespace ai-sre-agent \
  --set secrets.existingSecret=ai-sre-agent-secrets
```

## Development

```bash
# Install with dev dependencies
uv sync --all-extras

# Run tests
uv run pytest

# Run tests with coverage
uv run pytest --cov=agent

# Type checking
uv run mypy src/

# Linting
uv run ruff check src/

# Format code
uv run ruff format src/
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `LLM_BASE_URL` | Yes | Your model server URL |
| `LLM_API_KEY` | Maybe | API key (depends on your server) |
| `MODEL_NAME` | No | Model identifier |
| `JIRA_URL` | No | Jira Data Center URL |
| `JIRA_USERNAME` | No | Jira username |
| `JIRA_TOKEN` | No | Jira Personal Access Token |
| `CONFLUENCE_URL` | No | Confluence Data Center URL |
| `CONFLUENCE_USERNAME` | No | Confluence username |
| `CONFLUENCE_TOKEN` | No | Confluence PAT |
| `GITLAB_URL` | No | GitLab instance URL |
| `GITLAB_TOKEN` | No | GitLab PAT (read_api scope) |
| `REDIS_URL` | No | Redis for Celery broker |
| `DATABASE_URL` | No | PostgreSQL for persistence |
| `MCP_JIRA_SOCKET` | No | Unix socket path (K8s) |
| `MCP_CONFLUENCE_SOCKET` | No | Unix socket path (K8s) |
| `MCP_GITLAB_SOCKET` | No | Unix socket path (K8s) |

## License

MIT
