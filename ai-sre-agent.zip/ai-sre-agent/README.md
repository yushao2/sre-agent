# AI SRE Agent

An **agentic** AI assistant for Site Reliability Engineering that can autonomously search Jira, Confluence, and GitLab to investigate incidents.

## Features

- **Agentic Tool Use**: LLM automatically decides when to query Jira, Confluence, GitLab
- **RAG**: Searches past incidents and runbooks for context
- **Flexible Input**: Works with structured data or raw text pastes
- **Local First**: Runs locally without external services (except your LLM)

## Quick Start (Local Development)

```bash
# 1. Install with all features
uv sync --all-extras

# 2. Configure LLM (required)
export LLM_BASE_URL=https://your-llm-server.com/v1
export LLM_API_KEY=your-key

# 3. Configure RAG storage (optional, defaults to ~/.local/share/ai-sre-agent/)
export SRE_AGENT_DATA_DIR=./data

# 4. Configure external tools (optional - agent works without them)
export JIRA_URL=https://jira.company.com
export JIRA_USERNAME=you
export JIRA_TOKEN=your-personal-access-token

export CONFLUENCE_URL=https://confluence.company.com
export CONFLUENCE_USERNAME=you
export CONFLUENCE_TOKEN=your-personal-access-token

export GITLAB_URL=https://gitlab.company.com
export GITLAB_TOKEN=your-personal-access-token

# 5. Run the server
uv run python -m agent.server

# 6. Test it!
curl -X POST http://localhost:8000/api/v1/triage \
  -H "Content-Type: application/json" \
  -d '{"content": "Our API is returning 500 errors! Started 10 mins ago."}'
```

## How It Works

### Architecture

```
User Request
     ↓
┌─────────────────────────────────────────────────────────────────┐
│                         SRE Agent                                │
│                                                                  │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────┐ │
│  │   LLM       │───►│ Tool Router │───►│ MCP Servers         │ │
│  │             │◄───│             │◄───│ (Jira/Conf/GitLab)  │ │
│  └─────────────┘    └─────────────┘    └─────────────────────┘ │
│         │                                        ▲              │
│         │           ┌─────────────┐              │              │
│         └──────────►│     RAG     │──────────────┘              │
│                     │ (ChromaDB)  │                             │
│                     └─────────────┘                             │
└─────────────────────────────────────────────────────────────────┘
```

### What Happens When You Make a Request

1. **You send a request** (e.g., "Investigate INC-123")
2. **Agent sends to LLM** with available tools listed
3. **LLM decides** which tools to call (e.g., "search_jira", "search_similar_incidents")
4. **Agent executes tools**:
   - MCP tools → Spawns subprocess for Jira/Confluence/GitLab
   - RAG tools → Searches local ChromaDB
5. **Results returned to LLM** for analysis
6. **Loop continues** until LLM has enough info
7. **Final response** returned to you

### What's Automatic vs Manual

| Feature | Automatic? | Notes |
|---------|-----------|-------|
| RAG (similar incidents) | ✅ Yes | If `chromadb` installed |
| MCP (Jira/Confluence/GitLab) | ✅ Yes | If env vars configured |
| Tool calling | ✅ Yes | LLM decides when to use tools |
| MCP server startup | ✅ Yes | Spawned as subprocess when needed |

## API Endpoints

### POST /api/v1/triage
Triage incoming requests from any source (Teams, Slack, tickets, etc.)

```bash
# Raw text
curl -X POST http://localhost:8000/api/v1/triage \
  -H "Content-Type: application/json" \
  -d '{"content": "@SRE-Support our API is down!"}'

# Structured
curl -X POST http://localhost:8000/api/v1/triage \
  -H "Content-Type: application/json" \
  -d '{"key": "SUP-123", "summary": "API errors", "source": "teams"}'
```

### POST /api/v1/summarize
Summarize an incident

```bash
curl -X POST http://localhost:8000/api/v1/summarize \
  -H "Content-Type: application/json" \
  -d '{"key": "INC-123", "summary": "DB connection timeout"}'
```

### POST /api/v1/rca
Root cause analysis

```bash
curl -X POST http://localhost:8000/api/v1/rca \
  -H "Content-Type: application/json" \
  -d '{"content": "Production outage on Jan 15..."}'
```

### POST /api/v1/chat
Free-form chat with tool access

```bash
curl -X POST http://localhost:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What causes connection pool exhaustion?"}'
```

## Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `LLM_BASE_URL` | Yes | Your LLM server URL |
| `LLM_API_KEY` | Maybe | API key (if required) |
| `MODEL_NAME` | No | Model identifier |
| `SRE_AGENT_DATA_DIR` | No | RAG data directory (default: ~/.local/share/ai-sre-agent/) |
| `RAG_ENABLED` | No | Set to "false" to disable RAG |
| `JIRA_URL` | No | Jira Data Center URL |
| `JIRA_USERNAME` | No | Jira username |
| `JIRA_TOKEN` | No | Jira personal access token |
| `CONFLUENCE_URL` | No | Confluence URL |
| `CONFLUENCE_USERNAME` | No | Confluence username |
| `CONFLUENCE_TOKEN` | No | Confluence token |
| `GITLAB_URL` | No | GitLab URL |
| `GITLAB_TOKEN` | No | GitLab token (needs `read_api` scope) |

### RAG Data Storage

RAG data is stored in files on disk:
```
~/.local/share/ai-sre-agent/
├── incidents/     # ChromaDB for past incidents
└── runbooks/      # ChromaDB for runbook chunks
```

Override with `SRE_AGENT_DATA_DIR`:
```bash
export SRE_AGENT_DATA_DIR=/path/to/my/data
```

### Customizing the LLM

The LLM integration is in `src/agent/llm_custom.py`. You **must** customize this for your LLM server:

```python
# Edit these 5 methods in llm_custom.py:

def _get_endpoint(self) -> str:
    """Return your API endpoint"""
    return f"{self.base_url}/v1/chat/completions"

def _get_headers(self) -> Dict[str, str]:
    """Return your auth headers"""
    return {"Authorization": f"Bearer {self.api_key}"}

def _convert_messages(self, messages):
    """Convert LangChain messages to your format"""
    ...

def _build_request_body(self, messages, tools, stop):
    """Build the request payload"""
    ...

def _parse_response(self, response_json):
    """Parse your API's response"""
    ...
```

## Project Structure

```
ai-sre-agent/
├── src/
│   ├── agent/
│   │   ├── agent.py         # Main agentic agent with tool calling
│   │   ├── server.py        # FastAPI server
│   │   ├── llm_custom.py    # LLM integration (customize this!)
│   │   ├── mcp_client.py    # MCP client (auto-spawns servers)
│   │   ├── rag.py           # RAG with ChromaDB
│   │   ├── prompts.py       # System prompts
│   │   └── local.py         # CLI for local development
│   └── mcp_servers/
│       ├── jira/            # Jira MCP server
│       ├── confluence/      # Confluence MCP server
│       └── gitlab/          # GitLab MCP server
├── helm/                    # Kubernetes deployment
├── examples/                # Example usage
└── tests/                   # Tests
```

## MCP Servers

MCP (Model Context Protocol) servers provide read-only access to external systems.

### Local Development
Servers are spawned as **subprocesses** automatically:
```
Agent → subprocess: mcp-jira → Jira API
```

### Kubernetes
Servers run as **sidecars** communicating via Unix sockets:
```
Agent → /sockets/jira.sock → Sidecar Container → Jira API
```

See [docs/MCP_STDIO_KUBERNETES.md](docs/MCP_STDIO_KUBERNETES.md) for K8s architecture.

## Testing Without External Services

The agent works without Jira/Confluence/GitLab - it will just skip those tools:

```bash
# Minimal setup - LLM + RAG only
export LLM_BASE_URL=https://your-llm.com
uv run python -m agent.server

# The agent will:
# - Use RAG to search similar incidents (starts empty)
# - Skip Jira/Confluence/GitLab tools (not configured)
# - Still provide analysis based on your input
```

## Adding Past Incidents to RAG

```python
from agent import IncidentKnowledgeBase

kb = IncidentKnowledgeBase(persist_directory="./data/incidents")

# Add incidents
kb.add_incident({
    "key": "INC-100",
    "summary": "Database connection pool exhausted",
    "root_cause": "Connection leak in reporting service",
    "resolution": "Fixed connection leak, added monitoring",
})

# Now the agent will find this when investigating similar issues
```

## Development

```bash
# Install dev dependencies
uv sync --all-extras

# Run tests
uv run pytest

# Run server in debug mode
DEBUG=true uv run python -m agent.server

# Interactive CLI
uv run python -m agent.local interactive
```

## License

MIT
