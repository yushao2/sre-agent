# AI SRE Agent

Production-ready AI agent for incident management and support triage.

## Overview

This project provides an AI-powered SRE (Site Reliability Engineering) agent that can:

- **Summarize Incidents**: Generate structured summaries with timeline, root cause, and recommendations
- **Triage Tickets**: Categorize and prioritize support tickets automatically  
- **Root Cause Analysis**: Deep-dive analysis with contributing factors and fixes
- **Interactive Chat**: Ask SRE-related questions and get expert guidance
- **RAG (Retrieval Augmented Generation)**: Store and search past incidents for context

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              AI SRE Agent                               │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────────────┐ │
│  │   CLI       │    │  FastAPI    │    │     Celery Workers          │ │
│  │  (local.py) │    │ (server.py) │    │      (tasks.py)             │ │
│  └──────┬──────┘    └──────┬──────┘    └─────────────┬───────────────┘ │
│         │                  │                         │                  │
│         └──────────────────┴─────────────┬───────────┘                  │
│                                          │                              │
│                                          ▼                              │
│                              ┌───────────────────┐                      │
│                              │   SREAgentSimple  │                      │
│                              │    (agent.py)     │                      │
│                              └─────────┬─────────┘                      │
│                                        │                                │
│                    ┌───────────────────┼───────────────────┐            │
│                    ▼                   ▼                   ▼            │
│           ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │
│           │  Custom LLM    │  │      RAG       │  │   MCP Servers  │   │
│           │ (llm_custom.py)│  │   (rag.py)     │  │ (mcp_servers/) │   │
│           └────────────────┘  └────────────────┘  └────────────────┘   │
│                    │                   │                   │            │
│                    ▼                   ▼                   ▼            │
│           ┌────────────────┐  ┌────────────────┐  ┌────────────────┐   │
│           │ Your Model     │  │   ChromaDB     │  │ Jira/Confluence│   │
│           │ Server         │  │   (Local)      │  │ GitLab         │   │
│           └────────────────┘  └────────────────┘  └────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

### 1. Installation

```bash
# Clone and install
cd ai-sre-agent
pip install -e ".[dev]"

# Or minimal install
pip install -e .
```

### 2. Configuration

```bash
# Copy example environment file
cp .env.example .env

# Edit .env with your settings:
# - LLM_BASE_URL: Your model server URL
# - LLM_API_KEY: Your API key
# - Other integrations as needed
```

### 3. Customize Your LLM Integration

Edit `src/agent/llm_custom.py` to match your model server's API. Search for `>>> CUSTOMIZE` markers.

```bash
# Test your LLM configuration
python -m agent.llm_custom
```

### 4. Run Locally

```bash
# Interactive mode
python -m agent.local interactive

# Single command
python -m agent.local chat "What causes connection pool exhaustion?"

# Run demo with sample incident
python -m agent.local demo
```

## Project Structure

```
ai-sre-agent/
├── README.md                 # This file
├── pyproject.toml            # Python project config & dependencies
├── .env.example              # Environment variable template
│
├── src/
│   ├── agent/                # Core agent package
│   │   ├── README.md         # Agent module documentation
│   │   ├── __init__.py       # Package exports
│   │   ├── agent.py          # SREAgentSimple - main agent class
│   │   ├── llm_custom.py     # Custom LLM wrapper (CUSTOMIZE THIS)
│   │   ├── prompts.py        # System prompts and formatters
│   │   ├── rag.py            # RAG with ChromaDB
│   │   ├── local.py          # CLI and local development
│   │   ├── server.py         # FastAPI production server
│   │   ├── tasks.py          # Celery async tasks
│   │   └── database.py       # SQLAlchemy models
│   │
│   └── mcp_servers/          # MCP server implementations
│       ├── README.md         # MCP documentation
│       ├── jira/             # Jira Data Center (read-only)
│       ├── confluence/       # Confluence Data Center (read-only)
│       └── gitlab/           # GitLab self-hosted (read-only)
│
├── helm/                     # Kubernetes Helm chart
│   └── ai-sre-agent/
│       ├── README.md         # Helm chart documentation
│       ├── Chart.yaml        # Chart metadata
│       ├── values.yaml       # Default values
│       └── templates/        # K8s manifest templates
│
├── docker-compose.yml        # Local development stack
├── Dockerfile                # Multi-stage container build
│
├── examples/                 # Usage examples
│   ├── simple_usage.py
│   └── sample_incident.json
│
└── tests/                    # Test suite
    └── __init__.py
```

## Environment Variables

### Required

| Variable | Description | Example |
|----------|-------------|---------|
| `LLM_BASE_URL` | Your model server URL | `https://llm.company.com` |
| `LLM_API_KEY` | API key for authentication | `sk-...` |

### Optional - Model Configuration

| Variable | Description | Default |
|----------|-------------|---------|
| `MODEL_NAME` | Model identifier | `default-model` |
| `LLM_TIMEOUT` | Request timeout (seconds) | `120` |

### Optional - MCP Servers

| Variable | Description |
|----------|-------------|
| `JIRA_URL` | Jira Data Center URL |
| `JIRA_USERNAME` | Jira username |
| `JIRA_TOKEN` | Jira personal access token |
| `CONFLUENCE_URL` | Confluence Data Center URL |
| `CONFLUENCE_USERNAME` | Confluence username |
| `CONFLUENCE_TOKEN` | Confluence personal access token |
| `GITLAB_URL` | GitLab self-hosted URL |
| `GITLAB_TOKEN` | GitLab personal access token |

### Optional - Production Infrastructure

| Variable | Description |
|----------|-------------|
| `REDIS_URL` | Redis connection URL |
| `DATABASE_URL` | PostgreSQL connection URL |
| `CELERY_BROKER_URL` | Celery broker URL |
| `CELERY_RESULT_BACKEND` | Celery result backend URL |

## Running Modes

### Local Development (stdio)

No external services required. Uses file-based ChromaDB for RAG.

```bash
# Install minimal dependencies
pip install -e .

# Configure LLM
export LLM_BASE_URL=https://your-model-server.com
export LLM_API_KEY=your-key

# Run
python -m agent.local interactive
```

### Production (HTTP)

Full stack with FastAPI, Celery, Redis, PostgreSQL.

```bash
# Install all dependencies
pip install -e ".[all]"

# Start with Docker Compose
docker-compose up -d

# Or deploy to Kubernetes
helm install ai-sre-agent ./helm/ai-sre-agent
```

## MCP Servers

Model Context Protocol (MCP) servers provide read-only access to external systems.

| Server | System | Features |
|--------|--------|----------|
| `mcp-jira` | Jira Data Center | Search issues, get issue details, list comments |
| `mcp-confluence` | Confluence Data Center | Search pages, get page content |
| `mcp-gitlab` | GitLab (self-hosted) | List projects, MRs, pipelines, get file contents |

### Running MCP Servers Locally (stdio)

```bash
# Jira
JIRA_URL=https://jira.company.com \
JIRA_USERNAME=user \
JIRA_TOKEN=token \
python -m mcp_servers.jira.server

# Confluence
CONFLUENCE_URL=https://confluence.company.com \
CONFLUENCE_USERNAME=user \
CONFLUENCE_TOKEN=token \
python -m mcp_servers.confluence.server

# GitLab
GITLAB_URL=https://gitlab.company.com \
GITLAB_TOKEN=token \
python -m mcp_servers.gitlab.server
```

## RAG (Retrieval Augmented Generation)

Store and search past incidents to provide context for new incidents.

```python
from agent import IncidentKnowledgeBase

# Create knowledge base (file-based, no server needed)
kb = IncidentKnowledgeBase(persist_directory="./data/incidents")

# Add past incidents
kb.add_incident({
    "key": "INC-100",
    "summary": "Database connection pool exhausted",
    "root_cause": "Connection leak in reporting service",
    "resolution": "Fixed connection leak, added monitoring",
})

# Search for similar incidents
similar = kb.search("connection timeout errors", k=3)
```

## Customizing the LLM

The agent uses a custom LLM wrapper that you must configure for your model server.

1. Open `src/agent/llm_custom.py`
2. Search for `>>> CUSTOMIZE` comments
3. Modify the 5 key methods:
   - `_get_endpoint()` - Your API URL path
   - `_get_headers()` - Authentication headers
   - `_convert_messages()` - Message format
   - `_build_request_body()` - Request JSON structure
   - `_parse_response()` - Response parsing

See `src/agent/llm_custom.py` for detailed documentation and examples.

## Development

### Running Tests

```bash
pip install -e ".[dev]"
pytest
```

### Code Quality

```bash
# Linting
ruff check src/

# Type checking
mypy src/
```

## License

MIT License - see LICENSE file.
