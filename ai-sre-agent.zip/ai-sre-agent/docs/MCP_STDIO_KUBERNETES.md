# MCP Stdio Architecture for Kubernetes

## Overview

This document describes how to run MCP servers in **stdio mode** within Kubernetes, avoiding the need to design a custom transport layer. The key insight is using Unix sockets combined with the **sidecar pattern**.

## The Problem

MCP's native transport is stdio (stdin/stdout), which works great locally:
```
Agent Process <--stdio--> MCP Server Process
```

But in Kubernetes, we typically want:
- MCP servers as separate deployments (scalability, isolation)
- Network-based communication (load balancing, service discovery)

Building an HTTP transport layer adds complexity and deviates from MCP's design.

## The Solution: Sidecar + Unix Socket Pattern

Instead of network transport, we keep stdio but bridge it through Unix sockets:

```
┌─────────────────────────────────────────────────────────────────┐
│                         Kubernetes Pod                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────┐     Unix Socket      ┌──────────────────┐ │
│  │                  │   /sockets/jira.sock │                  │ │
│  │   Main Container │◄───────────────────►│  Sidecar: Jira   │ │
│  │   (SRE Agent)    │                      │  MCP Server      │ │
│  │                  │   /sockets/conf.sock │                  │ │
│  │                  │◄───────────────────►│  Sidecar: Conf   │ │
│  │                  │                      │                  │ │
│  │                  │   /sockets/gl.sock   │                  │ │
│  │                  │◄───────────────────►│  Sidecar: GitLab │ │
│  └──────────────────┘                      └──────────────────┘ │
│           │                                         │            │
│           │ emptyDir: /sockets                     │            │
│           └─────────────────────────────────────────┘            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ External APIs
                              ▼
            ┌─────────────────────────────────────┐
            │  Jira DC │ Confluence │ GitLab     │
            └─────────────────────────────────────┘
```

## How It Works

### 1. Shared Volume for Sockets

All containers in the pod share an `emptyDir` volume mounted at `/sockets`:

```yaml
volumes:
  - name: mcp-sockets
    emptyDir: {}
```

### 2. MCP Servers Listen on Unix Sockets

Each MCP server sidecar creates a Unix socket instead of using raw stdio:

```python
# Instead of: stdio_server()
# We use: unix_socket_server("/sockets/jira.sock")
```

### 3. Agent Connects to Sockets

The agent spawns subprocess-like connections to each socket:

```python
# Connect to Jira MCP via Unix socket
reader, writer = await asyncio.open_unix_connection("/sockets/jira.sock")
```

### 4. Stdio Protocol Over Socket

The MCP protocol (JSON-RPC over stdio) works identically over Unix sockets:
- Same message format
- Same request/response flow
- No HTTP overhead

## Implementation

### Socket Wrapper for MCP Servers

Each MCP server needs a wrapper that:
1. Creates a Unix socket
2. Accepts connections
3. Bridges to the MCP stdio protocol

See `src/mcp_servers/socket_bridge.py` for the implementation.

### Agent MCP Client

The agent uses a client that:
1. Connects to Unix sockets
2. Sends MCP requests
3. Receives MCP responses

See `src/agent/mcp_client.py` for the implementation.

## Kubernetes Deployment

### Pod with Sidecars

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: sre-agent
spec:
  containers:
    # Main agent container
    - name: agent
      image: ai-sre-agent:latest
      volumeMounts:
        - name: mcp-sockets
          mountPath: /sockets
      env:
        - name: MCP_JIRA_SOCKET
          value: /sockets/jira.sock
        - name: MCP_CONFLUENCE_SOCKET
          value: /sockets/confluence.sock
        - name: MCP_GITLAB_SOCKET
          value: /sockets/gitlab.sock
    
    # Jira MCP sidecar
    - name: mcp-jira
      image: ai-sre-agent:latest
      command: ["mcp-jira", "--socket", "/sockets/jira.sock"]
      volumeMounts:
        - name: mcp-sockets
          mountPath: /sockets
      env:
        - name: JIRA_URL
          valueFrom:
            secretKeyRef:
              name: mcp-secrets
              key: JIRA_URL
    
    # Confluence MCP sidecar
    - name: mcp-confluence
      image: ai-sre-agent:latest
      command: ["mcp-confluence", "--socket", "/sockets/confluence.sock"]
      volumeMounts:
        - name: mcp-sockets
          mountPath: /sockets
    
    # GitLab MCP sidecar
    - name: mcp-gitlab
      image: ai-sre-agent:latest
      command: ["mcp-gitlab", "--socket", "/sockets/gitlab.sock"]
      volumeMounts:
        - name: mcp-sockets
          mountPath: /sockets
  
  volumes:
    - name: mcp-sockets
      emptyDir: {}
```

## Advantages

1. **No Custom Transport**: Uses MCP's native stdio protocol
2. **No Network Overhead**: Unix sockets are faster than TCP
3. **Simple Security**: Socket files are pod-local, no network exposure
4. **Easy Debugging**: Can still run locally with stdio
5. **Same Codebase**: One codebase works locally and in K8s

## Disadvantages

1. **No Independent Scaling**: MCP servers scale with agent pods
2. **Resource Sharing**: Sidecars share pod resources
3. **Restart Coupling**: Sidecar restart affects agent

## Alternative: Shared Deployment Scaling

For independent scaling while keeping stdio, use a hybrid approach:

```
┌─────────────────────┐     ┌─────────────────────┐
│ Agent Deployment    │     │ MCP Pool Deployment │
│ (N replicas)        │     │ (M replicas)        │
├─────────────────────┤     ├─────────────────────┤
│ ┌─────────────────┐ │     │ ┌─────────────────┐ │
│ │ Agent + socat   │◄──────►│ socat + MCP Jira│ │
│ │ proxy container │ │ TCP │ │ bridge container│ │
│ └─────────────────┘ │     │ └─────────────────┘ │
└─────────────────────┘     └─────────────────────┘
```

Use `socat` to bridge Unix sockets to TCP, enabling network communication while maintaining stdio at each end.

## Files in This Project

- `src/mcp_servers/socket_bridge.py` - Unix socket server wrapper
- `src/agent/mcp_client.py` - MCP client over Unix sockets
- `helm/ai-sre-agent/templates/agent-deployment.yaml` - K8s deployment with sidecars

## Running Locally vs Kubernetes

### Local Development (stdio)
```bash
# Direct stdio
echo '{"method": "tools/list"}' | mcp-jira

# Or via agent
uv run sre-agent interactive
```

### Kubernetes (Unix sockets)
```bash
# Agent automatically detects socket paths from env vars
# MCP_JIRA_SOCKET=/sockets/jira.sock triggers socket mode
```

The code auto-detects the environment and uses the appropriate transport.
