"""
MCP Server Usage Example
========================

This example shows how to use the MCP servers programmatically
(outside of the MCP protocol context).

Prerequisites:
    pip install atlassian-python-api python-gitlab
    
    Set environment variables:
    - JIRA_URL, JIRA_USERNAME, JIRA_TOKEN
    - CONFLUENCE_URL, CONFLUENCE_USERNAME, CONFLUENCE_TOKEN  
    - GITLAB_URL, GITLAB_TOKEN

Run:
    python examples/mcp_example.py
"""

import asyncio
import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


async def test_jira():
    """Test Jira MCP functions."""
    print("\n" + "-" * 40)
    print("Testing Jira MCP Server")
    print("-" * 40)
    
    if not os.getenv("JIRA_URL"):
        print("JIRA_URL not set - skipping Jira test")
        return
    
    from mcp_servers.jira import search_issues, get_issue, list_projects
    
    # List projects
    print("\nListing projects...")
    result = await list_projects(max_results=5)
    if "error" in result:
        print(f"  Error: {result['error']}")
    else:
        for proj in result.get("projects", []):
            print(f"  - {proj['key']}: {proj['name']}")
    
    # Search issues
    print("\nSearching for recent issues...")
    result = await search_issues(
        jql="created >= -7d ORDER BY created DESC",
        max_results=5,
    )
    if "error" in result:
        print(f"  Error: {result['error']}")
    else:
        for issue in result.get("issues", []):
            print(f"  - {issue['key']}: {issue.get('summary', 'N/A')}")


async def test_confluence():
    """Test Confluence MCP functions."""
    print("\n" + "-" * 40)
    print("Testing Confluence MCP Server")
    print("-" * 40)
    
    if not os.getenv("CONFLUENCE_URL"):
        print("CONFLUENCE_URL not set - skipping Confluence test")
        return
    
    from mcp_servers.confluence import search_pages, list_spaces
    
    # List spaces
    print("\nListing spaces...")
    result = await list_spaces(max_results=5)
    if "error" in result:
        print(f"  Error: {result['error']}")
    else:
        for space in result.get("spaces", []):
            print(f"  - {space['key']}: {space['name']}")
    
    # Search pages
    print("\nSearching for 'runbook'...")
    result = await search_pages(query="runbook", max_results=5)
    if "error" in result:
        print(f"  Error: {result['error']}")
    else:
        for page in result.get("pages", []):
            print(f"  - [{page.get('space_key')}] {page['title']}")


async def test_gitlab():
    """Test GitLab MCP functions."""
    print("\n" + "-" * 40)
    print("Testing GitLab MCP Server")
    print("-" * 40)
    
    if not os.getenv("GITLAB_URL"):
        print("GITLAB_URL not set - skipping GitLab test")
        return
    
    from mcp_servers.gitlab import list_projects, list_merge_requests
    
    # List projects
    print("\nListing projects...")
    result = await list_projects(per_page=5)
    if "error" in result:
        print(f"  Error: {result['error']}")
    else:
        projects = result.get("projects", [])
        for proj in projects:
            print(f"  - {proj['path_with_namespace']}")
        
        # List MRs for first project
        if projects:
            project_id = projects[0]["id"]
            print(f"\nListing open MRs for project {project_id}...")
            result = await list_merge_requests(project_id=project_id, state="opened", per_page=5)
            if "error" in result:
                print(f"  Error: {result['error']}")
            else:
                for mr in result.get("merge_requests", []):
                    print(f"  - !{mr['iid']}: {mr['title']}")


async def main():
    """Run all MCP tests."""
    print("=" * 60)
    print("MCP Server Usage Example")
    print("=" * 60)
    print("\nThis example tests the MCP server functions directly.")
    print("All operations are READ-ONLY.")
    
    await test_jira()
    await test_confluence()
    await test_gitlab()
    
    print("\n" + "=" * 60)
    print("MCP example complete!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
