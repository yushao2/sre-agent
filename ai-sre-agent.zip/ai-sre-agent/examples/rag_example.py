"""
RAG (Retrieval Augmented Generation) Example
=============================================

This example shows how to use the RAG system to store and search
past incidents and runbooks.

Prerequisites:
    pip install chromadb sentence-transformers

Run:
    python examples/rag_example.py
"""

import sys
import os
import tempfile

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from agent.rag import IncidentKnowledgeBase, RunbookStore


def main():
    """Demonstrate RAG functionality."""
    
    print("=" * 60)
    print("AI SRE Agent - RAG Example")
    print("=" * 60)
    
    # Use temporary directory for this demo
    with tempfile.TemporaryDirectory() as tmpdir:
        
        # =====================================================================
        # Part 1: Incident Knowledge Base
        # =====================================================================
        print("\n" + "-" * 40)
        print("Part 1: Incident Knowledge Base")
        print("-" * 40)
        
        # Create knowledge base
        kb = IncidentKnowledgeBase(persist_directory=f"{tmpdir}/incidents")
        print(f"Created incident KB at: {tmpdir}/incidents")
        
        # Add some incidents
        incidents = [
            {
                "key": "INC-100",
                "summary": "Database connection pool exhausted",
                "description": "Production PostgreSQL database reached max connections",
                "root_cause": "Connection leak in the reporting microservice",
                "resolution": "Fixed connection leak, added connection pool monitoring",
                "labels": ["database", "connections", "postgresql"],
            },
            {
                "key": "INC-101", 
                "summary": "API gateway high latency during peak hours",
                "description": "p99 latency spiked from 100ms to 5 seconds at 10am",
                "root_cause": "Missing database index on user_activity table",
                "resolution": "Added composite index, latency returned to normal",
                "labels": ["api", "latency", "database"],
            },
            {
                "key": "INC-102",
                "summary": "Memory leak causing pod restarts",
                "description": "API pods being OOMKilled every 4 hours",
                "root_cause": "Unbounded in-memory cache without eviction policy",
                "resolution": "Implemented LRU cache with 1GB max size",
                "labels": ["memory", "oom", "kubernetes"],
            },
            {
                "key": "INC-103",
                "summary": "SSL certificate expiry caused outage",
                "description": "All HTTPS traffic failing with certificate errors",
                "root_cause": "Certificate auto-renewal failed silently",
                "resolution": "Manually renewed cert, added monitoring for expiry",
                "labels": ["ssl", "certificates", "monitoring"],
            },
            {
                "key": "INC-104",
                "summary": "Kafka consumer lag causing delayed notifications",
                "description": "Users not receiving real-time notifications",
                "root_cause": "Consumer group rebalancing storm after deployment",
                "resolution": "Increased session timeout, added sticky partitioning",
                "labels": ["kafka", "messaging", "notifications"],
            },
        ]
        
        print(f"\nAdding {len(incidents)} incidents...")
        for incident in incidents:
            kb.add_incident(incident)
            print(f"  Added: {incident['key']} - {incident['summary']}")
        
        print(f"\nTotal incidents in KB: {kb.count()}")
        
        # Search for similar incidents
        print("\n--- Searching for 'connection timeout errors' ---")
        results = kb.search("connection timeout errors", k=3)
        for incident, score in results:
            print(f"  [{score:.3f}] {incident['key']}: {incident['summary']}")
        
        print("\n--- Searching for 'memory issues kubernetes' ---")
        results = kb.search("memory issues kubernetes", k=3)
        for incident, score in results:
            print(f"  [{score:.3f}] {incident['key']}: {incident['summary']}")
        
        print("\n--- Searching for 'slow API response time' ---")
        results = kb.search("slow API response time", k=3)
        for incident, score in results:
            print(f"  [{score:.3f}] {incident['key']}: {incident['summary']}")
        
        # =====================================================================
        # Part 2: Runbook Store
        # =====================================================================
        print("\n" + "-" * 40)
        print("Part 2: Runbook Store")
        print("-" * 40)
        
        store = RunbookStore(persist_directory=f"{tmpdir}/runbooks")
        print(f"Created runbook store at: {tmpdir}/runbooks")
        
        # Add a runbook
        runbook = {
            "id": "RB-DB-001",
            "title": "Database Connection Pool Troubleshooting",
            "tags": ["database", "postgresql", "connections"],
            "content": """
# Database Connection Pool Troubleshooting

## Overview
This runbook covers diagnosing and resolving database connection pool issues.

## Symptoms
- "Too many connections" errors in application logs
- Connection timeout exceptions
- Slow or hanging database queries
- High database CPU usage

## Diagnosis Steps

### Step 1: Check Current Connections
```sql
SELECT count(*) FROM pg_stat_activity;
SELECT usename, count(*) FROM pg_stat_activity GROUP BY usename;
```

### Step 2: Identify Long-Running Queries
```sql
SELECT pid, now() - pg_stat_activity.query_start AS duration, query
FROM pg_stat_activity
WHERE state != 'idle'
ORDER BY duration DESC;
```

### Step 3: Check Application Connection Pool
- Review connection pool settings (min, max, timeout)
- Check for connection leaks in recent deployments
- Verify connection health check configuration

## Resolution Steps

### Quick Fix: Kill Idle Connections
```sql
SELECT pg_terminate_backend(pid)
FROM pg_stat_activity
WHERE state = 'idle'
AND query_start < now() - interval '5 minutes';
```

### Long-term Fix
1. Add connection pool monitoring
2. Set up alerts at 80% capacity
3. Implement connection timeout in applications
4. Review and fix connection leaks

## Prevention
- Monitor connection pool utilization
- Set appropriate connection limits
- Implement circuit breakers
- Regular load testing
            """,
        }
        
        chunks = store.add_runbook(runbook)
        print(f"\nAdded runbook '{runbook['title']}' ({len(chunks)} chunks)")
        
        # Search runbooks
        print("\n--- Searching runbooks for 'connection timeout' ---")
        results = store.search("connection timeout", k=2)
        for result, score in results:
            print(f"  [{score:.3f}] {result['title']}")
            print(f"           Chunk {result['chunk_index']+1}/{result['total_chunks']}")
            # Show snippet
            content = result['content'][:200].replace('\n', ' ')
            print(f"           \"{content}...\"")
        
        print("\n--- Searching runbooks for 'kill idle connections SQL' ---")
        results = store.search("kill idle connections SQL", k=2)
        for result, score in results:
            print(f"  [{score:.3f}] {result['title']}")
            print(f"           Chunk {result['chunk_index']+1}/{result['total_chunks']}")
    
    print("\n" + "=" * 60)
    print("RAG example complete!")
    print("=" * 60)
    print("\nNote: In production, use a persistent directory:")
    print("  kb = IncidentKnowledgeBase(persist_directory='/data/incidents')")
    print("  store = RunbookStore(persist_directory='/data/runbooks')")


if __name__ == "__main__":
    main()
