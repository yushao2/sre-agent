"""
Simple Usage Example
====================

This example shows how to use the AI SRE Agent programmatically.

Prerequisites:
    1. Set environment variables:
       export LLM_BASE_URL=https://your-model-server.com
       export LLM_API_KEY=your-api-key
    
    2. Customize src/agent/llm_custom.py for your API format
    
    3. Install dependencies:
       pip install -e .

Run:
    python examples/simple_usage.py
"""

import asyncio
import json
import os
import sys

# Add src to path for development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from agent import SREAgentSimple


async def main():
    """Demonstrate basic agent usage."""
    
    print("=" * 60)
    print("AI SRE Agent - Simple Usage Example")
    print("=" * 60)
    
    # Check configuration
    if not os.getenv("LLM_BASE_URL"):
        print()
        print("ERROR: LLM_BASE_URL not set!")
        print("Please configure your model server:")
        print("  export LLM_BASE_URL=https://your-model-server.com")
        print("  export LLM_API_KEY=your-api-key")
        sys.exit(1)
    
    # Create agent
    print("\n1. Creating agent...")
    agent = SREAgentSimple()
    print(f"   Model: {agent.model_name}")
    
    # Example 1: Simple chat
    print("\n2. Testing chat...")
    print("-" * 40)
    response = await agent.chat("What are the top 3 causes of API latency?")
    print(response)
    
    # Example 2: Summarize incident
    print("\n3. Testing incident summarization...")
    print("-" * 40)
    
    incident = {
        "key": "INC-001",
        "summary": "Production database connection pool exhausted",
        "description": """
        At 10:30 UTC, monitoring alerted on increased 5xx errors.
        Investigation showed database connection pool was at 100%.
        Root cause was a connection leak in the reporting service.
        Service was restarted and connections recovered.
        """,
        "status": "Resolved",
        "priority": "Critical",
    }
    
    summary = await agent.summarize_incident_simple(incident)
    print(summary)
    
    # Example 3: Triage ticket
    print("\n4. Testing ticket triage...")
    print("-" * 40)
    
    ticket = {
        "key": "SUPPORT-123",
        "summary": "Cannot export reports to PDF",
        "description": """
        When I click the Export to PDF button, nothing happens.
        I've tried clearing my cache and using a different browser.
        This worked fine last week.
        """,
    }
    
    triage = await agent.triage_ticket_simple(ticket)
    print(triage)
    
    print("\n" + "=" * 60)
    print("Examples complete!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
