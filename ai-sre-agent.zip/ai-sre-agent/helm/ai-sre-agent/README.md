# AI SRE Agent Helm Chart

Kubernetes Helm chart for deploying the AI SRE Agent.

## Overview

This chart deploys:
- **API Server**: FastAPI application for REST API and webhooks
- **Celery Workers**: Background task processing for LLM operations
- **Celery Beat**: Optional scheduler for periodic tasks
- **MCP Servers**: Jira, Confluence, GitLab integrations
- **Redis**: Message broker (via Bitnami subchart or external)
- **PostgreSQL**: Result storage (via Bitnami subchart or external)

## Prerequisites

- Kubernetes 1.21+
- Helm 3.0+
- PV provisioner (for Redis/PostgreSQL persistence)

## Installation

### Quick Start

```bash
# Add Bitnami repo for Redis/PostgreSQL subcharts
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

# Create namespace
kubectl create namespace ai-sre-agent

# Create secrets
kubectl create secret generic ai-sre-agent-secrets \
  --namespace ai-sre-agent \
  --from-literal=LLM_BASE_URL=https://your-llm-server.com \
  --from-literal=LLM_API_KEY=your-key \
  --from-literal=JIRA_URL=https://jira.company.com \
  --from-literal=JIRA_USERNAME=your-username \
  --from-literal=JIRA_TOKEN=your-token

# Install chart
helm install ai-sre-agent ./helm/ai-sre-agent \
  --namespace ai-sre-agent \
  --set secrets.existingSecret=ai-sre-agent-secrets
```

### With Custom Values

```bash
# Create values file
cat > my-values.yaml <<EOF
api:
  replicaCount: 3

worker:
  replicaCount: 5
  concurrency: 8

secrets:
  existingSecret: my-existing-secret

redis:
  enabled: false

externalRedis:
  host: my-redis.example.com
  port: 6379
EOF

# Install with custom values
helm install ai-sre-agent ./helm/ai-sre-agent \
  --namespace ai-sre-agent \
  -f my-values.yaml
```

## Configuration

### Required Configuration

| Parameter | Description |
|-----------|-------------|
| `secrets.llm.baseUrl` | Your LLM server URL |
| `secrets.llm.apiKey` | LLM API key |

### API Server

| Parameter | Default | Description |
|-----------|---------|-------------|
| `api.enabled` | `true` | Enable API server |
| `api.replicaCount` | `2` | Number of replicas |
| `api.image.repository` | `ai-sre-agent` | Image repository |
| `api.image.tag` | `latest` | Image tag |
| `api.resources.limits.cpu` | `1` | CPU limit |
| `api.resources.limits.memory` | `1Gi` | Memory limit |
| `api.ingress.enabled` | `false` | Enable ingress |

### Celery Workers

| Parameter | Default | Description |
|-----------|---------|-------------|
| `worker.enabled` | `true` | Enable workers |
| `worker.replicaCount` | `2` | Number of replicas |
| `worker.concurrency` | `4` | Worker concurrency |
| `worker.queues` | `llm` | Celery queues |
| `worker.resources.limits.cpu` | `2` | CPU limit |
| `worker.resources.limits.memory` | `4Gi` | Memory limit |

### MCP Servers

| Parameter | Default | Description |
|-----------|---------|-------------|
| `mcpServers.jira.enabled` | `true` | Enable Jira MCP |
| `mcpServers.confluence.enabled` | `true` | Enable Confluence MCP |
| `mcpServers.gitlab.enabled` | `true` | Enable GitLab MCP |

### Redis

| Parameter | Default | Description |
|-----------|---------|-------------|
| `redis.enabled` | `true` | Deploy Redis subchart |
| `redis.architecture` | `standalone` | Redis architecture |
| `externalRedis.host` | `""` | External Redis host |

### PostgreSQL

| Parameter | Default | Description |
|-----------|---------|-------------|
| `postgresql.enabled` | `true` | Deploy PostgreSQL subchart |
| `externalPostgresql.host` | `""` | External PostgreSQL host |

## Secrets

### Using existingSecret (Recommended)

Create a secret with these keys:
- `LLM_BASE_URL`
- `LLM_API_KEY`
- `MODEL_NAME` (optional)
- `JIRA_URL`, `JIRA_USERNAME`, `JIRA_TOKEN`
- `CONFLUENCE_URL`, `CONFLUENCE_USERNAME`, `CONFLUENCE_TOKEN`
- `GITLAB_URL`, `GITLAB_TOKEN`

```bash
kubectl create secret generic ai-sre-agent-secrets \
  --from-literal=LLM_BASE_URL=... \
  --from-literal=LLM_API_KEY=...
```

Then reference it:

```yaml
secrets:
  existingSecret: ai-sre-agent-secrets
```

### Using values.yaml (Development Only)

```yaml
secrets:
  create: true
  llm:
    baseUrl: https://llm.company.com
    apiKey: your-key
  jira:
    url: https://jira.company.com
    username: your-username
    apiToken: your-token
```

## Upgrading

```bash
helm upgrade ai-sre-agent ./helm/ai-sre-agent \
  --namespace ai-sre-agent \
  -f my-values.yaml
```

## Uninstalling

```bash
helm uninstall ai-sre-agent --namespace ai-sre-agent
kubectl delete namespace ai-sre-agent
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Kubernetes Cluster                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌──────────────┐     ┌──────────────┐     ┌──────────────┐   │
│   │  API Server  │────▶│    Redis     │◀────│   Workers    │   │
│   │  (FastAPI)   │     │   (Broker)   │     │   (Celery)   │   │
│   └──────────────┘     └──────────────┘     └──────────────┘   │
│          │                                         │            │
│          │                                         │            │
│          ▼                                         ▼            │
│   ┌──────────────┐                         ┌──────────────┐    │
│   │  PostgreSQL  │                         │  LLM Server  │    │
│   │  (Results)   │                         │  (External)  │    │
│   └──────────────┘                         └──────────────┘    │
│                                                                  │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│   │   Jira MCP   │  │Confluence MCP│  │  GitLab MCP  │        │
│   └──────────────┘  └──────────────┘  └──────────────┘        │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```
