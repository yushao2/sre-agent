"""
AI SRE Agent Test Suite
=======================

Run tests with:
    pytest tests/
    pytest tests/ -v --cov=agent
"""
