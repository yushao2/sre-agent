"""
Pytest Configuration and Fixtures
==================================

Shared fixtures for all tests.
"""

import os
import sys
import pytest

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


@pytest.fixture(scope="session")
def sample_incident():
    """Sample incident data for testing."""
    return {
        "key": "INC-TEST-001",
        "summary": "Test incident for unit tests",
        "description": "This is a test incident created for unit testing.",
        "status": "Open",
        "priority": "High",
        "comments": {
            "comments": [
                {
                    "author": "test-user",
                    "body": "Test comment",
                    "created": "2024-01-01T00:00:00Z",
                }
            ]
        },
    }


@pytest.fixture(scope="session")
def sample_ticket():
    """Sample ticket data for testing."""
    return {
        "key": "TICKET-TEST-001",
        "summary": "Test support ticket",
        "description": "User cannot login to the application.",
        "reporter": {
            "displayName": "Test User",
            "email": "test@example.com",
        },
        "labels": ["support", "login"],
    }


@pytest.fixture
def mock_llm_env(monkeypatch):
    """Set mock LLM environment variables."""
    monkeypatch.setenv("LLM_BASE_URL", "http://localhost:8000")
    monkeypatch.setenv("LLM_API_KEY", "test-key")
    monkeypatch.setenv("MODEL_NAME", "test-model")
