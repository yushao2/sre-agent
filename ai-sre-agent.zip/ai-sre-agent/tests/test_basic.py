"""
Basic Tests for AI SRE Agent
============================

These tests verify the basic structure and imports work correctly.
They don't require a model server to run.
"""

import pytest


class TestImports:
    """Test that modules can be imported."""
    
    def test_import_agent(self):
        """Test agent module imports."""
        from agent import SREAgentSimple
        assert SREAgentSimple is not None
    
    def test_import_prompts(self):
        """Test prompts module imports."""
        from agent.prompts import (
            SRE_AGENT_SYSTEM_PROMPT,
            format_incident_prompt,
            format_triage_prompt,
        )
        assert SRE_AGENT_SYSTEM_PROMPT
        assert callable(format_incident_prompt)
        assert callable(format_triage_prompt)
    
    def test_import_llm_custom(self):
        """Test custom LLM module imports."""
        from agent.llm_custom import (
            CustomModelServerLLM,
            create_llm,
        )
        assert CustomModelServerLLM is not None
        assert callable(create_llm)


class TestPromptFormatters:
    """Test prompt formatting functions."""
    
    def test_format_incident_prompt(self):
        """Test incident prompt formatting."""
        from agent.prompts import format_incident_prompt
        
        incident = {
            "key": "INC-123",
            "summary": "Test incident",
            "description": "This is a test",
            "status": "Open",
            "priority": "High",
        }
        
        prompt = format_incident_prompt(incident)
        
        assert "INC-123" in prompt
        assert "Test incident" in prompt
        assert "This is a test" in prompt
    
    def test_format_triage_prompt(self):
        """Test triage prompt formatting."""
        from agent.prompts import format_triage_prompt
        
        ticket = {
            "key": "TICKET-456",
            "summary": "Cannot login",
            "description": "Getting error 500",
        }
        
        prompt = format_triage_prompt(ticket)
        
        assert "TICKET-456" in prompt
        assert "Cannot login" in prompt
    
    def test_format_incident_with_comments(self):
        """Test incident prompt with comments."""
        from agent.prompts import format_incident_prompt
        
        incident = {
            "key": "INC-100",
            "summary": "Test",
            "description": "Test desc",
            "comments": {
                "comments": [
                    {"author": "user1", "body": "Comment 1", "created": "2024-01-01"},
                    {"author": "user2", "body": "Comment 2", "created": "2024-01-02"},
                ]
            }
        }
        
        prompt = format_incident_prompt(incident)
        
        assert "Comment 1" in prompt
        assert "Comment 2" in prompt
        assert "user1" in prompt


class TestCustomLLMConfig:
    """Test custom LLM configuration."""
    
    def test_llm_has_required_methods(self):
        """Test that custom LLM has required methods."""
        from agent.llm_custom import CustomModelServerLLM
        
        # Check required methods exist
        assert hasattr(CustomModelServerLLM, "_get_endpoint")
        assert hasattr(CustomModelServerLLM, "_get_headers")
        assert hasattr(CustomModelServerLLM, "_convert_messages")
        assert hasattr(CustomModelServerLLM, "_build_request_body")
        assert hasattr(CustomModelServerLLM, "_parse_response")
    
    def test_llm_initialization(self):
        """Test LLM can be initialized with parameters."""
        from agent.llm_custom import CustomModelServerLLM
        
        llm = CustomModelServerLLM(
            base_url="http://localhost:8000",
            api_key="test-key",
            model="test-model",
        )
        
        assert llm.base_url == "http://localhost:8000"
        assert llm.model == "test-model"
