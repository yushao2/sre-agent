"""
Tests for RAG (Retrieval Augmented Generation) module.
"""

import pytest
import tempfile


class TestIncidentKnowledgeBase:
    """Test the IncidentKnowledgeBase class."""
    
    @pytest.fixture
    def kb(self):
        """Create a temporary knowledge base for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from agent.rag import IncidentKnowledgeBase
            yield IncidentKnowledgeBase(persist_directory=f"{tmpdir}/incidents")
    
    def test_add_incident(self, kb):
        """Test adding an incident."""
        incident = {
            "key": "INC-001",
            "summary": "Test incident",
            "description": "This is a test incident",
        }
        
        key = kb.add_incident(incident)
        assert key == "INC-001"
        assert kb.count() == 1
    
    def test_add_incident_requires_key(self, kb):
        """Test that incident requires a key."""
        with pytest.raises(ValueError, match="must have a 'key' field"):
            kb.add_incident({"summary": "No key"})
    
    def test_add_incident_requires_content(self, kb):
        """Test that incident requires some content."""
        with pytest.raises(ValueError, match="must have some text content"):
            kb.add_incident({"key": "INC-001"})
    
    def test_search_incidents(self, kb):
        """Test searching for incidents."""
        # Add some incidents
        kb.add_incident({
            "key": "INC-001",
            "summary": "Database connection pool exhausted",
            "root_cause": "Connection leak",
        })
        kb.add_incident({
            "key": "INC-002",
            "summary": "Memory leak in API service",
            "root_cause": "Unbounded cache",
        })
        
        # Search
        results = kb.search("database connection", k=2)
        
        assert len(results) > 0
        assert results[0][0]["key"] == "INC-001"  # Should be most relevant
    
    def test_get_incident(self, kb):
        """Test getting a specific incident."""
        kb.add_incident({
            "key": "INC-001",
            "summary": "Test incident",
            "custom_field": "custom value",
        })
        
        incident = kb.get_incident("INC-001")
        
        assert incident is not None
        assert incident["key"] == "INC-001"
        assert incident["custom_field"] == "custom value"
    
    def test_get_nonexistent_incident(self, kb):
        """Test getting an incident that doesn't exist."""
        result = kb.get_incident("NONEXISTENT")
        assert result is None
    
    def test_delete_incident(self, kb):
        """Test deleting an incident."""
        kb.add_incident({"key": "INC-001", "summary": "Test"})
        assert kb.count() == 1
        
        result = kb.delete_incident("INC-001")
        
        assert result is True
        assert kb.count() == 0
    
    def test_list_all(self, kb):
        """Test listing all incidents."""
        kb.add_incident({"key": "INC-001", "summary": "First"})
        kb.add_incident({"key": "INC-002", "summary": "Second"})
        
        incidents = kb.list_all()
        
        assert len(incidents) == 2
        keys = {i["key"] for i in incidents}
        assert keys == {"INC-001", "INC-002"}


class TestRunbookStore:
    """Test the RunbookStore class."""
    
    @pytest.fixture
    def store(self):
        """Create a temporary runbook store for testing."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from agent.rag import RunbookStore
            yield RunbookStore(persist_directory=f"{tmpdir}/runbooks")
    
    def test_add_runbook(self, store):
        """Test adding a runbook."""
        runbook = {
            "id": "RB-001",
            "title": "Test Runbook",
            "content": "This is the runbook content.",
            "tags": ["test", "example"],
        }
        
        chunks = store.add_runbook(runbook)
        
        assert len(chunks) >= 1
        assert store.count() >= 1
    
    def test_add_runbook_requires_fields(self, store):
        """Test that runbook requires id, title, content."""
        with pytest.raises(ValueError):
            store.add_runbook({"id": "RB-001"})  # Missing title and content
    
    def test_search_runbooks(self, store):
        """Test searching runbooks."""
        store.add_runbook({
            "id": "RB-001",
            "title": "Database Troubleshooting",
            "content": "Steps to diagnose database connection issues.",
        })
        store.add_runbook({
            "id": "RB-002",
            "title": "Memory Leak Investigation",
            "content": "How to find and fix memory leaks.",
        })
        
        results = store.search("database connection", k=2)
        
        assert len(results) > 0
        assert results[0][0]["runbook_id"] == "RB-001"
    
    def test_chunking_long_content(self, store):
        """Test that long content is chunked."""
        long_content = "A" * 2000 + " " + "B" * 2000  # 4000+ chars
        
        chunks = store.add_runbook({
            "id": "RB-001",
            "title": "Long Runbook",
            "content": long_content,
        }, chunk_size=1000)
        
        assert len(chunks) > 1
    
    def test_delete_runbook(self, store):
        """Test deleting a runbook."""
        store.add_runbook({
            "id": "RB-001",
            "title": "Test",
            "content": "Content",
        })
        
        deleted = store.delete_runbook("RB-001")
        
        assert deleted >= 1
        assert store.count() == 0
