"""
Custom LLM Integration for Your Model Server
=============================================

This module provides a LangChain-compatible chat model that communicates
with YOUR custom model server. You MUST customize this file to match your
API format.

QUICK START
-----------
1. Set environment variables:
   
   export LLM_BASE_URL=https://your-model-server.company.com
   export LLM_API_KEY=your-api-key

2. Search for ">>> CUSTOMIZE" in this file and modify those methods

3. Test your configuration:
   
   python -m agent.llm_custom

4. Use with the agent:
   
   from agent import SREAgentSimple
   agent = SREAgentSimple()
   result = await agent.chat("Hello!")


WHAT TO CUSTOMIZE
-----------------
There are 5 methods you need to modify, marked with ">>> CUSTOMIZE":

1. _get_endpoint()       - Your API URL path (e.g., /v1/chat/completions)
2. _get_headers()        - Authentication headers (e.g., Bearer token)
3. _convert_messages()   - Convert LangChain messages to your format
4. _build_request_body() - Build the JSON request payload
5. _parse_response()     - Extract the generated text from the response


COMMON API FORMATS
------------------
Here are examples for common API formats:

OpenAI-compatible (vLLM, TGI, Ollama):
    Endpoint: POST /v1/chat/completions
    Request:  {"model": "...", "messages": [{"role": "user", "content": "..."}]}
    Response: {"choices": [{"message": {"content": "..."}}]}

Anthropic-compatible:
    Endpoint: POST /v1/messages
    Request:  {"model": "...", "system": "...", "messages": [...]}
    Response: {"content": [{"type": "text", "text": "..."}]}

Simple/Custom:
    Endpoint: POST /api/generate
    Request:  {"prompt": "...", "max_tokens": 1000}
    Response: {"generated_text": "..."}


ENVIRONMENT VARIABLES
---------------------
LLM_BASE_URL  - Your model server URL (required)
LLM_API_KEY   - API key for authentication (usually required)
MODEL_NAME    - Model identifier (optional)
LLM_TIMEOUT   - Request timeout in seconds (default: 120)
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

import httpx
from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import Field, SecretStr


# Set up logging
logger = logging.getLogger(__name__)


# =============================================================================
# CUSTOM LLM CLASS
# =============================================================================

class CustomModelServerLLM(BaseChatModel):
    """
    LangChain-compatible chat model for your custom model server.
    
    This class handles all communication with your model server.
    You MUST customize the methods marked with ">>> CUSTOMIZE".
    
    Attributes:
        base_url: Base URL of your model server
        api_key: API key for authentication
        model: Model identifier/name
        max_tokens: Maximum tokens in response
        temperature: Sampling temperature (0.0 = deterministic)
        timeout: HTTP request timeout in seconds
        verify_ssl: Whether to verify SSL certificates
    
    Example:
        >>> llm = CustomModelServerLLM(
        ...     base_url="https://llm.company.com",
        ...     api_key="your-key",
        ... )
        >>> response = llm.invoke([HumanMessage(content="Hello!")])
        >>> print(response.content)
    """
    
    # =========================================================================
    # CONFIGURATION FIELDS
    # =========================================================================
    # These fields are automatically populated from environment variables
    # or can be passed explicitly to the constructor.
    
    base_url: str = Field(
        default_factory=lambda: os.getenv("LLM_BASE_URL", "http://localhost:8000"),
        description="Base URL of your model server",
    )
    
    api_key: Optional[SecretStr] = Field(
        default=None,
        description="API key for authentication",
    )
    
    model: str = Field(
        default_factory=lambda: os.getenv("MODEL_NAME", "default-model"),
        description="Model identifier",
    )
    
    max_tokens: int = Field(
        default=4096,
        description="Maximum tokens in response",
    )
    
    temperature: float = Field(
        default=0.0,
        description="Sampling temperature (0.0 = deterministic, 1.0 = creative)",
    )
    
    timeout: float = Field(
        default_factory=lambda: float(os.getenv("LLM_TIMEOUT", "120")),
        description="Request timeout in seconds",
    )
    
    verify_ssl: bool = Field(
        default=True,
        description="Verify SSL certificates (set False for self-signed certs)",
    )
    
    # =========================================================================
    # ADD YOUR CUSTOM FIELDS HERE
    # =========================================================================
    # If your API requires additional parameters, add them here.
    # Examples:
    #
    # top_p: float = Field(default=1.0, description="Top-p sampling")
    # top_k: int = Field(default=50, description="Top-k sampling")
    # stop_sequences: List[str] = Field(default_factory=list)
    # api_version: str = Field(default="v1")
    # =========================================================================
    
    # Internal HTTP clients (do not modify)
    _sync_client: Optional[httpx.Client] = None
    _async_client: Optional[httpx.AsyncClient] = None
    
    class Config:
        arbitrary_types_allowed = True
    
    def __init__(self, **kwargs):
        """
        Initialize the LLM.
        
        API key is loaded from (in order):
        1. api_key parameter
        2. LLM_API_KEY environment variable
        """
        # Load api_key from environment if not provided
        if "api_key" not in kwargs or kwargs.get("api_key") is None:
            env_key = os.getenv("LLM_API_KEY")
            if env_key:
                kwargs["api_key"] = SecretStr(env_key)
        elif isinstance(kwargs.get("api_key"), str):
            kwargs["api_key"] = SecretStr(kwargs["api_key"])
        
        super().__init__(**kwargs)
        
        logger.debug(f"Initialized LLM: base_url={self.base_url}, model={self.model}")
    
    @property
    def _llm_type(self) -> str:
        """Identifier for this LLM type (used in LangChain tracing)."""
        return "custom-model-server"
    
    @property
    def _identifying_params(self) -> Dict[str, Any]:
        """Parameters that identify this LLM instance."""
        return {
            "base_url": self.base_url,
            "model": self.model,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }
    
    # =========================================================================
    # HTTP CLIENT MANAGEMENT (do not modify)
    # =========================================================================
    
    def _get_sync_client(self) -> httpx.Client:
        """Get or create synchronous HTTP client."""
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                timeout=httpx.Timeout(self.timeout),
                verify=self.verify_ssl,
                limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
            )
        return self._sync_client
    
    def _get_async_client(self) -> httpx.AsyncClient:
        """Get or create asynchronous HTTP client."""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                verify=self.verify_ssl,
                limits=httpx.Limits(max_keepalive_connections=5, max_connections=10),
            )
        return self._async_client
    
    # =========================================================================
    # >>> CUSTOMIZE: API ENDPOINT
    # =========================================================================
    
    def _get_endpoint(self) -> str:
        """
        >>> CUSTOMIZE THIS METHOD
        
        Return the full URL for your model API endpoint.
        
        Examples:
            # OpenAI-compatible (vLLM, TGI, Ollama, etc.)
            return f"{self.base_url}/v1/chat/completions"
            
            # Anthropic-compatible
            return f"{self.base_url}/v1/messages"
            
            # Text Generation Inference (TGI)
            return f"{self.base_url}/generate"
            
            # Ollama
            return f"{self.base_url}/api/chat"
            
            # Custom
            return f"{self.base_url}/api/v2/inference"
        """
        # =====================================================================
        # TODO: MODIFY THIS TO MATCH YOUR API
        # =====================================================================
        
        # Default: OpenAI-compatible endpoint
        return f"{self.base_url.rstrip('/')}/v1/chat/completions"
    
    # =========================================================================
    # >>> CUSTOMIZE: AUTHENTICATION HEADERS
    # =========================================================================
    
    def _get_headers(self) -> Dict[str, str]:
        """
        >>> CUSTOMIZE THIS METHOD
        
        Return HTTP headers for your API requests.
        
        Common authentication patterns:
        
            # Bearer token (OpenAI, most common)
            headers["Authorization"] = f"Bearer {api_key}"
            
            # X-API-Key header
            headers["X-API-Key"] = api_key
            
            # Anthropic style
            headers["x-api-key"] = api_key
            headers["anthropic-version"] = "2023-06-01"
            
            # Basic auth
            import base64
            credentials = base64.b64encode(f"user:{api_key}".encode()).decode()
            headers["Authorization"] = f"Basic {credentials}"
        """
        # =====================================================================
        # TODO: MODIFY THIS TO MATCH YOUR AUTH METHOD
        # =====================================================================
        
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        
        if self.api_key:
            api_key = self.api_key.get_secret_value()
            
            # Default: Bearer token
            headers["Authorization"] = f"Bearer {api_key}"
            
            # Uncomment for alternative auth methods:
            # headers["X-API-Key"] = api_key
            # headers["x-api-key"] = api_key
        
        return headers
    
    # =========================================================================
    # >>> CUSTOMIZE: MESSAGE FORMAT CONVERSION
    # =========================================================================
    
    def _convert_messages(self, messages: List[BaseMessage]) -> Any:
        """
        >>> CUSTOMIZE THIS METHOD
        
        Convert LangChain messages to your API's format.
        
        Input: List of LangChain message objects
            - SystemMessage(content="You are a helpful assistant")
            - HumanMessage(content="Hello!")
            - AIMessage(content="Hi there!")
        
        Output: Whatever format your API expects
        
        Example outputs for different APIs:
        
        1. OpenAI-style (list of dicts):
            [
                {"role": "system", "content": "..."},
                {"role": "user", "content": "..."},
                {"role": "assistant", "content": "..."},
            ]
        
        2. Anthropic-style (dict with system and messages):
            {
                "system": "...",
                "messages": [
                    {"role": "user", "content": "..."},
                    {"role": "assistant", "content": "..."},
                ]
            }
        
        3. Simple prompt string:
            "System: ...\\n\\nHuman: ...\\n\\nAssistant:"
        """
        # =====================================================================
        # TODO: MODIFY THIS TO MATCH YOUR MESSAGE FORMAT
        # =====================================================================
        
        # Default: OpenAI-style conversion
        converted = []
        
        for msg in messages:
            if isinstance(msg, SystemMessage):
                converted.append({
                    "role": "system",
                    "content": str(msg.content)
                })
            elif isinstance(msg, HumanMessage):
                converted.append({
                    "role": "user",
                    "content": str(msg.content)
                })
            elif isinstance(msg, AIMessage):
                converted.append({
                    "role": "assistant",
                    "content": str(msg.content)
                })
            else:
                # Unknown message type - treat as user
                logger.warning(f"Unknown message type: {type(msg).__name__}")
                converted.append({
                    "role": "user",
                    "content": str(msg.content)
                })
        
        return converted
    
    # =========================================================================
    # >>> CUSTOMIZE: REQUEST BODY STRUCTURE
    # =========================================================================
    
    def _build_request_body(self, messages: List[BaseMessage]) -> Dict[str, Any]:
        """
        >>> CUSTOMIZE THIS METHOD
        
        Build the complete JSON request body for your API.
        
        Example request bodies for different APIs:
        
        1. OpenAI-style:
            {
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 4096,
                "temperature": 0.0
            }
        
        2. Anthropic-style:
            {
                "model": "claude-3-sonnet",
                "system": "You are helpful",
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 4096
            }
        
        3. Simple/Custom:
            {
                "prompt": "Human: Hello\\n\\nAssistant:",
                "max_new_tokens": 4096,
                "temperature": 0.0,
                "do_sample": false
            }
        """
        # =====================================================================
        # TODO: MODIFY THIS TO MATCH YOUR REQUEST FORMAT
        # =====================================================================
        
        converted_messages = self._convert_messages(messages)
        
        # Default: OpenAI-style request body
        body: Dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }
        
        # Add any additional parameters your API needs:
        # body["stream"] = False
        # body["top_p"] = 0.9
        # body["stop"] = ["\\n\\nHuman:"]
        
        return body
    
    # =========================================================================
    # >>> CUSTOMIZE: RESPONSE PARSING
    # =========================================================================
    
    def _parse_response(self, response_data: Dict[str, Any]) -> str:
        """
        >>> CUSTOMIZE THIS METHOD
        
        Extract the generated text from your API's response.
        
        Input: The JSON response from your API (as a dict)
        Output: The generated text string
        
        Example response formats:
        
        1. OpenAI-style:
            {"choices": [{"message": {"content": "Hello!"}}]}
            -> return response_data["choices"][0]["message"]["content"]
        
        2. Anthropic-style:
            {"content": [{"type": "text", "text": "Hello!"}]}
            -> return response_data["content"][0]["text"]
        
        3. Simple:
            {"generated_text": "Hello!"}
            -> return response_data["generated_text"]
            
            {"text": "Hello!"}
            -> return response_data["text"]
        """
        # =====================================================================
        # TODO: MODIFY THIS TO MATCH YOUR RESPONSE FORMAT
        # =====================================================================
        
        # Try OpenAI-style first
        try:
            choices = response_data.get("choices", [])
            if choices:
                return str(choices[0]["message"]["content"])
        except (KeyError, IndexError, TypeError):
            pass
        
        # Try Anthropic-style
        try:
            content = response_data.get("content", [])
            if content:
                return str(content[0]["text"])
        except (KeyError, IndexError, TypeError):
            pass
        
        # Try common simple formats
        for field in ["generated_text", "text", "response", "output", "result"]:
            if field in response_data:
                value = response_data[field]
                if isinstance(value, str):
                    return value
        
        # Fallback: return string representation
        logger.warning(f"Could not parse response: {response_data}")
        return str(response_data)
    
    # =========================================================================
    # ERROR HANDLING (usually no need to modify)
    # =========================================================================
    
    def _handle_error(self, response: httpx.Response) -> None:
        """Handle error responses from the API."""
        try:
            error_data = response.json()
            error_msg = (
                error_data.get("error", {}).get("message")
                or error_data.get("message")
                or error_data.get("detail")
                or str(error_data)
            )
        except Exception:
            error_msg = response.text[:500] if response.text else "Unknown error"
        
        logger.error(f"API error {response.status_code}: {error_msg}")
        
        raise httpx.HTTPStatusError(
            f"Model server error ({response.status_code}): {error_msg}",
            request=response.request,
            response=response,
        )
    
    # =========================================================================
    # CORE GENERATION METHODS (usually no need to modify)
    # =========================================================================
    
    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        Generate a response synchronously.
        
        Called by LangChain when you use:
            llm.invoke([...])
        """
        body = self._build_request_body(messages)
        
        if stop:
            body["stop"] = stop
        body.update(kwargs)
        
        logger.debug(f"Request to {self._get_endpoint()}")
        
        client = self._get_sync_client()
        response = client.post(
            self._get_endpoint(),
            headers=self._get_headers(),
            json=body,
        )
        
        if not response.is_success:
            self._handle_error(response)
        
        response_data = response.json()
        content = self._parse_response(response_data)
        
        message = AIMessage(content=content)
        generation = ChatGeneration(message=message)
        return ChatResult(generations=[generation])
    
    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """
        Generate a response asynchronously.
        
        Called by LangChain when you use:
            await llm.ainvoke([...])
        """
        body = self._build_request_body(messages)
        
        if stop:
            body["stop"] = stop
        body.update(kwargs)
        
        logger.debug(f"Async request to {self._get_endpoint()}")
        
        client = self._get_async_client()
        response = await client.post(
            self._get_endpoint(),
            headers=self._get_headers(),
            json=body,
        )
        
        if not response.is_success:
            self._handle_error(response)
        
        response_data = response.json()
        content = self._parse_response(response_data)
        
        message = AIMessage(content=content)
        generation = ChatGeneration(message=message)
        return ChatResult(generations=[generation])
    
    def __del__(self):
        """Cleanup HTTP clients."""
        if self._sync_client:
            try:
                self._sync_client.close()
            except Exception:
                pass


# =============================================================================
# LLM WITH AUTOMATIC RETRY
# =============================================================================

class CustomModelServerLLMWithRetry(CustomModelServerLLM):
    """
    Same as CustomModelServerLLM but with automatic retry on failures.
    
    Retries on:
        - Connection errors
        - Timeouts
        - 429 Too Many Requests (rate limiting)
        - 5xx Server errors
    
    Does NOT retry on:
        - 4xx Client errors (except 429)
    """
    
    max_retries: int = Field(
        default=3,
        description="Maximum retry attempts",
    )
    retry_delay: float = Field(
        default=1.0,
        description="Initial delay between retries (seconds)",
    )
    retry_multiplier: float = Field(
        default=2.0,
        description="Multiply delay after each retry (exponential backoff)",
    )
    
    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Generate with automatic retry."""
        import time
        
        last_error: Optional[Exception] = None
        delay = self.retry_delay
        
        for attempt in range(self.max_retries + 1):
            try:
                return super()._generate(messages, stop, run_manager, **kwargs)
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if 400 <= status < 500 and status != 429:
                    raise  # Don't retry client errors
                last_error = e
                logger.warning(f"Attempt {attempt + 1} failed: {status}")
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_error = e
                logger.warning(f"Attempt {attempt + 1} failed: {type(e).__name__}")
            
            if attempt < self.max_retries:
                logger.info(f"Retrying in {delay:.1f}s...")
                time.sleep(delay)
                delay *= self.retry_multiplier
        
        raise last_error  # type: ignore
    
    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Generate with automatic retry (async)."""
        import asyncio
        
        last_error: Optional[Exception] = None
        delay = self.retry_delay
        
        for attempt in range(self.max_retries + 1):
            try:
                return await super()._agenerate(messages, stop, run_manager, **kwargs)
            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                if 400 <= status < 500 and status != 429:
                    raise
                last_error = e
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_error = e
            
            if attempt < self.max_retries:
                await asyncio.sleep(delay)
                delay *= self.retry_multiplier
        
        raise last_error  # type: ignore


# =============================================================================
# FACTORY FUNCTION
# =============================================================================

def create_llm(
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs,
) -> CustomModelServerLLM:
    """
    Create an LLM instance with configuration from parameters or environment.
    
    Configuration priority:
        1. Explicit parameters
        2. Environment variables
        3. Defaults
    
    Args:
        base_url: Model server URL (or LLM_BASE_URL env var)
        api_key: API key (or LLM_API_KEY env var)
        model: Model name (or MODEL_NAME env var)
        **kwargs: Additional arguments
    
    Returns:
        Configured LLM instance with retry support
    
    Example:
        >>> llm = create_llm()  # From environment
        >>> llm = create_llm(base_url="https://...", api_key="...")
    """
    config: Dict[str, Any] = {}
    
    if base_url:
        config["base_url"] = base_url
    if api_key:
        config["api_key"] = api_key
    if model:
        config["model"] = model
    
    config.update(kwargs)
    
    return CustomModelServerLLMWithRetry(**config)


# =============================================================================
# TESTING
# =============================================================================

if __name__ == "__main__":
    """
    Test your LLM configuration.
    
    Usage:
        export LLM_BASE_URL=https://your-server.com
        export LLM_API_KEY=your-key
        python -m agent.llm_custom
    """
    import asyncio
    import sys
    
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    
    print("=" * 60)
    print("Custom LLM Configuration Test")
    print("=" * 60)
    print()
    print("Environment:")
    print(f"  LLM_BASE_URL: {os.getenv('LLM_BASE_URL', '(not set)')}")
    print(f"  LLM_API_KEY:  {'*****' if os.getenv('LLM_API_KEY') else '(not set)'}")
    print(f"  MODEL_NAME:   {os.getenv('MODEL_NAME', '(not set)')}")
    print()
    
    if not os.getenv("LLM_BASE_URL"):
        print("ERROR: LLM_BASE_URL is not set!")
        print()
        print("Please configure your model server:")
        print("  export LLM_BASE_URL=https://your-model-server.com")
        print("  export LLM_API_KEY=your-api-key")
        print()
        print("Then customize this file to match your API format.")
        sys.exit(1)
    
    async def run_tests():
        try:
            llm = create_llm()
            
            # Test 1: Sync
            print("-" * 40)
            print("Test 1: Synchronous call")
            print("-" * 40)
            response = llm.invoke([
                HumanMessage(content="Say exactly: 'Sync test OK'")
            ])
            print(f"Response: {response.content}")
            print("✓ Passed\n")
            
            # Test 2: Async
            print("-" * 40)
            print("Test 2: Asynchronous call")
            print("-" * 40)
            response = await llm.ainvoke([
                HumanMessage(content="Say exactly: 'Async test OK'")
            ])
            print(f"Response: {response.content}")
            print("✓ Passed\n")
            
            # Test 3: System message
            print("-" * 40)
            print("Test 3: System + User messages")
            print("-" * 40)
            response = await llm.ainvoke([
                SystemMessage(content="You are a helpful assistant. Be very brief."),
                HumanMessage(content="What is 2+2?"),
            ])
            print(f"Response: {response.content}")
            print("✓ Passed\n")
            
            print("=" * 60)
            print("✓ ALL TESTS PASSED!")
            print("=" * 60)
            print()
            print("Your LLM is configured correctly.")
            print("You can now use it with the SRE Agent:")
            print()
            print("  from agent import SREAgentSimple")
            print("  agent = SREAgentSimple()")
            print("  result = await agent.chat('Hello!')")
            
        except Exception as e:
            print()
            print("=" * 60)
            print("✗ TEST FAILED")
            print("=" * 60)
            print(f"Error: {e}")
            print()
            print("Troubleshooting:")
            print("1. Check LLM_BASE_URL is correct")
            print("2. Check LLM_API_KEY is valid")
            print("3. Customize _get_endpoint() for your API path")
            print("4. Customize _get_headers() for your auth method")
            print("5. Customize _parse_response() for your response format")
            sys.exit(1)
    
    asyncio.run(run_tests())
