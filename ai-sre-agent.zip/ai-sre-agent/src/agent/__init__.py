"""
AI SRE Agent - Core Package
===========================

This package provides the AI-powered SRE agent for incident management
and support triage.

Quick Start:
    >>> from agent import SREAgentSimple
    >>> agent = SREAgentSimple()
    >>> result = await agent.chat("What causes connection pool exhaustion?")

For synchronous usage:
    >>> from agent.local import run_chat
    >>> result = run_chat("What causes connection pool exhaustion?")

Exports:
    - SREAgentSimple: Main agent class
    - SREAgent: Alias for SREAgentSimple
    - SRE_AGENT_SYSTEM_PROMPT: The system prompt used by the agent
    - create_llm: Factory function to create LLM instance
    - IncidentKnowledgeBase: RAG for incidents
    - RunbookStore: RAG for runbooks
"""

__version__ = "0.3.0"

# =============================================================================
# Core Agent
# =============================================================================

from .agent import SREAgentSimple

# Backwards compatibility alias
SREAgent = SREAgentSimple

# =============================================================================
# Prompts
# =============================================================================

from .prompts import SRE_AGENT_SYSTEM_PROMPT

# =============================================================================
# Custom LLM
# =============================================================================

try:
    from .llm_custom import (
        CustomModelServerLLM,
        CustomModelServerLLMWithRetry,
        create_llm,
    )
except ImportError:
    # httpx not installed
    CustomModelServerLLM = None  # type: ignore
    CustomModelServerLLMWithRetry = None  # type: ignore
    create_llm = None  # type: ignore

# =============================================================================
# RAG
# =============================================================================

try:
    from .rag import (
        IncidentKnowledgeBase,
        RunbookStore,
        get_default_data_dir,
    )
except ImportError:
    # chromadb not installed
    IncidentKnowledgeBase = None  # type: ignore
    RunbookStore = None  # type: ignore
    get_default_data_dir = None  # type: ignore

# =============================================================================
# Sync Helpers (for scripts)
# =============================================================================

try:
    from .local import (
        run_chat,
        run_summarize,
        run_triage,
        run_rca,
    )
except ImportError:
    run_chat = None  # type: ignore
    run_summarize = None  # type: ignore
    run_triage = None  # type: ignore
    run_rca = None  # type: ignore

# =============================================================================
# MCP Client (for sidecar communication)
# =============================================================================

try:
    from .mcp_client import (
        MCPClientManager,
        MCPConnection,
        MCPServerConfig,
        MCPError,
    )
except ImportError:
    MCPClientManager = None  # type: ignore
    MCPConnection = None  # type: ignore
    MCPServerConfig = None  # type: ignore
    MCPError = None  # type: ignore

# =============================================================================
# Public API
# =============================================================================

__all__ = [
    # Version
    "__version__",
    # Core
    "SREAgentSimple",
    "SREAgent",
    "SRE_AGENT_SYSTEM_PROMPT",
    # LLM
    "CustomModelServerLLM",
    "CustomModelServerLLMWithRetry",
    "create_llm",
    # RAG
    "IncidentKnowledgeBase",
    "RunbookStore",
    "get_default_data_dir",
    # Sync helpers
    "run_chat",
    "run_summarize",
    "run_triage",
    "run_rca",
    # MCP client
    "MCPClientManager",
    "MCPConnection",
    "MCPServerConfig",
    "MCPError",
]
