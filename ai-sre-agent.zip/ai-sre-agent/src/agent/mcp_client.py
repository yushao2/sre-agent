"""
MCP Client
==========

Client for connecting to MCP servers from the SRE agent.

Supports two transport modes:
1. **Subprocess (stdio)**: For local development - spawns MCP server as subprocess
2. **Unix Socket**: For Kubernetes - connects to sidecar via Unix socket

The mode is auto-detected based on environment variables:
- MCP_JIRA_SOCKET=/sockets/jira.sock → Unix socket mode
- No socket env var → Subprocess mode

Usage:
    from agent.mcp_client import MCPClientManager
    
    async with MCPClientManager() as manager:
        # Call Jira tools
        result = await manager.call_tool("jira", "search_issues", {
            "jql": "project = INC ORDER BY created DESC"
        })
        
        # List available tools
        tools = await manager.list_tools("jira")

Architecture (Kubernetes):
    ┌─────────────────────────────────────────────────────────────┐
    │                         Kubernetes Pod                       │
    │                                                              │
    │  ┌────────────────┐  Unix Socket  ┌─────────────────────┐  │
    │  │  SRE Agent     │◄─────────────►│  MCP Server Sidecar │  │
    │  │  (this client) │               │  (Jira/Conf/GitLab) │  │
    │  └────────────────┘               └─────────────────────┘  │
    │                                                              │
    └─────────────────────────────────────────────────────────────┘
"""

import asyncio
import json
import logging
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class MCPServerConfig:
    """Configuration for an MCP server connection."""
    name: str
    socket_path: Optional[str] = None  # For Kubernetes
    command: Optional[List[str]] = None  # For local subprocess
    env: Optional[Dict[str, str]] = None  # Environment variables


class MCPConnection:
    """
    A connection to a single MCP server.
    
    Handles both subprocess (stdio) and Unix socket transports.
    """
    
    def __init__(self, config: MCPServerConfig):
        self.config = config
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._process: Optional[asyncio.subprocess.Process] = None
        self._request_id = 0
        self._connected = False
    
    async def connect(self):
        """Establish connection to the MCP server."""
        if self._connected:
            return
        
        if self.config.socket_path:
            await self._connect_socket()
        elif self.config.command:
            await self._connect_subprocess()
        else:
            raise ValueError(f"No socket_path or command configured for {self.config.name}")
        
        self._connected = True
        logger.info(f"Connected to MCP server: {self.config.name}")
        
        # Initialize the MCP connection
        await self._initialize()
    
    async def _connect_socket(self):
        """Connect via Unix socket."""
        socket_path = self.config.socket_path
        logger.debug(f"Connecting to Unix socket: {socket_path}")
        
        # Wait for socket to be available (sidecar startup)
        for attempt in range(30):
            if Path(socket_path).exists():
                break
            logger.debug(f"Waiting for socket {socket_path} (attempt {attempt + 1})")
            await asyncio.sleep(1)
        else:
            raise ConnectionError(f"Socket not available after 30s: {socket_path}")
        
        self._reader, self._writer = await asyncio.open_unix_connection(socket_path)
    
    async def _connect_subprocess(self):
        """Connect via subprocess stdio."""
        command = self.config.command
        env = {**os.environ, **(self.config.env or {})}
        
        logger.debug(f"Starting subprocess: {' '.join(command)}")
        
        self._process = await asyncio.create_subprocess_exec(
            *command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )
        
        self._reader = self._process.stdout
        self._writer = self._process.stdin
    
    async def _initialize(self):
        """Send MCP initialize request."""
        response = await self._request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "ai-sre-agent",
                "version": "0.3.0",
            },
        })
        
        logger.debug(f"MCP initialized: {response}")
        
        # Send initialized notification
        await self._notify("notifications/initialized", {})
    
    async def _request(self, method: str, params: Dict[str, Any]) -> Any:
        """Send a JSON-RPC request and wait for response."""
        self._request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params,
        }
        
        await self._send(request)
        response = await self._receive()
        
        if "error" in response:
            raise MCPError(response["error"])
        
        return response.get("result")
    
    async def _notify(self, method: str, params: Dict[str, Any]):
        """Send a JSON-RPC notification (no response expected)."""
        notification = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }
        await self._send(notification)
    
    async def _send(self, message: Dict[str, Any]):
        """Send a message to the MCP server."""
        data = json.dumps(message)
        # MCP uses newline-delimited JSON
        self._writer.write(f"{data}\n".encode())
        await self._writer.drain()
    
    async def _receive(self) -> Dict[str, Any]:
        """Receive a message from the MCP server."""
        line = await self._reader.readline()
        if not line:
            raise ConnectionError("MCP server closed connection")
        return json.loads(line.decode())
    
    async def list_tools(self) -> List[Dict[str, Any]]:
        """List available tools from this MCP server."""
        result = await self._request("tools/list", {})
        return result.get("tools", [])
    
    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        """Call a tool on this MCP server."""
        result = await self._request("tools/call", {
            "name": name,
            "arguments": arguments,
        })
        
        # Extract content from result
        content = result.get("content", [])
        if content and content[0].get("type") == "text":
            # Parse JSON response
            text = content[0].get("text", "{}")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                return {"text": text}
        
        return result
    
    async def close(self):
        """Close the connection."""
        if self._writer:
            self._writer.close()
            try:
                await self._writer.wait_closed()
            except Exception:
                pass
        
        if self._process:
            self._process.terminate()
            try:
                await asyncio.wait_for(self._process.wait(), timeout=5)
            except asyncio.TimeoutError:
                self._process.kill()
        
        self._connected = False
        logger.info(f"Disconnected from MCP server: {self.config.name}")


class MCPError(Exception):
    """Error from MCP server."""
    
    def __init__(self, error: Dict[str, Any]):
        self.code = error.get("code", -1)
        self.message = error.get("message", "Unknown error")
        self.data = error.get("data")
        super().__init__(f"MCP Error {self.code}: {self.message}")


class MCPClientManager:
    """
    Manages connections to multiple MCP servers.
    
    Auto-detects transport mode (socket vs subprocess) based on environment.
    
    Environment Variables:
        MCP_JIRA_SOCKET: Path to Jira MCP Unix socket
        MCP_CONFLUENCE_SOCKET: Path to Confluence MCP Unix socket
        MCP_GITLAB_SOCKET: Path to GitLab MCP Unix socket
    
    Usage:
        async with MCPClientManager() as manager:
            # List tools
            tools = await manager.list_tools("jira")
            
            # Call tool
            result = await manager.call_tool("jira", "search_issues", {
                "jql": "project = INC"
            })
    """
    
    # Default subprocess commands for local development
    DEFAULT_COMMANDS = {
        "jira": ["mcp-jira"],
        "confluence": ["mcp-confluence"],
        "gitlab": ["mcp-gitlab"],
    }
    
    def __init__(
        self,
        servers: Optional[Dict[str, MCPServerConfig]] = None,
        auto_connect: bool = True,
    ):
        """
        Initialize the MCP client manager.
        
        Args:
            servers: Custom server configurations. If None, auto-detects from env.
            auto_connect: Whether to auto-connect on __aenter__
        """
        self.servers = servers or self._detect_servers()
        self.auto_connect = auto_connect
        self._connections: Dict[str, MCPConnection] = {}
    
    def _detect_servers(self) -> Dict[str, MCPServerConfig]:
        """Auto-detect MCP server configurations from environment."""
        servers = {}
        
        # Check for Jira
        jira_socket = os.getenv("MCP_JIRA_SOCKET")
        if jira_socket:
            servers["jira"] = MCPServerConfig(
                name="jira",
                socket_path=jira_socket,
            )
        elif os.getenv("JIRA_URL"):  # Only enable if Jira is configured
            servers["jira"] = MCPServerConfig(
                name="jira",
                command=self.DEFAULT_COMMANDS["jira"],
            )
        
        # Check for Confluence
        confluence_socket = os.getenv("MCP_CONFLUENCE_SOCKET")
        if confluence_socket:
            servers["confluence"] = MCPServerConfig(
                name="confluence",
                socket_path=confluence_socket,
            )
        elif os.getenv("CONFLUENCE_URL"):
            servers["confluence"] = MCPServerConfig(
                name="confluence",
                command=self.DEFAULT_COMMANDS["confluence"],
            )
        
        # Check for GitLab
        gitlab_socket = os.getenv("MCP_GITLAB_SOCKET")
        if gitlab_socket:
            servers["gitlab"] = MCPServerConfig(
                name="gitlab",
                socket_path=gitlab_socket,
            )
        elif os.getenv("GITLAB_URL"):
            servers["gitlab"] = MCPServerConfig(
                name="gitlab",
                command=self.DEFAULT_COMMANDS["gitlab"],
            )
        
        return servers
    
    async def __aenter__(self):
        """Connect to all configured servers."""
        if self.auto_connect:
            await self.connect_all()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Disconnect from all servers."""
        await self.close_all()
    
    async def connect(self, server_name: str):
        """Connect to a specific MCP server."""
        if server_name in self._connections:
            return
        
        config = self.servers.get(server_name)
        if not config:
            raise ValueError(f"Unknown MCP server: {server_name}")
        
        connection = MCPConnection(config)
        await connection.connect()
        self._connections[server_name] = connection
    
    async def connect_all(self):
        """Connect to all configured servers."""
        for name in self.servers:
            try:
                await self.connect(name)
            except Exception as e:
                logger.warning(f"Failed to connect to {name}: {e}")
    
    async def close_all(self):
        """Close all connections."""
        for connection in self._connections.values():
            try:
                await connection.close()
            except Exception as e:
                logger.warning(f"Error closing {connection.config.name}: {e}")
        self._connections.clear()
    
    async def list_tools(self, server_name: str) -> List[Dict[str, Any]]:
        """List tools available from a specific server."""
        connection = self._connections.get(server_name)
        if not connection:
            raise ValueError(f"Not connected to: {server_name}")
        return await connection.list_tools()
    
    async def list_all_tools(self) -> Dict[str, List[Dict[str, Any]]]:
        """List tools from all connected servers."""
        result = {}
        for name, connection in self._connections.items():
            try:
                result[name] = await connection.list_tools()
            except Exception as e:
                logger.warning(f"Failed to list tools from {name}: {e}")
                result[name] = []
        return result
    
    async def call_tool(
        self,
        server_name: str,
        tool_name: str,
        arguments: Dict[str, Any],
    ) -> Any:
        """
        Call a tool on a specific MCP server.
        
        Args:
            server_name: Name of the MCP server (jira, confluence, gitlab)
            tool_name: Name of the tool to call
            arguments: Tool arguments
        
        Returns:
            Tool result (parsed JSON)
        """
        connection = self._connections.get(server_name)
        if not connection:
            raise ValueError(f"Not connected to: {server_name}")
        return await connection.call_tool(tool_name, arguments)
    
    def is_connected(self, server_name: str) -> bool:
        """Check if connected to a specific server."""
        return server_name in self._connections
