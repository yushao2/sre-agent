"""
SRE Agent - Agentic Implementation
==================================

An AI agent that can autonomously use tools to investigate incidents.

AUTOMATIC FEATURES:
- RAG: Searches past incidents for context (if chromadb installed)
- MCP: Automatically starts and manages Jira/Confluence/GitLab servers
- Tool Calling: LLM decides when to query external systems

LOCAL DEVELOPMENT:
    # 1. Configure your LLM
    export LLM_BASE_URL=https://your-llm-server.com
    export LLM_API_KEY=your-key
    
    # 2. Configure external systems (optional - agent works without them)
    export JIRA_URL=https://jira.company.com
    export JIRA_USERNAME=you
    export JIRA_TOKEN=your-pat
    
    # 3. Run
    uv run python -m agent.local interactive

The agent will:
- Auto-start MCP servers as subprocesses when needed
- Let the LLM decide when to search Jira/Confluence/GitLab
- Use RAG to find similar past incidents
- Store incidents for future reference
"""

import asyncio
import json
import logging
import os
from typing import Any, Dict, List, Optional, Union, Callable

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from .prompts import (
    SRE_AGENT_SYSTEM_PROMPT,
    format_incident_prompt,
    format_triage_prompt,
    format_rca_prompt,
)

logger = logging.getLogger(__name__)


# =============================================================================
# TOOL DEFINITIONS
# =============================================================================

TOOL_DEFINITIONS = [
    {
        "name": "search_jira",
        "description": "Search Jira for issues using JQL. Use this to find incidents, tickets, or any Jira issues.",
        "parameters": {
            "type": "object",
            "properties": {
                "jql": {
                    "type": "string",
                    "description": "JQL query string. Examples: 'project = INC ORDER BY created DESC', 'status = Open AND priority = Critical'"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum results to return (default: 10)",
                    "default": 10
                }
            },
            "required": ["jql"]
        }
    },
    {
        "name": "get_jira_issue",
        "description": "Get details of a specific Jira issue by key. Use this when you know the issue ID.",
        "parameters": {
            "type": "object",
            "properties": {
                "issue_key": {
                    "type": "string",
                    "description": "The Jira issue key (e.g., 'INC-123', 'SUPPORT-456')"
                }
            },
            "required": ["issue_key"]
        }
    },
    {
        "name": "search_confluence",
        "description": "Search Confluence for documentation, runbooks, or knowledge base articles.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query text"
                },
                "space_key": {
                    "type": "string",
                    "description": "Optional: Limit to specific Confluence space (e.g., 'OPS', 'RUNBOOKS')"
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_confluence_page",
        "description": "Get the content of a specific Confluence page.",
        "parameters": {
            "type": "object",
            "properties": {
                "page_id": {
                    "type": "string",
                    "description": "The Confluence page ID"
                }
            },
            "required": ["page_id"]
        }
    },
    {
        "name": "search_gitlab_projects",
        "description": "Search GitLab for projects/repositories.",
        "parameters": {
            "type": "object",
            "properties": {
                "search": {
                    "type": "string",
                    "description": "Search query for project names"
                }
            },
            "required": ["search"]
        }
    },
    {
        "name": "list_merge_requests",
        "description": "List recent merge requests for a GitLab project. Useful for finding recent code changes.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_id": {
                    "type": "integer",
                    "description": "GitLab project ID"
                },
                "state": {
                    "type": "string",
                    "description": "MR state: 'opened', 'merged', 'closed', 'all'",
                    "default": "merged"
                }
            },
            "required": ["project_id"]
        }
    },
    {
        "name": "search_similar_incidents",
        "description": "Search the local knowledge base for similar past incidents. Use this to find historical context.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Description of the incident or symptoms to search for"
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default: 5)",
                    "default": 5
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "search_runbooks",
        "description": "Search the local runbook store for relevant procedures and documentation.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Topic or issue to find runbooks for"
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default: 3)",
                    "default": 3
                }
            },
            "required": ["query"]
        }
    },
]


# =============================================================================
# SRE AGENT
# =============================================================================

class SREAgent:
    """
    Agentic SRE Assistant with automatic tool use.
    
    The agent can autonomously:
    - Search Jira for incidents and tickets
    - Query Confluence for documentation
    - Check GitLab for recent code changes
    - Search past incidents in local RAG
    - Look up runbooks
    
    MCP servers are started automatically as subprocesses when needed.
    
    Example:
        >>> agent = SREAgent()
        >>> 
        >>> # Agent will automatically search Jira, check similar incidents, etc.
        >>> result = await agent.investigate("INC-123 - Database connection timeouts")
        >>> print(result)
    """
    
    def __init__(
        self,
        llm: Optional[BaseChatModel] = None,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        model_name: str = "default-model",
        max_tokens: int = 4096,
        temperature: float = 0.0,
        verify_ssl: bool = True,
        timeout: float = 120.0,
        enable_rag: Optional[bool] = None,
        rag_data_dir: Optional[str] = None,
        enable_mcp: Optional[bool] = None,
        max_tool_iterations: int = 10,
    ):
        """
        Initialize the SRE Agent.
        
        Args:
            llm: Pre-configured LangChain chat model (optional)
            base_url: LLM server URL. Falls back to LLM_BASE_URL env var.
            api_key: API key. Falls back to LLM_API_KEY env var.
            model_name: Model identifier. Falls back to MODEL_NAME env var.
            enable_rag: Enable RAG. None = auto (enabled if chromadb available).
            rag_data_dir: RAG data directory.
            enable_mcp: Enable MCP tools. None = auto (enabled if any MCP env vars set).
            max_tool_iterations: Max tool-calling loops before stopping.
        """
        # Initialize LLM
        if llm is not None:
            self.llm = llm
            self.model_name = getattr(llm, "model", model_name)
        else:
            from .llm_custom import create_llm
            
            effective_base_url = base_url or os.getenv("LLM_BASE_URL")
            if not effective_base_url:
                raise ValueError(
                    "LLM_BASE_URL is not configured. "
                    "Set the LLM_BASE_URL environment variable or pass base_url parameter."
                )
            
            effective_model = model_name
            if model_name == "default-model":
                effective_model = os.getenv("MODEL_NAME", model_name)
            
            self.llm = create_llm(
                base_url=effective_base_url,
                api_key=api_key,
                model=effective_model,
                max_tokens=max_tokens,
                temperature=temperature,
                verify_ssl=verify_ssl,
                timeout=timeout,
            )
            self.model_name = effective_model
        
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.max_tool_iterations = max_tool_iterations
        
        # Initialize RAG
        self.incident_kb = None
        self.runbook_store = None
        self.rag_enabled = False
        self._init_rag(enable_rag, rag_data_dir)
        
        # Initialize MCP
        self.mcp_manager = None
        self.mcp_enabled = False
        self._mcp_initialized = False
        self._init_mcp(enable_mcp)
        
        # Build available tools
        self._tools = self._build_tools()
        
        logger.info(f"SREAgent initialized: RAG={self.rag_enabled}, MCP={self.mcp_enabled}")
    
    def _init_rag(self, enable_rag: Optional[bool], rag_data_dir: Optional[str]):
        """Initialize RAG components."""
        env_rag = os.getenv("RAG_ENABLED", "").lower()
        if env_rag == "false" or enable_rag is False:
            logger.info("RAG disabled")
            return
        
        try:
            from .rag import IncidentKnowledgeBase, RunbookStore, get_default_data_dir
            
            data_path = rag_data_dir or os.getenv("SRE_AGENT_DATA_DIR") or get_default_data_dir()
            
            self.incident_kb = IncidentKnowledgeBase(
                persist_directory=os.path.join(data_path, "incidents")
            )
            self.runbook_store = RunbookStore(
                persist_directory=os.path.join(data_path, "runbooks")
            )
            self.rag_enabled = True
            
            logger.info(f"RAG enabled: {self.incident_kb.count()} incidents, {self.runbook_store.count()} runbooks")
            
        except ImportError as e:
            logger.info(f"RAG not available (install chromadb): {e}")
        except Exception as e:
            logger.warning(f"RAG init failed: {e}")
    
    def _init_mcp(self, enable_mcp: Optional[bool]):
        """Initialize MCP configuration."""
        if enable_mcp is False:
            logger.info("MCP disabled")
            return
        
        # Check if any MCP services are configured
        self._has_jira = bool(os.getenv("JIRA_URL"))
        self._has_confluence = bool(os.getenv("CONFLUENCE_URL"))
        self._has_gitlab = bool(os.getenv("GITLAB_URL"))
        
        if not (self._has_jira or self._has_confluence or self._has_gitlab):
            logger.info("MCP: No external services configured (set JIRA_URL, CONFLUENCE_URL, or GITLAB_URL)")
            return
        
        self.mcp_enabled = True
        logger.info(f"MCP enabled: Jira={self._has_jira}, Confluence={self._has_confluence}, GitLab={self._has_gitlab}")
    
    async def connect_mcp(self):
        """
        Eagerly connect to MCP servers.
        
        Call this at startup to ensure MCP servers are running before
        handling requests. This is optional - servers will also be
        started lazily on first tool call.
        """
        if not self.mcp_enabled:
            logger.info("MCP not enabled, skipping connection")
            return False
        
        if self._mcp_initialized:
            logger.info("MCP already connected")
            return True
        
        try:
            from .mcp_client import MCPClientManager
            self.mcp_manager = MCPClientManager()
            await self.mcp_manager.connect_all()
            self._mcp_initialized = True
            
            # Log which servers connected
            connected = []
            if self._has_jira and self.mcp_manager.is_connected("jira"):
                connected.append("Jira")
            if self._has_confluence and self.mcp_manager.is_connected("confluence"):
                connected.append("Confluence")
            if self._has_gitlab and self.mcp_manager.is_connected("gitlab"):
                connected.append("GitLab")
            
            logger.info(f"MCP servers connected: {', '.join(connected) or 'none'}")
            return True
        except Exception as e:
            logger.warning(f"MCP connection failed: {e}")
            self.mcp_enabled = False
            return False
    
    async def _ensure_mcp_connected(self):
        """Lazily connect to MCP servers when first needed."""
        if self._mcp_initialized or not self.mcp_enabled:
            return
        
        await self.connect_mcp()
    
    def _build_tools(self) -> Dict[str, Callable]:
        """Build the tool function registry."""
        return {
            "search_jira": self._tool_search_jira,
            "get_jira_issue": self._tool_get_jira_issue,
            "search_confluence": self._tool_search_confluence,
            "get_confluence_page": self._tool_get_confluence_page,
            "search_gitlab_projects": self._tool_search_gitlab,
            "list_merge_requests": self._tool_list_mrs,
            "search_similar_incidents": self._tool_search_incidents,
            "search_runbooks": self._tool_search_runbooks,
        }
    
    def _get_available_tools(self) -> List[Dict]:
        """Get tool definitions for tools that are currently available."""
        available = []
        
        for tool_def in TOOL_DEFINITIONS:
            name = tool_def["name"]
            
            # RAG tools - always available if RAG enabled
            if name in ["search_similar_incidents", "search_runbooks"]:
                if self.rag_enabled:
                    available.append(tool_def)
                continue
            
            # Jira tools
            if name in ["search_jira", "get_jira_issue"]:
                if os.getenv("JIRA_URL"):
                    available.append(tool_def)
                continue
            
            # Confluence tools
            if name in ["search_confluence", "get_confluence_page"]:
                if os.getenv("CONFLUENCE_URL"):
                    available.append(tool_def)
                continue
            
            # GitLab tools
            if name in ["search_gitlab_projects", "list_merge_requests"]:
                if os.getenv("GITLAB_URL"):
                    available.append(tool_def)
                continue
        
        return available
    
    # =========================================================================
    # TOOL IMPLEMENTATIONS
    # =========================================================================
    
    async def _tool_search_jira(self, jql: str, max_results: int = 10) -> str:
        """Search Jira using JQL."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("jira"):
            return json.dumps({"error": "Jira not connected"})
        
        try:
            result = await self.mcp_manager.call_tool("jira", "search_issues", {
                "jql": jql,
                "max_results": max_results,
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_get_jira_issue(self, issue_key: str) -> str:
        """Get Jira issue details."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("jira"):
            return json.dumps({"error": "Jira not connected"})
        
        try:
            result = await self.mcp_manager.call_tool("jira", "get_issue", {
                "issue_key": issue_key,
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_search_confluence(self, query: str, space_key: str = None) -> str:
        """Search Confluence."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("confluence"):
            return json.dumps({"error": "Confluence not connected"})
        
        try:
            args = {"query": query}
            if space_key:
                args["space_key"] = space_key
            result = await self.mcp_manager.call_tool("confluence", "search_pages", args)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_get_confluence_page(self, page_id: str) -> str:
        """Get Confluence page content."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("confluence"):
            return json.dumps({"error": "Confluence not connected"})
        
        try:
            result = await self.mcp_manager.call_tool("confluence", "get_page", {
                "page_id": page_id,
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_search_gitlab(self, search: str) -> str:
        """Search GitLab projects."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("gitlab"):
            return json.dumps({"error": "GitLab not connected"})
        
        try:
            result = await self.mcp_manager.call_tool("gitlab", "list_projects", {
                "search": search,
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_list_mrs(self, project_id: int, state: str = "merged") -> str:
        """List GitLab merge requests."""
        await self._ensure_mcp_connected()
        if not self.mcp_manager or not self.mcp_manager.is_connected("gitlab"):
            return json.dumps({"error": "GitLab not connected"})
        
        try:
            result = await self.mcp_manager.call_tool("gitlab", "list_merge_requests", {
                "project_id": project_id,
                "state": state,
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_search_incidents(self, query: str, limit: int = 5) -> str:
        """Search similar incidents in RAG."""
        if not self.incident_kb:
            return json.dumps({"error": "Incident knowledge base not available"})
        
        try:
            results = self.incident_kb.search(query, k=limit)
            incidents = []
            for incident, score in results:
                incidents.append({
                    "key": incident.get("key"),
                    "summary": incident.get("summary"),
                    "root_cause": incident.get("root_cause"),
                    "resolution": incident.get("resolution"),
                    "similarity": round(score, 3),
                })
            return json.dumps({"incidents": incidents}, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _tool_search_runbooks(self, query: str, limit: int = 3) -> str:
        """Search runbooks in RAG."""
        if not self.runbook_store:
            return json.dumps({"error": "Runbook store not available"})
        
        try:
            results = self.runbook_store.search(query, k=limit)
            runbooks = []
            for rb, score in results:
                runbooks.append({
                    "title": rb.get("title"),
                    "content": rb.get("content", "")[:500] + "...",
                    "similarity": round(score, 3),
                })
            return json.dumps({"runbooks": runbooks}, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    async def _execute_tool(self, name: str, args: Dict[str, Any]) -> str:
        """Execute a tool by name."""
        tool_fn = self._tools.get(name)
        if not tool_fn:
            return json.dumps({"error": f"Unknown tool: {name}"})
        
        try:
            return await tool_fn(**args)
        except Exception as e:
            logger.error(f"Tool {name} failed: {e}")
            return json.dumps({"error": str(e)})
    
    # =========================================================================
    # AGENTIC LOOP
    # =========================================================================
    
    async def _run_agent_loop(
        self,
        initial_prompt: str,
        system_prompt: str = SRE_AGENT_SYSTEM_PROMPT,
    ) -> str:
        """
        Run the agentic loop with tool calling.
        
        The LLM can call tools, see results, and iterate until it has
        enough information to provide a final answer.
        """
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=initial_prompt),
        ]
        
        available_tools = self._get_available_tools()
        
        for iteration in range(self.max_tool_iterations):
            # Call LLM with tools
            response = await self._call_llm_with_tools(messages, available_tools)
            
            # Check if LLM wants to use tools
            tool_calls = self._extract_tool_calls(response)
            
            if not tool_calls:
                # No tool calls - return the response
                return self._extract_text_content(response)
            
            # Add assistant message with tool calls
            messages.append(AIMessage(content=response.content, additional_kwargs={"tool_calls": tool_calls}))
            
            # Execute tools and add results
            for tool_call in tool_calls:
                tool_name = tool_call.get("name")
                tool_args = tool_call.get("arguments", {})
                tool_id = tool_call.get("id", tool_name)
                
                logger.info(f"Executing tool: {tool_name}({tool_args})")
                result = await self._execute_tool(tool_name, tool_args)
                
                messages.append(ToolMessage(content=result, tool_call_id=tool_id))
        
        # Max iterations reached
        return "I've gathered information but reached the iteration limit. Here's what I found based on the tool results above."
    
    async def _call_llm_with_tools(self, messages: List, tools: List[Dict]) -> Any:
        """
        Call LLM with tool definitions injected into the prompt.
        
        We always use prompt-based tools (not native function calling) because:
        1. We're using local MCP servers
        2. Not all LLM servers support native tool calling
        3. Prompt-based works with any LLM
        """
        if not tools:
            return await self.llm.ainvoke(messages)
        
        return await self._call_llm_with_prompt_tools(messages, tools)
    
    async def _call_llm_with_prompt_tools(self, messages: List, tools: List[Dict]) -> Any:
        """Fallback: Inject tools into the prompt for LLMs without native tool support."""
        tools_text = "You have access to these tools:\n\n"
        for tool in tools:
            tools_text += f"**{tool['name']}**: {tool['description']}\n"
            tools_text += f"  Parameters: {json.dumps(tool['parameters']['properties'])}\n\n"
        
        tools_text += """
To use a tool, respond with a JSON block like:
```json
{"tool": "tool_name", "arguments": {"param": "value"}}
```

If you have enough information, respond with your final answer (no JSON block).
"""
        
        # Inject into system message
        modified_messages = messages.copy()
        if modified_messages and isinstance(modified_messages[0], SystemMessage):
            modified_messages[0] = SystemMessage(
                content=modified_messages[0].content + "\n\n" + tools_text
            )
        
        return await self.llm.ainvoke(modified_messages)
    
    def _extract_tool_calls(self, response: Any) -> List[Dict]:
        """Extract tool calls from LLM response."""
        # Check for native tool calls
        if hasattr(response, 'tool_calls') and response.tool_calls:
            return [
                {
                    "id": tc.get("id", tc.get("name")),
                    "name": tc.get("name"),
                    "arguments": tc.get("args", {}),
                }
                for tc in response.tool_calls
            ]
        
        # Check additional_kwargs
        if hasattr(response, 'additional_kwargs'):
            tool_calls = response.additional_kwargs.get("tool_calls", [])
            if tool_calls:
                return [
                    {
                        "id": tc.get("id", tc.get("function", {}).get("name")),
                        "name": tc.get("function", {}).get("name"),
                        "arguments": json.loads(tc.get("function", {}).get("arguments", "{}")),
                    }
                    for tc in tool_calls
                ]
        
        # Fallback: Parse JSON from content
        content = self._extract_text_content(response)
        if "```json" in content:
            try:
                json_start = content.find("```json") + 7
                json_end = content.find("```", json_start)
                json_str = content[json_start:json_end].strip()
                data = json.loads(json_str)
                if "tool" in data:
                    return [{
                        "id": data["tool"],
                        "name": data["tool"],
                        "arguments": data.get("arguments", {}),
                    }]
            except (json.JSONDecodeError, ValueError):
                pass
        
        return []
    
    def _extract_text_content(self, response: Any) -> str:
        """Extract text content from LLM response."""
        if hasattr(response, 'content'):
            return str(response.content)
        return str(response)
    
    # =========================================================================
    # PUBLIC API
    # =========================================================================
    
    async def investigate(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Investigate an incident or issue using all available tools.
        
        The agent will autonomously:
        - Search for similar past incidents
        - Query Jira for related issues
        - Check Confluence for runbooks
        - Look at recent code changes in GitLab
        
        Args:
            query: Description of the incident/issue to investigate
            context: Optional additional context
        
        Returns:
            Investigation findings and recommendations
        """
        prompt = f"""Please investigate the following:

{query}

Use the available tools to gather information:
1. Search for similar past incidents in the knowledge base
2. Search Jira for related issues or incidents
3. Look for relevant documentation in Confluence
4. Check GitLab for recent code changes if relevant

Provide a comprehensive analysis including:
- What you found from each source
- Potential root causes
- Recommended actions
- Related incidents or documentation
"""
        
        if context:
            prompt += f"\n\nAdditional context:\n```json\n{json.dumps(context, indent=2)}\n```"
        
        return await self._run_agent_loop(prompt)
    
    async def triage(
        self,
        request_data: Union[Dict[str, Any], str],
    ) -> str:
        """
        Triage an incoming request using available tools.
        
        Args:
            request_data: Request details (dict or raw text)
        
        Returns:
            Triage analysis with category, severity, recommendations
        """
        if isinstance(request_data, str):
            description = request_data
        else:
            description = f"""
Key: {request_data.get('key', 'N/A')}
Summary: {request_data.get('summary', 'N/A')}
Description: {request_data.get('description', request_data.get('message', 'N/A'))}
Source: {request_data.get('source', 'unknown')}
"""
        
        prompt = f"""Please triage the following request:

{description}

Use tools to gather context:
1. Search for similar past incidents
2. Check if this matches any known issues in Jira
3. Look for relevant runbooks

Then provide:
1. **Category**: incident, bug, support question, feature request, change request, other
2. **Severity**: critical, high, medium, low (with reasoning)
3. **Urgency**: Does this need immediate attention?
4. **Suggested Team**: Who should handle this
5. **Recommended Action**: What to do next
6. **Analysis**: Your assessment based on the gathered information
"""
        
        return await self._run_agent_loop(prompt)
    
    async def summarize_incident(
        self,
        incident_data: Union[Dict[str, Any], str],
    ) -> str:
        """
        Summarize an incident, optionally fetching additional context.
        
        Args:
            incident_data: Incident details (dict or raw text)
        
        Returns:
            Structured incident summary
        """
        if isinstance(incident_data, str):
            description = incident_data
            incident_key = None
        else:
            incident_key = incident_data.get("key")
            description = format_incident_prompt(incident_data)
        
        prompt = f"""Please summarize this incident:

{description}

Use tools to enrich your analysis:
1. Search for similar past incidents to identify patterns
2. {"Fetch the full incident details from Jira using key: " + incident_key if incident_key else ""}
3. Find relevant runbooks for this type of issue

Provide a structured summary:
1. **Executive Summary**: 2-3 sentences
2. **Timeline**: Key events
3. **Impact**: Who/what was affected
4. **Root Cause**: What caused it (if known)
5. **Resolution**: How it was/should be resolved
6. **Prevention**: How to prevent recurrence
"""
        
        result = await self._run_agent_loop(prompt)
        
        # Store in RAG for future searches
        if self.incident_kb and isinstance(incident_data, dict) and incident_data.get("key"):
            try:
                incident_data["_ai_summary"] = result[:1000]
                self.incident_kb.add_incident(incident_data)
            except Exception as e:
                logger.warning(f"Failed to store incident: {e}")
        
        return result
    
    async def analyze_root_cause(
        self,
        incident_data: Union[Dict[str, Any], str],
    ) -> str:
        """
        Perform root cause analysis.
        
        Args:
            incident_data: Incident details
        
        Returns:
            RCA with findings and recommendations
        """
        if isinstance(incident_data, str):
            description = incident_data
        else:
            description = format_rca_prompt(incident_data)
        
        prompt = f"""Perform a root cause analysis for this incident:

{description}

Gather evidence using tools:
1. Search for similar past incidents - look for patterns
2. Check GitLab for recent code changes that might be related
3. Find relevant documentation about the affected systems
4. Search Jira for related issues or known problems

Then provide:
1. **Primary Root Cause**: The main technical reason
2. **Contributing Factors**: Other factors that enabled/worsened it
3. **Evidence**: Cite specific findings from your tool searches
4. **Detection Gap**: Why wasn't this caught earlier?
5. **Immediate Fix**: What was done to resolve it
6. **Long-term Fix**: How to prevent recurrence
7. **Action Items**: Specific tasks with suggested owners
"""
        
        return await self._run_agent_loop(prompt)
    
    async def chat(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Free-form chat with tool access.
        
        Args:
            message: User's question
            context: Optional context
        
        Returns:
            Agent's response
        """
        prompt = message
        if context:
            prompt += f"\n\nContext:\n```json\n{json.dumps(context, indent=2)}\n```"
        
        return await self._run_agent_loop(prompt)
    
    async def close(self):
        """Clean up resources."""
        if self.mcp_manager:
            await self.mcp_manager.close_all()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


# Backwards compatibility
SREAgentSimple = SREAgent
