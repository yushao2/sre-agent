"""
SRE Agent - Core Implementation
===============================

This module provides the main SREAgentSimple class that powers the AI SRE Agent.

Usage:
    >>> from agent import SREAgentSimple
    >>> agent = SREAgentSimple()
    >>> 
    >>> # Summarize an incident
    >>> summary = await agent.summarize_incident_simple({
    ...     "key": "INC-123",
    ...     "summary": "Database connection timeout",
    ...     "description": "Users seeing 504 errors...",
    ... })
    >>> 
    >>> # Chat with the agent
    >>> response = await agent.chat("What causes connection pool exhaustion?")

Configuration:
    The agent reads LLM configuration from environment variables:
    - LLM_BASE_URL: Your model server URL (required)
    - LLM_API_KEY: API key for authentication
    - MODEL_NAME: Model identifier
    
    You must customize src/agent/llm_custom.py to match your API.
"""

import json
import os
from typing import Any, Dict, List, Optional, Union

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from .prompts import (
    SRE_AGENT_SYSTEM_PROMPT,
    format_incident_prompt,
    format_triage_prompt,
    format_rca_prompt,
)


class SREAgentSimple:
    """
    AI-powered SRE Agent for incident management and support triage.
    
    This agent provides methods for:
    - Incident summarization
    - Ticket triage
    - Root cause analysis
    - Interactive chat
    
    The agent uses your custom model server configured via environment
    variables. You must customize llm_custom.py to match your API.
    
    Attributes:
        llm: The underlying LangChain chat model
        model_name: Name/identifier of the model being used
        max_tokens: Maximum tokens in responses
        temperature: Sampling temperature
    
    Example:
        >>> # Create agent (reads config from environment)
        >>> agent = SREAgentSimple()
        >>> 
        >>> # Or with explicit configuration
        >>> agent = SREAgentSimple(
        ...     base_url="https://llm.company.com",
        ...     api_key="your-key",
        ... )
        >>> 
        >>> # Or bring your own LLM
        >>> agent = SREAgentSimple(llm=my_custom_llm)
    """
    
    def __init__(
        self,
        # Option 1: Pass your own LLM instance
        llm: Optional[BaseChatModel] = None,
        # Option 2: Configure the custom LLM
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        model_name: str = "default-model",
        # Model parameters
        max_tokens: int = 4096,
        temperature: float = 0.0,
        # HTTP settings
        verify_ssl: bool = True,
        timeout: float = 120.0,
    ):
        """
        Initialize the SRE Agent.
        
        Args:
            llm: Pre-configured LangChain chat model. If provided, all other
                 LLM configuration options are ignored.
            base_url: Model server URL. Falls back to LLM_BASE_URL env var.
            api_key: API key. Falls back to LLM_API_KEY env var.
            model_name: Model identifier. Falls back to MODEL_NAME env var.
            max_tokens: Maximum tokens in response.
            temperature: Sampling temperature (0.0 = deterministic).
            verify_ssl: Whether to verify SSL certificates.
            timeout: Request timeout in seconds.
        
        Raises:
            ValueError: If LLM_BASE_URL is not configured.
        """
        if llm is not None:
            # Use provided LLM directly
            self.llm = llm
            self.model_name = getattr(llm, "model", model_name)
        else:
            # Create LLM from configuration
            from .llm_custom import create_llm
            
            # Get base_url from parameter or environment
            effective_base_url = base_url or os.getenv("LLM_BASE_URL")
            if not effective_base_url:
                raise ValueError(
                    "LLM_BASE_URL is not configured. "
                    "Set the LLM_BASE_URL environment variable or pass base_url parameter."
                )
            
            # Get model name from parameter or environment
            effective_model = model_name
            if model_name == "default-model":
                effective_model = os.getenv("MODEL_NAME", model_name)
            
            self.llm = create_llm(
                base_url=effective_base_url,
                api_key=api_key,
                model=effective_model,
                max_tokens=max_tokens,
                temperature=temperature,
                verify_ssl=verify_ssl,
                timeout=timeout,
            )
            self.model_name = effective_model
        
        self.max_tokens = max_tokens
        self.temperature = temperature
    
    # =========================================================================
    # INCIDENT SUMMARIZATION
    # =========================================================================
    
    async def summarize_incident_simple(
        self,
        incident_data: Dict[str, Any],
    ) -> str:
        """
        Generate a structured summary of an incident.
        
        Analyzes the incident data and produces a summary including:
        - Executive summary
        - Timeline of key events
        - Impact assessment
        - Root cause (if identifiable)
        - Resolution steps
        - Prevention recommendations
        
        Args:
            incident_data: Dictionary containing incident details:
                - key (str): Incident ID (e.g., "INC-123")
                - summary (str): Brief title
                - description (str): Full description
                - status (str, optional): Current status
                - priority (str, optional): Priority level
                - comments (dict/list, optional): Comments/timeline
        
        Returns:
            Markdown-formatted incident summary
        
        Example:
            >>> summary = await agent.summarize_incident_simple({
            ...     "key": "INC-123",
            ...     "summary": "API latency spike",
            ...     "description": "p99 latency increased from 100ms to 5s",
            ...     "status": "Resolved",
            ...     "priority": "Critical",
            ...     "comments": {
            ...         "comments": [
            ...             {"author": "oncall", "body": "Investigating..."}
            ...         ]
            ...     }
            ... })
        """
        prompt = format_incident_prompt(incident_data)
        
        response = await self.llm.ainvoke([
            SystemMessage(content=SRE_AGENT_SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ])
        
        return str(response.content)
    
    # =========================================================================
    # TICKET TRIAGE
    # =========================================================================
    
    async def triage_ticket_simple(
        self,
        ticket_data: Dict[str, Any],
    ) -> str:
        """
        Triage a support ticket and provide categorization.
        
        Analyzes the ticket and provides:
        - Category (bug, feature, support, incident)
        - Recommended priority with reasoning
        - Suggested team/owner
        - Escalation recommendation
        - Brief analysis
        
        Args:
            ticket_data: Dictionary containing ticket details:
                - key (str): Ticket ID
                - summary (str): Brief title
                - description (str, optional): Full description
                - reporter (dict/str, optional): Reporter info
                - labels (list, optional): Existing labels
        
        Returns:
            Triage analysis as formatted text
        
        Example:
            >>> result = await agent.triage_ticket_simple({
            ...     "key": "SUPPORT-789",
            ...     "summary": "Cannot export reports",
            ...     "description": "PDF export button does nothing..."
            ... })
        """
        prompt = format_triage_prompt(ticket_data)
        
        response = await self.llm.ainvoke([
            SystemMessage(content=SRE_AGENT_SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ])
        
        return str(response.content)
    
    # =========================================================================
    # ROOT CAUSE ANALYSIS
    # =========================================================================
    
    async def analyze_root_cause(
        self,
        incident_data: Dict[str, Any],
        code_changes: Optional[List[Dict[str, Any]]] = None,
        related_incidents: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """
        Perform root cause analysis on an incident.
        
        Provides detailed RCA including:
        - Primary root cause
        - Contributing factors
        - Detection gap analysis
        - Immediate and long-term fixes
        - Process improvements
        - Action items
        
        Args:
            incident_data: Dictionary containing incident details
            code_changes: Optional list of related code changes/MRs
            related_incidents: Optional list of similar past incidents
        
        Returns:
            Root cause analysis as formatted text
        
        Example:
            >>> rca = await agent.analyze_root_cause(
            ...     incident_data={"key": "INC-123", "summary": "..."},
            ...     code_changes=[{"title": "Add caching", "url": "..."}],
            ...     related_incidents=[{"key": "INC-100", "summary": "..."}],
            ... )
        """
        # Enrich incident data with additional context
        enriched_data = incident_data.copy()
        
        if code_changes:
            enriched_data["code_changes"] = code_changes
        
        if related_incidents:
            enriched_data["related_incidents"] = related_incidents
        
        prompt = format_rca_prompt(enriched_data)
        
        response = await self.llm.ainvoke([
            SystemMessage(content=SRE_AGENT_SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ])
        
        return str(response.content)
    
    # =========================================================================
    # INTERACTIVE CHAT
    # =========================================================================
    
    async def chat(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        conversation_history: Optional[List[Dict[str, str]]] = None,
    ) -> str:
        """
        Free-form chat with the SRE agent.
        
        Ask questions about SRE topics, debugging, incident response,
        or provide context for analysis.
        
        Args:
            message: User message or question
            context: Optional context dictionary to include in the prompt
            conversation_history: Optional list of previous messages for
                multi-turn conversations. Each dict should have:
                - role: "user" or "assistant"
                - content: The message content
        
        Returns:
            Agent's response
        
        Example:
            >>> # Simple question
            >>> response = await agent.chat(
            ...     "What causes connection pool exhaustion?"
            ... )
            
            >>> # With context
            >>> response = await agent.chat(
            ...     "What should I check next?",
            ...     context={"error": "OOMKilled", "service": "api-gateway"}
            ... )
            
            >>> # Multi-turn conversation
            >>> response = await agent.chat(
            ...     "What else?",
            ...     conversation_history=[
            ...         {"role": "user", "content": "What causes memory leaks?"},
            ...         {"role": "assistant", "content": "Common causes include..."},
            ...     ]
            ... )
        """
        # Build message content with context if provided
        content = message
        if context:
            content = f"{message}\n\nContext:\n```json\n{json.dumps(context, indent=2)}\n```"
        
        # Build messages list
        messages: List[Union[SystemMessage, HumanMessage, AIMessage]] = [
            SystemMessage(content=SRE_AGENT_SYSTEM_PROMPT),
        ]
        
        # Add conversation history if provided
        if conversation_history:
            for msg in conversation_history:
                role = msg.get("role", "user")
                msg_content = msg.get("content", "")
                
                if role == "user":
                    messages.append(HumanMessage(content=msg_content))
                elif role == "assistant":
                    messages.append(AIMessage(content=msg_content))
        
        # Add current message
        messages.append(HumanMessage(content=content))
        
        # Get response
        response = await self.llm.ainvoke(messages)
        
        return str(response.content)


# =============================================================================
# BACKWARDS COMPATIBILITY
# =============================================================================

# Alias for backwards compatibility
SREAgent = SREAgentSimple
