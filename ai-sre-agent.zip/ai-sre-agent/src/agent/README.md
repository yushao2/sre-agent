# Agent Module

This is the core AI SRE Agent implementation.

## Module Structure

```
agent/
├── __init__.py       # Package exports
├── agent.py          # SREAgentSimple - main agent class
├── llm_custom.py     # Custom LLM wrapper (CUSTOMIZE THIS!)
├── prompts.py        # System prompts and formatters
├── rag.py            # RAG with ChromaDB
├── local.py          # CLI and local development tools
├── server.py         # FastAPI production server
├── tasks.py          # Celery async task definitions
├── database.py       # SQLAlchemy models for persistence
└── cli.py            # CLI entry point
```

## Quick Start

### As a Python Library

```python
from agent import SREAgentSimple

# Create agent (reads LLM config from environment)
agent = SREAgentSimple()

# Summarize an incident
summary = await agent.summarize_incident_simple({
    "key": "INC-123",
    "summary": "Database connection timeout",
    "description": "Users seeing 504 errors...",
    "status": "Resolved",
    "priority": "Critical",
})

# Chat with the agent
response = await agent.chat("What causes connection pool exhaustion?")

# Triage a ticket
triage = await agent.triage_ticket_simple({
    "key": "SUPPORT-456",
    "summary": "Cannot export reports",
    "description": "PDF export button does nothing...",
})
```

### From Command Line

```bash
# Interactive chat
python -m agent.local interactive

# Single question
python -m agent.local chat "What causes high CPU usage?"

# Summarize incident from JSON file
python -m agent.local summarize --file incident.json

# Run demo
python -m agent.local demo
```

## Customizing the LLM

The agent uses `llm_custom.py` to communicate with your model server. You MUST customize this file.

### Steps:

1. Open `llm_custom.py`
2. Search for `>>> CUSTOMIZE` comments
3. Modify the marked methods to match your API

### Key Methods to Customize:

| Method | Purpose |
|--------|---------|
| `_get_endpoint()` | Return your API URL path |
| `_get_headers()` | Return authentication headers |
| `_convert_messages()` | Convert LangChain messages to your format |
| `_build_request_body()` | Build the JSON request payload |
| `_parse_response()` | Extract generated text from response |

### Testing Your Configuration

```bash
export LLM_BASE_URL=https://your-server.com
export LLM_API_KEY=your-key
python -m agent.llm_custom
```

## RAG (Retrieval Augmented Generation)

Store and search past incidents:

```python
from agent import IncidentKnowledgeBase

# Create/open knowledge base
kb = IncidentKnowledgeBase(persist_directory="./data/incidents")

# Add incidents
kb.add_incident({
    "key": "INC-100",
    "summary": "Memory leak in API service",
    "root_cause": "Unbounded cache growth",
    "resolution": "Added cache eviction policy",
})

# Search similar incidents
results = kb.search("memory issues in API", k=5)
for incident, score in results:
    print(f"{incident['key']}: {incident['summary']} (score: {score:.2f})")
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `LLM_BASE_URL` | Yes | Your model server URL |
| `LLM_API_KEY` | Usually | API key for authentication |
| `MODEL_NAME` | No | Model identifier |
| `LLM_TIMEOUT` | No | Request timeout (default: 120s) |
| `SRE_AGENT_DATA_DIR` | No | Override data directory for RAG |

## Synchronous Helpers

For scripts that can't use async:

```python
from agent.local import run_chat, run_summarize, run_triage

# These are synchronous wrappers around the async agent methods
response = run_chat("What is a runbook?")
summary = run_summarize(incident_data)
triage = run_triage(ticket_data)
```
