"""
System Prompts and Message Formatters
=====================================

This module contains the system prompts and helper functions for
formatting messages to send to the LLM.

The system prompt defines the agent's personality, capabilities,
and response format.
"""

from typing import Any, Dict, List, Optional


# =============================================================================
# SYSTEM PROMPT
# =============================================================================

SRE_AGENT_SYSTEM_PROMPT = """You are an expert Site Reliability Engineer (SRE) AI assistant.

Your role is to help with:
- Incident analysis and summarization
- Root cause analysis (RCA)
- Support ticket triage and prioritization
- SRE best practices and guidance

## Response Guidelines

1. **Be Concise**: Get to the point quickly. Avoid unnecessary preamble.

2. **Be Structured**: Use clear sections and formatting when appropriate.

3. **Be Actionable**: Provide specific, actionable recommendations.

4. **Be Accurate**: If you're uncertain, say so. Don't make up information.

5. **Use Technical Language**: You're speaking to engineers. Use appropriate terminology.

## For Incident Summaries

Structure your response with:
- **Executive Summary**: 2-3 sentence overview
- **Timeline**: Key events in chronological order
- **Impact**: Who/what was affected and for how long
- **Root Cause**: What caused the incident (if known)
- **Resolution**: How the incident was resolved
- **Prevention**: Recommendations to prevent recurrence

## For Ticket Triage

Provide:
- **Category**: bug, feature request, support question, incident, etc.
- **Priority**: critical, high, medium, low (with reasoning)
- **Suggested Team**: Which team should handle this
- **Escalation**: Whether immediate escalation is needed
- **Summary**: Brief description of the issue

## For Root Cause Analysis

Include:
- **Primary Cause**: The main reason the incident occurred
- **Contributing Factors**: Other factors that made it worse
- **Detection Gap**: Why wasn't this caught earlier?
- **Immediate Fix**: What was done to resolve it
- **Long-term Fix**: What should be done to prevent recurrence
- **Process Improvements**: Changes to processes/practices
"""


# =============================================================================
# MESSAGE FORMATTERS
# =============================================================================

def format_incident_prompt(incident_data: Dict[str, Any]) -> str:
    """
    Format an incident for the summarization prompt.
    
    Args:
        incident_data: Dictionary containing incident details:
            - key: Incident ID (e.g., "INC-123")
            - summary: Brief title
            - description: Full description
            - status: Current status
            - priority: Priority level
            - comments: Dict with 'comments' list
    
    Returns:
        Formatted prompt string
    """
    key = incident_data.get("key", "UNKNOWN")
    summary = incident_data.get("summary", "No summary provided")
    description = incident_data.get("description", "No description provided")
    status = incident_data.get("status", "Unknown")
    priority = incident_data.get("priority", "Unknown")
    
    # Format comments if present
    comments_section = ""
    comments_data = incident_data.get("comments", {})
    if isinstance(comments_data, dict):
        comments_list = comments_data.get("comments", [])
    elif isinstance(comments_data, list):
        comments_list = comments_data
    else:
        comments_list = []
    
    if comments_list:
        comments_section = "\n\n## Comments/Timeline\n"
        for comment in comments_list:
            author = comment.get("author", "Unknown")
            created = comment.get("created", "")
            body = comment.get("body", "")
            comments_section += f"\n**{author}** ({created}):\n{body}\n"
    
    # Build the prompt
    prompt = f"""Please analyze and summarize the following incident:

## Incident Details
- **ID**: {key}
- **Summary**: {summary}
- **Status**: {status}
- **Priority**: {priority}

## Description
{description}
{comments_section}

Please provide a structured summary including:
1. Executive Summary
2. Timeline of key events
3. Impact assessment
4. Root cause (if identifiable from the information)
5. Resolution steps taken
6. Recommendations to prevent recurrence
"""
    
    return prompt


def format_triage_prompt(ticket_data: Dict[str, Any]) -> str:
    """
    Format a ticket for the triage prompt.
    
    Args:
        ticket_data: Dictionary containing ticket details:
            - key: Ticket ID
            - summary: Brief title
            - description: Full description
            - reporter: Reporter info
            - labels: List of labels
    
    Returns:
        Formatted prompt string
    """
    key = ticket_data.get("key", "UNKNOWN")
    summary = ticket_data.get("summary", "No summary provided")
    description = ticket_data.get("description", "No description provided")
    
    # Format reporter
    reporter_data = ticket_data.get("reporter", {})
    if isinstance(reporter_data, dict):
        reporter = reporter_data.get("displayName", reporter_data.get("name", "Unknown"))
    else:
        reporter = str(reporter_data) if reporter_data else "Unknown"
    
    # Format labels
    labels = ticket_data.get("labels", [])
    labels_str = ", ".join(labels) if labels else "None"
    
    prompt = f"""Please triage the following support ticket:

## Ticket Details
- **ID**: {key}
- **Summary**: {summary}
- **Reporter**: {reporter}
- **Labels**: {labels_str}

## Description
{description}

Please provide:
1. **Category**: (bug, feature request, support question, incident, documentation, other)
2. **Recommended Priority**: (critical, high, medium, low) with reasoning
3. **Suggested Team/Owner**: Which team should handle this
4. **Escalation Needed**: Yes/No with reasoning
5. **Brief Analysis**: What is the core issue and suggested approach
"""
    
    return prompt


def format_rca_prompt(incident_data: Dict[str, Any]) -> str:
    """
    Format an incident for root cause analysis.
    
    Args:
        incident_data: Dictionary containing incident details
            Can also include:
            - code_changes: Related code changes/MRs
            - related_incidents: Similar past incidents
    
    Returns:
        Formatted prompt string
    """
    key = incident_data.get("key", "UNKNOWN")
    summary = incident_data.get("summary", "No summary provided")
    description = incident_data.get("description", "No description provided")
    status = incident_data.get("status", "Unknown")
    priority = incident_data.get("priority", "Unknown")
    
    # Build base prompt
    prompt = f"""Please perform a detailed Root Cause Analysis (RCA) for the following incident:

## Incident Details
- **ID**: {key}
- **Summary**: {summary}
- **Status**: {status}
- **Priority**: {priority}

## Description
{description}
"""
    
    # Add code changes if present
    code_changes = incident_data.get("code_changes")
    if code_changes:
        prompt += "\n## Related Code Changes\n"
        if isinstance(code_changes, str):
            prompt += code_changes
        else:
            for change in code_changes:
                title = change.get("title", "Unknown")
                url = change.get("url", "")
                author = change.get("author", "Unknown")
                prompt += f"\n- **{title}** by {author}"
                if url:
                    prompt += f" ({url})"
                prompt += "\n"
    
    # Add related incidents if present
    related_incidents = incident_data.get("related_incidents")
    if related_incidents:
        prompt += "\n## Similar Past Incidents\n"
        if isinstance(related_incidents, str):
            prompt += related_incidents
        else:
            for incident in related_incidents:
                inc_key = incident.get("key", "Unknown")
                inc_summary = incident.get("summary", "")
                prompt += f"\n- **{inc_key}**: {inc_summary}\n"
    
    prompt += """

Please provide a comprehensive RCA including:
1. **Primary Root Cause**: The main technical reason the incident occurred
2. **Contributing Factors**: Other factors that enabled or worsened the incident
3. **Detection Gap**: Why wasn't this caught earlier (monitoring, testing, review)?
4. **Immediate Fix**: What was done to resolve the immediate issue
5. **Long-term Fix**: Architectural or code changes to prevent recurrence
6. **Process Improvements**: Changes to development/operational processes
7. **Action Items**: Specific, assignable tasks with suggested owners
"""
    
    return prompt


def format_chat_context(context: Dict[str, Any]) -> str:
    """
    Format additional context for a chat message.
    
    Args:
        context: Dictionary of context to include
    
    Returns:
        Formatted context string
    """
    import json
    
    if not context:
        return ""
    
    return f"\n\nContext:\n```json\n{json.dumps(context, indent=2)}\n```"
