"""
System Prompts and Message Formatters
=====================================

This module contains the system prompts and helper functions for
formatting messages to send to the LLM.

The system prompt defines the agent's personality, capabilities,
and response format.
"""

from typing import Any, Dict, List, Optional


# =============================================================================
# SYSTEM PROMPT
# =============================================================================

SRE_AGENT_SYSTEM_PROMPT = """You are an expert Site Reliability Engineer (SRE) AI assistant.

Your role is to help with:
- Incident analysis and summarization
- Root cause analysis (RCA)
- Triage of incoming requests from any source (tickets, Teams, Slack, incident bridges, etc.)
- SRE best practices and guidance

## Response Guidelines

1. **Be Concise**: Get to the point quickly. Avoid unnecessary preamble.

2. **Be Structured**: Use clear sections and formatting when appropriate.

3. **Be Actionable**: Provide specific, actionable recommendations.

4. **Be Accurate**: If you're uncertain, say so. Don't make up information.

5. **Use Technical Language**: You're speaking to engineers. Use appropriate terminology.

## For Incident Summaries

Structure your response with:
- **Executive Summary**: 2-3 sentence overview
- **Timeline**: Key events in chronological order
- **Impact**: Who/what was affected and for how long
- **Root Cause**: What caused the incident (if known)
- **Resolution**: How the incident was resolved
- **Prevention**: Recommendations to prevent recurrence

## For Triage (Tickets, Teams Messages, Incident Bridges, etc.)

Requests can come from many sources: support tickets, MS Teams channels, Slack, 
incident bridges, email, PagerDuty alerts, etc. Regardless of source, provide:

- **Category**: incident, bug, support question, feature request, change request, documentation, noise, other
- **Severity**: critical, high, medium, low (with reasoning)
- **Urgency**: Whether immediate attention is needed
- **Suggested Team**: Which team should handle this
- **Recommended Action**: Next steps (escalate, create ticket, respond, etc.)
- **Brief Analysis**: Core issue and your assessment

## For Root Cause Analysis

Include:
- **Primary Cause**: The main reason the incident occurred
- **Contributing Factors**: Other factors that made it worse
- **Detection Gap**: Why wasn't this caught earlier?
- **Immediate Fix**: What was done to resolve it
- **Long-term Fix**: What should be done to prevent recurrence
- **Process Improvements**: Changes to processes/practices
"""


# =============================================================================
# MESSAGE FORMATTERS
# =============================================================================

def format_incident_prompt(incident_data: Dict[str, Any]) -> str:
    """
    Format an incident for the summarization prompt.
    
    Args:
        incident_data: Dictionary containing incident details:
            - key: Incident ID (e.g., "INC-123")
            - summary: Brief title
            - description: Full description
            - status: Current status
            - priority: Priority level
            - comments: Dict with 'comments' list
    
    Returns:
        Formatted prompt string
    """
    key = incident_data.get("key", "UNKNOWN")
    summary = incident_data.get("summary", "No summary provided")
    description = incident_data.get("description", "No description provided")
    status = incident_data.get("status", "Unknown")
    priority = incident_data.get("priority", "Unknown")
    
    # Format comments if present
    comments_section = ""
    comments_data = incident_data.get("comments", {})
    if isinstance(comments_data, dict):
        comments_list = comments_data.get("comments", [])
    elif isinstance(comments_data, list):
        comments_list = comments_data
    else:
        comments_list = []
    
    if comments_list:
        comments_section = "\n\n## Comments/Timeline\n"
        for comment in comments_list:
            author = comment.get("author", "Unknown")
            created = comment.get("created", "")
            body = comment.get("body", "")
            comments_section += f"\n**{author}** ({created}):\n{body}\n"
    
    # Build the prompt
    prompt = f"""Please analyze and summarize the following incident:

## Incident Details
- **ID**: {key}
- **Summary**: {summary}
- **Status**: {status}
- **Priority**: {priority}

## Description
{description}
{comments_section}

Please provide a structured summary including:
1. Executive Summary
2. Timeline of key events
3. Impact assessment
4. Root cause (if identifiable from the information)
5. Resolution steps taken
6. Recommendations to prevent recurrence
"""
    
    return prompt


def format_triage_prompt(request_data: Dict[str, Any]) -> str:
    """
    Format a triage request for analysis.
    
    This handles incoming requests from multiple sources:
    - Support tickets (Jira, ServiceNow, etc.)
    - MS Teams messages (support channels, incident bridges)
    - Slack messages
    - Email
    - PagerDuty alerts
    - Generic webhook payloads
    
    Args:
        request_data: Dictionary containing request details. Flexible schema:
            - key/id: Optional identifier
            - summary/title/subject: Brief title
            - description/message/body/text: Full content
            - reporter/author/sender/from: Who sent it
            - source/channel: Where it came from (teams, slack, email, jira)
            - labels/tags: Optional categorization
            - thread/conversation: Optional conversation context
    
    Returns:
        Formatted prompt string
    """
    # Extract identifier (flexible field names)
    request_id = (
        request_data.get("key") or 
        request_data.get("id") or 
        request_data.get("ticket_id") or
        request_data.get("message_id") or
        "UNKNOWN"
    )
    
    # Extract title/summary (flexible field names)
    summary = (
        request_data.get("summary") or
        request_data.get("title") or
        request_data.get("subject") or
        "No summary provided"
    )
    
    # Extract main content (flexible field names)
    description = (
        request_data.get("description") or
        request_data.get("message") or
        request_data.get("body") or
        request_data.get("text") or
        request_data.get("content") or
        "No description provided"
    )
    
    # Extract source/channel info
    source = (
        request_data.get("source") or
        request_data.get("channel") or
        request_data.get("platform") or
        "unknown"
    )
    
    # Format reporter/author (flexible field names and types)
    reporter_data = (
        request_data.get("reporter") or
        request_data.get("author") or
        request_data.get("sender") or
        request_data.get("from") or
        request_data.get("user") or
        {}
    )
    if isinstance(reporter_data, dict):
        reporter = (
            reporter_data.get("displayName") or 
            reporter_data.get("name") or
            reporter_data.get("email") or
            reporter_data.get("username") or
            "Unknown"
        )
    else:
        reporter = str(reporter_data) if reporter_data else "Unknown"
    
    # Format labels/tags
    labels = (
        request_data.get("labels") or
        request_data.get("tags") or
        []
    )
    labels_str = ", ".join(labels) if labels else "None"
    
    # Include thread/conversation context if present
    thread_context = ""
    thread = request_data.get("thread") or request_data.get("conversation") or request_data.get("replies")
    if thread:
        thread_context = "\n\n## Conversation Thread\n"
        if isinstance(thread, list):
            for msg in thread:
                if isinstance(msg, dict):
                    msg_author = msg.get("author") or msg.get("sender") or msg.get("from") or "Unknown"
                    msg_text = msg.get("text") or msg.get("message") or msg.get("body") or ""
                    msg_time = msg.get("timestamp") or msg.get("time") or msg.get("created") or ""
                    thread_context += f"\n**{msg_author}** ({msg_time}):\n{msg_text}\n"
                else:
                    thread_context += f"\n{msg}\n"
        elif isinstance(thread, str):
            thread_context += thread
    
    # Include any additional context
    extra_context = ""
    for extra_key in ["environment", "service", "component", "urgency", "impact", "error", "stack_trace"]:
        if extra_key in request_data and request_data[extra_key]:
            extra_context += f"- **{extra_key.replace('_', ' ').title()}**: {request_data[extra_key]}\n"
    
    if extra_context:
        extra_context = f"\n## Additional Context\n{extra_context}"
    
    prompt = f"""Please triage the following request:

## Request Details
- **ID**: {request_id}
- **Summary**: {summary}
- **Reporter**: {reporter}
- **Source**: {source}
- **Tags**: {labels_str}

## Content
{description}
{thread_context}
{extra_context}

Please provide:
1. **Category**: (incident, bug, support question, feature request, change request, documentation, noise/spam, other)
2. **Severity Assessment**: (critical, high, medium, low) with reasoning
3. **Urgency**: Does this need immediate attention? Why or why not?
4. **Suggested Team/Owner**: Which team or person should handle this
5. **Recommended Action**: What should be done next (e.g., escalate to incident bridge, create ticket, respond with documentation, etc.)
6. **Brief Analysis**: What is the core issue and your assessment
"""
    
    return prompt


def format_rca_prompt(incident_data: Dict[str, Any]) -> str:
    """
    Format an incident for root cause analysis.
    
    Args:
        incident_data: Dictionary containing incident details
            Can also include:
            - code_changes: Related code changes/MRs
            - related_incidents: Similar past incidents
    
    Returns:
        Formatted prompt string
    """
    key = incident_data.get("key", "UNKNOWN")
    summary = incident_data.get("summary", "No summary provided")
    description = incident_data.get("description", "No description provided")
    status = incident_data.get("status", "Unknown")
    priority = incident_data.get("priority", "Unknown")
    
    # Build base prompt
    prompt = f"""Please perform a detailed Root Cause Analysis (RCA) for the following incident:

## Incident Details
- **ID**: {key}
- **Summary**: {summary}
- **Status**: {status}
- **Priority**: {priority}

## Description
{description}
"""
    
    # Add code changes if present
    code_changes = incident_data.get("code_changes")
    if code_changes:
        prompt += "\n## Related Code Changes\n"
        if isinstance(code_changes, str):
            prompt += code_changes
        else:
            for change in code_changes:
                title = change.get("title", "Unknown")
                url = change.get("url", "")
                author = change.get("author", "Unknown")
                prompt += f"\n- **{title}** by {author}"
                if url:
                    prompt += f" ({url})"
                prompt += "\n"
    
    # Add related incidents if present
    related_incidents = incident_data.get("related_incidents")
    if related_incidents:
        prompt += "\n## Similar Past Incidents\n"
        if isinstance(related_incidents, str):
            prompt += related_incidents
        else:
            for incident in related_incidents:
                inc_key = incident.get("key", "Unknown")
                inc_summary = incident.get("summary", "")
                prompt += f"\n- **{inc_key}**: {inc_summary}\n"
    
    prompt += """

Please provide a comprehensive RCA including:
1. **Primary Root Cause**: The main technical reason the incident occurred
2. **Contributing Factors**: Other factors that enabled or worsened the incident
3. **Detection Gap**: Why wasn't this caught earlier (monitoring, testing, review)?
4. **Immediate Fix**: What was done to resolve the immediate issue
5. **Long-term Fix**: Architectural or code changes to prevent recurrence
6. **Process Improvements**: Changes to development/operational processes
7. **Action Items**: Specific, assignable tasks with suggested owners
"""
    
    return prompt


def format_chat_context(context: Dict[str, Any]) -> str:
    """
    Format additional context for a chat message.
    
    Args:
        context: Dictionary of context to include
    
    Returns:
        Formatted context string
    """
    import json
    
    if not context:
        return ""
    
    return f"\n\nContext:\n```json\n{json.dumps(context, indent=2)}\n```"
