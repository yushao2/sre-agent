"""
Database Models and Utilities
=============================

SQLAlchemy models for persisting task results and webhook logs.

This module is OPTIONAL - the agent works without a database.
The database is only needed for:
- Long-term task result storage
- Webhook logging and auditing
- Historical analytics

Configuration:
    DATABASE_URL: PostgreSQL connection string
    Example: postgresql://user:pass@localhost:5432/sre_agent

Usage:
    from agent.database import init_database, get_db_session
    
    # Initialize tables
    init_database("postgresql://...")
    
    # Use session
    with get_db_session() as db:
        results = db.query(TaskResult).all()
"""

import os
from contextlib import contextmanager
from datetime import datetime
from typing import Generator, Optional

from sqlalchemy import (
    Column,
    DateTime,
    Integer,
    String,
    Text,
    create_engine,
    Index,
)
from sqlalchemy.orm import Session, sessionmaker, declarative_base

# SQLAlchemy base class for models
Base = declarative_base()

# Global engine and session factory
_engine = None
_SessionLocal = None


# =============================================================================
# MODELS
# =============================================================================

class TaskResult(Base):
    """
    Stores results from Celery tasks.
    
    This provides a queryable record of all LLM operations,
    beyond what's stored in the Celery result backend.
    """
    __tablename__ = "task_results"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(255), unique=True, nullable=False, index=True)
    task_type = Column(String(50), nullable=False)  # summarize, triage, rca, chat
    status = Column(String(50), nullable=False, default="pending")
    result_data = Column(Text, nullable=True)  # JSON string
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    
    # Indexes for common queries
    __table_args__ = (
        Index("idx_task_type_created", "task_type", "created_at"),
        Index("idx_status_created", "status", "created_at"),
    )
    
    def __repr__(self):
        return f"<TaskResult(task_id={self.task_id}, type={self.task_type}, status={self.status})>"


class WebhookLog(Base):
    """
    Logs incoming webhook events for auditing.
    
    Stores the raw webhook payload and processing status.
    """
    __tablename__ = "webhook_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    webhook_id = Column(String(255), unique=True, nullable=False, index=True)
    source = Column(String(50), nullable=False)  # jira, pagerduty, generic
    event_type = Column(String(100), nullable=True)
    payload = Column(Text, nullable=True)  # JSON string
    task_id = Column(String(255), nullable=True)  # Associated Celery task
    status = Column(String(50), default="received")  # received, processed, failed
    error_message = Column(Text, nullable=True)
    received_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    processed_at = Column(DateTime, nullable=True)
    
    __table_args__ = (
        Index("idx_source_received", "source", "received_at"),
    )
    
    def __repr__(self):
        return f"<WebhookLog(id={self.webhook_id}, source={self.source}, status={self.status})>"


# =============================================================================
# DATABASE INITIALIZATION
# =============================================================================

def init_database(database_url: Optional[str] = None) -> bool:
    """
    Initialize the database connection and create tables.
    
    Args:
        database_url: PostgreSQL connection string.
                     If not provided, uses DATABASE_URL env var.
    
    Returns:
        True if successful, False otherwise
    
    Example:
        init_database("postgresql://user:pass@localhost:5432/sre_agent")
    """
    global _engine, _SessionLocal
    
    url = database_url or os.getenv("DATABASE_URL")
    if not url:
        return False
    
    try:
        _engine = create_engine(
            url,
            pool_size=5,
            max_overflow=10,
            pool_pre_ping=True,  # Check connection health
        )
        
        _SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=_engine,
        )
        
        # Create tables if they don't exist
        Base.metadata.create_all(bind=_engine)
        
        return True
        
    except Exception as e:
        print(f"Database initialization failed: {e}")
        return False


@contextmanager
def get_db_session() -> Generator[Session, None, None]:
    """
    Get a database session.
    
    Use as a context manager to ensure proper cleanup:
    
        with get_db_session() as db:
            results = db.query(TaskResult).all()
    
    Yields:
        SQLAlchemy Session
    
    Raises:
        RuntimeError: If database is not initialized
    """
    global _SessionLocal
    
    if _SessionLocal is None:
        # Try to initialize from environment
        if not init_database():
            raise RuntimeError(
                "Database not initialized. "
                "Set DATABASE_URL environment variable or call init_database()."
            )
    
    session = _SessionLocal()
    try:
        yield session
    finally:
        session.close()


# =============================================================================
# REPOSITORY HELPERS
# =============================================================================

class TaskResultRepository:
    """Helper class for TaskResult operations."""
    
    def __init__(self, session: Session):
        self.session = session
    
    def create(
        self,
        task_id: str,
        task_type: str,
        status: str = "pending",
    ) -> TaskResult:
        """Create a new task result record."""
        result = TaskResult(
            task_id=task_id,
            task_type=task_type,
            status=status,
            created_at=datetime.utcnow(),
        )
        self.session.add(result)
        self.session.commit()
        return result
    
    def update_completed(
        self,
        task_id: str,
        status: str,
        result_data: Optional[str] = None,
        error_message: Optional[str] = None,
    ) -> Optional[TaskResult]:
        """Update task result when completed."""
        result = self.session.query(TaskResult).filter_by(task_id=task_id).first()
        if result:
            result.status = status
            result.result_data = result_data
            result.error_message = error_message
            result.completed_at = datetime.utcnow()
            self.session.commit()
        return result
    
    def get_by_task_id(self, task_id: str) -> Optional[TaskResult]:
        """Get task result by Celery task ID."""
        return self.session.query(TaskResult).filter_by(task_id=task_id).first()
    
    def list_recent(self, limit: int = 50) -> list:
        """List recent task results."""
        return (
            self.session.query(TaskResult)
            .order_by(TaskResult.created_at.desc())
            .limit(limit)
            .all()
        )


class WebhookLogRepository:
    """Helper class for WebhookLog operations."""
    
    def __init__(self, session: Session):
        self.session = session
    
    def create(
        self,
        webhook_id: str,
        source: str,
        payload: str,
        event_type: Optional[str] = None,
    ) -> WebhookLog:
        """Create a new webhook log entry."""
        log = WebhookLog(
            webhook_id=webhook_id,
            source=source,
            payload=payload,
            event_type=event_type,
            received_at=datetime.utcnow(),
        )
        self.session.add(log)
        self.session.commit()
        return log
    
    def update_processed(
        self,
        webhook_id: str,
        task_id: str,
        status: str = "processed",
        error_message: Optional[str] = None,
    ) -> Optional[WebhookLog]:
        """Update webhook log when processed."""
        log = self.session.query(WebhookLog).filter_by(webhook_id=webhook_id).first()
        if log:
            log.task_id = task_id
            log.status = status
            log.error_message = error_message
            log.processed_at = datetime.utcnow()
            self.session.commit()
        return log
    
    def get_by_webhook_id(self, webhook_id: str) -> Optional[WebhookLog]:
        """Get webhook log by ID."""
        return self.session.query(WebhookLog).filter_by(webhook_id=webhook_id).first()
