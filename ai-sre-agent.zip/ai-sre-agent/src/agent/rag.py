"""
RAG (Retrieval Augmented Generation) for Incidents and Runbooks
================================================================

This module provides vector stores for storing and searching:
- Past incidents (for finding similar issues)
- Runbooks (for finding relevant documentation)

Uses ChromaDB for vector storage and sentence-transformers for embeddings.
Both run locally with no external services required.

Data is stored in files on disk, so it persists between runs.

Requirements:
    pip install chromadb sentence-transformers

Usage:
    >>> from agent import IncidentKnowledgeBase, RunbookStore
    >>> 
    >>> # Create incident knowledge base
    >>> kb = IncidentKnowledgeBase(persist_directory="./data/incidents")
    >>> 
    >>> # Add past incidents
    >>> kb.add_incident({
    ...     "key": "INC-100",
    ...     "summary": "Database connection pool exhausted",
    ...     "root_cause": "Connection leak in reporting service",
    ...     "resolution": "Fixed connection leak, added monitoring",
    ... })
    >>> 
    >>> # Search for similar incidents
    >>> results = kb.search("connection timeout errors", k=3)
    >>> for incident, score in results:
    ...     print(f"{incident['key']}: {incident['summary']} (score: {score:.2f})")

Default data directory: ~/.local/share/ai-sre-agent/
Override with SRE_AGENT_DATA_DIR environment variable.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# =============================================================================
# DATA DIRECTORY
# =============================================================================

def get_default_data_dir() -> Path:
    """
    Get the default data directory for storing RAG data.
    
    Uses SRE_AGENT_DATA_DIR environment variable if set,
    otherwise defaults to ~/.local/share/ai-sre-agent/
    
    Returns:
        Path to the data directory
    """
    env_dir = os.getenv("SRE_AGENT_DATA_DIR")
    if env_dir:
        return Path(env_dir)
    
    # Default: ~/.local/share/ai-sre-agent/
    return Path.home() / ".local" / "share" / "ai-sre-agent"


# =============================================================================
# EMBEDDING MODEL
# =============================================================================

# Default embedding model - runs locally, no API calls
DEFAULT_EMBEDDING_MODEL = "all-MiniLM-L6-v2"


def _get_embedding_function(model_name: str = DEFAULT_EMBEDDING_MODEL):
    """
    Get the ChromaDB embedding function.
    
    Uses sentence-transformers for local embeddings.
    No API calls, runs entirely on CPU/GPU.
    
    Args:
        model_name: Name of the sentence-transformers model
    
    Returns:
        ChromaDB embedding function
    """
    try:
        from chromadb.utils import embedding_functions
        
        return embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name=model_name
        )
    except ImportError:
        raise ImportError(
            "chromadb and sentence-transformers are required for RAG. "
            "Install with: pip install chromadb sentence-transformers"
        )


# =============================================================================
# INCIDENT KNOWLEDGE BASE
# =============================================================================

class IncidentKnowledgeBase:
    """
    Vector store for past incidents.
    
    Use this to store and search historical incidents. When a new incident
    comes in, you can search for similar past incidents to provide context.
    
    The knowledge base uses:
    - ChromaDB for vector storage (file-based, no server needed)
    - sentence-transformers for embeddings (local, no API calls)
    
    Attributes:
        collection: The ChromaDB collection
        persist_directory: Where data is stored on disk
    
    Example:
        >>> kb = IncidentKnowledgeBase(persist_directory="./data/incidents")
        >>> 
        >>> # Add incidents
        >>> kb.add_incident({
        ...     "key": "INC-100",
        ...     "summary": "Memory leak in API service",
        ...     "root_cause": "Unbounded cache growth",
        ...     "resolution": "Added cache eviction",
        ... })
        >>> 
        >>> # Search
        >>> results = kb.search("API memory issues", k=3)
    """
    
    def __init__(
        self,
        persist_directory: Optional[str] = None,
        collection_name: str = "incidents",
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
    ):
        """
        Initialize the incident knowledge base.
        
        Args:
            persist_directory: Directory to store the database.
                              If None, uses in-memory storage (not persisted).
                              If not specified, uses default data directory.
            collection_name: Name of the ChromaDB collection
            embedding_model: sentence-transformers model for embeddings
        """
        try:
            import chromadb
        except ImportError:
            raise ImportError(
                "chromadb is required for RAG. "
                "Install with: pip install chromadb sentence-transformers"
            )
        
        # Set up persist directory
        if persist_directory is None:
            # Use default directory
            self.persist_directory = get_default_data_dir() / "incidents"
        else:
            self.persist_directory = Path(persist_directory)
        
        # Create directory if it doesn't exist
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Incident KB using directory: {self.persist_directory}")
        
        # Initialize ChromaDB client with persistence
        self._client = chromadb.PersistentClient(path=str(self.persist_directory))
        
        # Get or create collection
        embedding_fn = _get_embedding_function(embedding_model)
        self.collection = self._client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_fn,
            metadata={"description": "Historical incidents for similarity search"},
        )
        
        logger.info(f"Incident KB initialized with {self.collection.count()} incidents")
    
    def add_incident(self, incident: Dict[str, Any]) -> str:
        """
        Add an incident to the knowledge base.
        
        Args:
            incident: Dictionary with incident data. Required keys:
                - key: Incident ID (e.g., "INC-123")
                - summary: Brief title
                
                Optional but recommended:
                - description: Full description
                - root_cause: What caused the incident
                - resolution: How it was resolved
                - timeline: Key events
                - labels: List of tags/labels
        
        Returns:
            The incident key (ID)
        
        Example:
            >>> kb.add_incident({
            ...     "key": "INC-123",
            ...     "summary": "Database connection timeout",
            ...     "description": "Users seeing 504 errors...",
            ...     "root_cause": "Connection pool exhausted",
            ...     "resolution": "Increased pool size",
            ... })
        """
        key = incident.get("key", "")
        if not key:
            raise ValueError("Incident must have a 'key' field")
        
        # Build the text for embedding
        # Include summary, description, root cause, resolution
        text_parts = [
            incident.get("summary", ""),
            incident.get("description", ""),
            incident.get("root_cause", ""),
            incident.get("resolution", ""),
        ]
        text = " ".join(filter(None, text_parts))
        
        if not text.strip():
            raise ValueError("Incident must have some text content")
        
        # Store the full incident as metadata
        metadata = {
            "key": key,
            "summary": incident.get("summary", ""),
            # ChromaDB metadata values must be str, int, float, or bool
            "data": json.dumps(incident),
        }
        
        # Add to collection
        self.collection.upsert(
            ids=[key],
            documents=[text],
            metadatas=[metadata],
        )
        
        logger.debug(f"Added incident: {key}")
        return key
    
    def add_incidents(self, incidents: List[Dict[str, Any]]) -> List[str]:
        """
        Add multiple incidents at once.
        
        Args:
            incidents: List of incident dictionaries
        
        Returns:
            List of incident keys that were added
        """
        keys = []
        for incident in incidents:
            key = self.add_incident(incident)
            keys.append(key)
        return keys
    
    def search(
        self,
        query: str,
        k: int = 5,
        filter_dict: Optional[Dict[str, Any]] = None,
    ) -> List[Tuple[Dict[str, Any], float]]:
        """
        Search for similar incidents.
        
        Args:
            query: Search query (natural language)
            k: Number of results to return
            filter_dict: Optional metadata filter
        
        Returns:
            List of (incident, score) tuples, sorted by relevance.
            Score is distance (lower = more similar).
        
        Example:
            >>> results = kb.search("connection timeout", k=3)
            >>> for incident, score in results:
            ...     print(f"{incident['key']}: {score:.3f}")
        """
        # Query the collection
        results = self.collection.query(
            query_texts=[query],
            n_results=k,
            where=filter_dict,
        )
        
        # Parse results
        incidents = []
        
        if results and results["metadatas"]:
            for i, metadata in enumerate(results["metadatas"][0]):
                # Parse the stored incident data
                incident_data = json.loads(metadata.get("data", "{}"))
                
                # Get distance score
                distance = results["distances"][0][i] if results["distances"] else 0.0
                
                incidents.append((incident_data, distance))
        
        return incidents
    
    def get_incident(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific incident by key.
        
        Args:
            key: Incident ID
        
        Returns:
            Incident data or None if not found
        """
        results = self.collection.get(ids=[key])
        
        if results and results["metadatas"]:
            metadata = results["metadatas"][0]
            return json.loads(metadata.get("data", "{}"))
        
        return None
    
    def delete_incident(self, key: str) -> bool:
        """
        Delete an incident from the knowledge base.
        
        Args:
            key: Incident ID
        
        Returns:
            True if deleted, False if not found
        """
        try:
            self.collection.delete(ids=[key])
            logger.debug(f"Deleted incident: {key}")
            return True
        except Exception as e:
            logger.warning(f"Could not delete {key}: {e}")
            return False
    
    def count(self) -> int:
        """Return the number of incidents in the knowledge base."""
        return self.collection.count()
    
    def list_all(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        List all incidents in the knowledge base.
        
        Args:
            limit: Maximum number to return
        
        Returns:
            List of incident dictionaries
        """
        results = self.collection.get(limit=limit)
        
        incidents = []
        if results and results["metadatas"]:
            for metadata in results["metadatas"]:
                incident_data = json.loads(metadata.get("data", "{}"))
                incidents.append(incident_data)
        
        return incidents


# =============================================================================
# RUNBOOK STORE
# =============================================================================

class RunbookStore:
    """
    Vector store for runbooks and documentation.
    
    Use this to store and search operational runbooks, documentation,
    and knowledge articles. When incidents occur, search for relevant
    runbooks to help with diagnosis and resolution.
    
    Attributes:
        collection: The ChromaDB collection
        persist_directory: Where data is stored on disk
    
    Example:
        >>> store = RunbookStore(persist_directory="./data/runbooks")
        >>> 
        >>> # Add runbook
        >>> store.add_runbook({
        ...     "id": "RB-001",
        ...     "title": "Database Connection Troubleshooting",
        ...     "content": "Steps to diagnose connection issues...",
        ...     "tags": ["database", "connections", "troubleshooting"],
        ... })
        >>> 
        >>> # Search
        >>> results = store.search("database timeout", k=3)
    """
    
    def __init__(
        self,
        persist_directory: Optional[str] = None,
        collection_name: str = "runbooks",
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
    ):
        """
        Initialize the runbook store.
        
        Args:
            persist_directory: Directory to store the database
            collection_name: Name of the ChromaDB collection
            embedding_model: sentence-transformers model for embeddings
        """
        try:
            import chromadb
        except ImportError:
            raise ImportError(
                "chromadb is required for RAG. "
                "Install with: pip install chromadb sentence-transformers"
            )
        
        # Set up persist directory
        if persist_directory is None:
            self.persist_directory = get_default_data_dir() / "runbooks"
        else:
            self.persist_directory = Path(persist_directory)
        
        self.persist_directory.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Runbook store using directory: {self.persist_directory}")
        
        # Initialize ChromaDB client
        self._client = chromadb.PersistentClient(path=str(self.persist_directory))
        
        # Get or create collection
        embedding_fn = _get_embedding_function(embedding_model)
        self.collection = self._client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_fn,
            metadata={"description": "Runbooks and documentation"},
        )
        
        logger.info(f"Runbook store initialized with {self.collection.count()} documents")
    
    def add_runbook(
        self,
        runbook: Dict[str, Any],
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
    ) -> List[str]:
        """
        Add a runbook to the store.
        
        Long runbooks are automatically split into chunks for better
        search relevance.
        
        Args:
            runbook: Dictionary with runbook data:
                - id: Runbook ID (required)
                - title: Title (required)
                - content: Full text content (required)
                - tags: List of tags (optional)
                - url: Link to source (optional)
            chunk_size: Maximum characters per chunk
            chunk_overlap: Overlap between chunks
        
        Returns:
            List of chunk IDs that were created
        """
        runbook_id = runbook.get("id", "")
        title = runbook.get("title", "")
        content = runbook.get("content", "")
        tags = runbook.get("tags", [])
        url = runbook.get("url", "")
        
        if not runbook_id or not title or not content:
            raise ValueError("Runbook must have 'id', 'title', and 'content'")
        
        # Split content into chunks
        chunks = self._split_text(content, chunk_size, chunk_overlap)
        
        chunk_ids = []
        for i, chunk in enumerate(chunks):
            chunk_id = f"{runbook_id}_chunk_{i}"
            
            # Build text for embedding (include title for context)
            text = f"{title}\n\n{chunk}"
            
            metadata = {
                "runbook_id": runbook_id,
                "title": title,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "tags": ",".join(tags) if tags else "",
                "url": url,
            }
            
            self.collection.upsert(
                ids=[chunk_id],
                documents=[text],
                metadatas=[metadata],
            )
            
            chunk_ids.append(chunk_id)
        
        logger.debug(f"Added runbook {runbook_id} ({len(chunks)} chunks)")
        return chunk_ids
    
    def _split_text(
        self,
        text: str,
        chunk_size: int,
        overlap: int,
    ) -> List[str]:
        """Split text into overlapping chunks."""
        if len(text) <= chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + chunk_size
            
            # Try to break at paragraph or sentence boundary
            if end < len(text):
                # Look for paragraph break
                break_point = text.rfind("\n\n", start, end)
                if break_point == -1 or break_point <= start:
                    # Look for sentence break
                    break_point = text.rfind(". ", start, end)
                if break_point > start:
                    end = break_point + 1
            
            chunks.append(text[start:end].strip())
            start = end - overlap
        
        return [c for c in chunks if c]  # Filter empty chunks
    
    def search(
        self,
        query: str,
        k: int = 5,
        filter_tags: Optional[List[str]] = None,
    ) -> List[Tuple[Dict[str, Any], float]]:
        """
        Search for relevant runbooks.
        
        Args:
            query: Search query (natural language)
            k: Number of results to return
            filter_tags: Optional list of tags to filter by
        
        Returns:
            List of (result_dict, score) tuples.
            result_dict contains: runbook_id, title, content, url, tags
        """
        # Build filter
        where_filter = None
        if filter_tags:
            # Note: ChromaDB doesn't support array contains, so we use string matching
            where_filter = {
                "$or": [{"tags": {"$contains": tag}} for tag in filter_tags]
            }
        
        results = self.collection.query(
            query_texts=[query],
            n_results=k,
            where=where_filter,
        )
        
        # Parse results
        items = []
        
        if results and results["metadatas"]:
            for i, metadata in enumerate(results["metadatas"][0]):
                result = {
                    "runbook_id": metadata.get("runbook_id", ""),
                    "title": metadata.get("title", ""),
                    "content": results["documents"][0][i] if results["documents"] else "",
                    "url": metadata.get("url", ""),
                    "tags": metadata.get("tags", "").split(",") if metadata.get("tags") else [],
                    "chunk_index": metadata.get("chunk_index", 0),
                    "total_chunks": metadata.get("total_chunks", 1),
                }
                
                distance = results["distances"][0][i] if results["distances"] else 0.0
                items.append((result, distance))
        
        return items
    
    def delete_runbook(self, runbook_id: str) -> int:
        """
        Delete a runbook and all its chunks.
        
        Args:
            runbook_id: Runbook ID
        
        Returns:
            Number of chunks deleted
        """
        # Find all chunks for this runbook
        results = self.collection.get(
            where={"runbook_id": runbook_id}
        )
        
        if results and results["ids"]:
            self.collection.delete(ids=results["ids"])
            logger.debug(f"Deleted runbook {runbook_id} ({len(results['ids'])} chunks)")
            return len(results["ids"])
        
        return 0
    
    def count(self) -> int:
        """Return the number of chunks in the store."""
        return self.collection.count()


# =============================================================================
# TESTING
# =============================================================================

if __name__ == "__main__":
    """
    Test the RAG functionality.
    
    Usage:
        python -m agent.rag
    """
    import tempfile
    
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    
    print("=" * 60)
    print("RAG Module Test")
    print("=" * 60)
    
    # Use temporary directory for testing
    with tempfile.TemporaryDirectory() as tmpdir:
        print(f"\nUsing temp directory: {tmpdir}")
        
        # Test Incident Knowledge Base
        print("\n" + "-" * 40)
        print("Test: IncidentKnowledgeBase")
        print("-" * 40)
        
        kb = IncidentKnowledgeBase(persist_directory=f"{tmpdir}/incidents")
        
        # Add test incidents
        kb.add_incident({
            "key": "INC-100",
            "summary": "Database connection pool exhausted",
            "description": "Production database showing max connections reached",
            "root_cause": "Connection leak in reporting microservice",
            "resolution": "Fixed connection leak, added connection pool monitoring",
        })
        
        kb.add_incident({
            "key": "INC-101",
            "summary": "API latency spike during peak hours",
            "description": "p99 latency increased from 100ms to 5 seconds",
            "root_cause": "Missing database index on frequently queried table",
            "resolution": "Added index, latency returned to normal",
        })
        
        kb.add_incident({
            "key": "INC-102",
            "summary": "Memory leak causing OOMKilled pods",
            "description": "API pods being killed due to memory exhaustion",
            "root_cause": "Unbounded in-memory cache without eviction",
            "resolution": "Implemented LRU cache with size limits",
        })
        
        print(f"Added {kb.count()} incidents")
        
        # Search
        print("\nSearching for 'connection timeout'...")
        results = kb.search("connection timeout", k=2)
        for incident, score in results:
            print(f"  {incident['key']}: {incident['summary']} (distance: {score:.3f})")
        
        print("\nSearching for 'memory issues'...")
        results = kb.search("memory issues", k=2)
        for incident, score in results:
            print(f"  {incident['key']}: {incident['summary']} (distance: {score:.3f})")
        
        # Test Runbook Store
        print("\n" + "-" * 40)
        print("Test: RunbookStore")
        print("-" * 40)
        
        store = RunbookStore(persist_directory=f"{tmpdir}/runbooks")
        
        # Add test runbook
        store.add_runbook({
            "id": "RB-001",
            "title": "Database Connection Troubleshooting",
            "content": """
# Database Connection Troubleshooting

## Symptoms
- Connection timeout errors
- "Too many connections" errors
- Slow database queries

## Diagnosis Steps
1. Check current connection count: SELECT count(*) FROM pg_stat_activity;
2. Identify long-running queries: SELECT * FROM pg_stat_activity WHERE state != 'idle';
3. Check connection pool settings in application config

## Resolution
1. Kill idle connections older than 5 minutes
2. Restart affected services if connection leak suspected
3. Increase connection pool max if within safe limits

## Prevention
- Monitor connection pool utilization
- Set up alerts at 80% capacity
- Implement connection timeouts
            """,
            "tags": ["database", "connections", "postgresql"],
        })
        
        print(f"Added runbook ({store.count()} chunks)")
        
        # Search
        print("\nSearching for 'connection timeout'...")
        results = store.search("connection timeout", k=2)
        for result, score in results:
            print(f"  {result['title']} (chunk {result['chunk_index']+1}/{result['total_chunks']}, distance: {score:.3f})")
        
        print("\n" + "=" * 60)
        print("✓ RAG tests passed!")
        print("=" * 60)
