"""
Production HTTP Server
======================

FastAPI server for production deployment. Provides:
- REST API for all agent operations
- Webhook endpoints for Jira, PagerDuty, Teams, etc.
- Health checks for Kubernetes
- Optional Celery integration (works without it too!)

Usage:
    # Run locally WITHOUT Celery (sync mode)
    uv run python -m agent.server
    
    # With uvicorn
    uvicorn agent.server:app --host 0.0.0.0 --port 8000
    
    # Test with curl
    curl -X POST http://localhost:8000/api/v1/triage \\
      -H "Content-Type: application/json" \\
      -d '{"content": "Our API is down! Getting 500 errors everywhere"}'

Environment:
    CELERY_ENABLED=false  # Disable Celery, run synchronously (default if no Redis)
    CELERY_ENABLED=true   # Enable async processing via Celery
"""

import asyncio
import json
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from fastapi import FastAPI, HTTPException, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

# Optional Redis import
try:
    import redis
except ImportError:
    redis = None  # type: ignore


# =============================================================================
# PYDANTIC MODELS - Flexible inputs
# =============================================================================

class TaskStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class SummarizeRequest(BaseModel):
    """Request to summarize an incident. Accepts structured or unstructured input."""
    # Structured fields (all optional)
    key: Optional[str] = Field(None, description="Incident ID")
    summary: Optional[str] = Field(None, description="Incident title")
    description: Optional[str] = Field(None, description="Incident description")
    status: Optional[str] = Field(None)
    priority: Optional[str] = Field(None)
    comments: Optional[Any] = Field(None)
    
    # OR: Raw unstructured input
    content: Optional[str] = Field(None, description="Raw text (paste from anywhere)")
    
    # Processing options
    async_mode: bool = Field(False, description="Use Celery async processing")


class TriageRequest(BaseModel):
    """Request to triage incoming message. Accepts structured or unstructured input."""
    # Structured fields (all optional)
    key: Optional[str] = Field(None, description="Ticket/message ID")
    summary: Optional[str] = Field(None, description="Subject/title")
    description: Optional[str] = Field(None, description="Full description")
    message: Optional[str] = Field(None, description="Message body")
    source: Optional[str] = Field(None, description="Source: teams, slack, jira, email, etc.")
    reporter: Optional[Union[str, Dict[str, Any]]] = Field(None)
    labels: Optional[List[str]] = Field(None)
    thread: Optional[List[Dict[str, Any]]] = Field(None, description="Conversation thread")
    
    # OR: Raw unstructured input
    content: Optional[str] = Field(None, description="Raw text (paste from anywhere)")
    
    # Processing options
    async_mode: bool = Field(False, description="Use Celery async processing")


class RCARequest(BaseModel):
    """Request for root cause analysis. Accepts structured or unstructured input."""
    # Structured fields (all optional)
    key: Optional[str] = Field(None)
    summary: Optional[str] = Field(None)
    description: Optional[str] = Field(None)
    code_changes: Optional[List[Dict[str, Any]]] = Field(None)
    related_incidents: Optional[List[Dict[str, Any]]] = Field(None)
    
    # OR: Raw unstructured input
    content: Optional[str] = Field(None, description="Raw text (paste from anywhere)")
    
    # Processing options
    async_mode: bool = Field(False, description="Use Celery async processing")


class ChatRequest(BaseModel):
    """Chat request."""
    message: str
    context: Optional[Dict[str, Any]] = None
    conversation_id: Optional[str] = None


class TaskResponse(BaseModel):
    task_id: str
    status: TaskStatus
    message: str
    result: Optional[Any] = None
    result_url: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    mode: str  # "sync" or "async"
    dependencies: Dict[str, str]


# =============================================================================
# GLOBALS & HELPERS
# =============================================================================

_redis_client = None
_agent = None
_celery_enabled = None


def get_redis():
    """Get Redis client (optional)."""
    global _redis_client
    if redis is None:
        return None
    if _redis_client is None:
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        try:
            _redis_client = redis.from_url(redis_url, decode_responses=True)
            _redis_client.ping()
        except Exception:
            _redis_client = None
    return _redis_client


def is_celery_enabled() -> bool:
    """Check if Celery should be used."""
    global _celery_enabled
    if _celery_enabled is not None:
        return _celery_enabled
    
    # Check explicit setting
    env_val = os.getenv("CELERY_ENABLED", "").lower()
    if env_val == "true":
        _celery_enabled = True
    elif env_val == "false":
        _celery_enabled = False
    else:
        # Auto-detect: enable if Redis is available
        _celery_enabled = get_redis() is not None
    
    return _celery_enabled


def get_agent():
    """Get or create the SRE agent."""
    global _agent
    if _agent is None:
        from .agent import SREAgent
        _agent = SREAgent()
    return _agent


async def check_rate_limit(request: Request, x_api_key: Optional[str] = Header(None)):
    """Rate limiting dependency (optional, requires Redis)."""
    redis_client = get_redis()
    if not redis_client:
        return
    
    client_id = x_api_key or (request.client.host if request.client else "unknown")
    key = f"ratelimit:{client_id}:{datetime.utcnow().minute}"
    
    try:
        count = redis_client.incr(key)
        if count == 1:
            redis_client.expire(key, 60)
        if count > 60:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        request.state.rate_limit_remaining = max(0, 60 - count)
    except HTTPException:
        raise
    except Exception:
        pass


def request_to_dict(request: BaseModel) -> Union[Dict[str, Any], str]:
    """Convert request to dict or string for agent."""
    data = request.model_dump(exclude_none=True, exclude={"async_mode"})
    
    # If only 'content' provided, return raw string
    if "content" in data:
        content = data.pop("content")
        if not data:  # No other fields
            return content
        # Mix of structured + content - merge them
        data["description"] = data.get("description", "") + "\n\n" + content
    
    return data if data else ""


# =============================================================================
# LIFESPAN
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown."""
    print("=" * 60)
    print("AI SRE Agent API Server")
    print("=" * 60)
    
    # Check LLM
    llm_base_url = os.getenv("LLM_BASE_URL")
    if not llm_base_url:
        print("⚠️  WARNING: LLM_BASE_URL not set - agent won't work!")
    else:
        print(f"✓ LLM server: {llm_base_url}")
    
    if os.getenv("LLM_API_KEY"):
        print("✓ LLM API key configured")
    
    # Check mode
    if is_celery_enabled():
        print("✓ Mode: ASYNC (Celery + Redis)")
        print(f"  Redis: {os.getenv('REDIS_URL', 'redis://localhost:6379/0')}")
    else:
        print("✓ Mode: SYNC (no Celery required)")
    
    # Check RAG
    try:
        agent = get_agent()
        if agent.rag_enabled:
            incident_count = agent.incident_kb.count() if agent.incident_kb else 0
            runbook_count = agent.runbook_store.count() if agent.runbook_store else 0
            print(f"✓ RAG enabled: {incident_count} incidents, {runbook_count} runbook chunks")
            print(f"  Data dir: {os.getenv('SRE_AGENT_DATA_DIR', '~/.local/share/ai-sre-agent/')}")
        else:
            print("⚠️  RAG disabled (chromadb not installed or RAG_ENABLED=false)")
    except Exception as e:
        print(f"⚠️  Agent init warning: {e}")
    
    # Check MCP services configured
    mcp_services = []
    if os.getenv("JIRA_URL"):
        mcp_services.append("Jira")
    if os.getenv("CONFLUENCE_URL"):
        mcp_services.append("Confluence")
    if os.getenv("GITLAB_URL"):
        mcp_services.append("GitLab")
    
    if mcp_services:
        print(f"✓ MCP services: {', '.join(mcp_services)}")
    else:
        print("ℹ️  No MCP services configured (set JIRA_URL, CONFLUENCE_URL, GITLAB_URL)")
    
    # Check for K8s socket mode
    for name in ["JIRA", "CONFLUENCE", "GITLAB"]:
        socket = os.getenv(f"MCP_{name}_SOCKET")
        if socket:
            print(f"  {name} socket: {socket}")
    
    print("=" * 60)
    print("Ready! Try: curl http://localhost:8000/health/ready")
    print("=" * 60)
    
    yield
    
    print("Shutting down...")


# =============================================================================
# APP
# =============================================================================

app = FastAPI(
    title="AI SRE Agent API",
    description="AI-powered SRE agent for incident management and triage",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# HEALTH ENDPOINTS
# =============================================================================

@app.get("/", include_in_schema=False)
async def root():
    return {"name": "AI SRE Agent", "version": "0.3.0", "docs": "/docs"}


@app.get("/health/live")
async def health_live():
    """Kubernetes liveness probe."""
    return {"status": "ok"}


@app.get("/health/ready", response_model=HealthResponse)
async def health_ready():
    """Kubernetes readiness probe."""
    dependencies = {
        "redis": "connected" if get_redis() else "not available",
        "llm": "configured" if os.getenv("LLM_BASE_URL") else "NOT CONFIGURED",
    }
    
    # Check RAG
    try:
        agent = get_agent()
        if agent.rag_enabled:
            incident_count = agent.incident_kb.count() if agent.incident_kb else 0
            dependencies["rag"] = f"enabled ({incident_count} incidents)"
        else:
            dependencies["rag"] = "disabled"
    except Exception:
        dependencies["rag"] = "error"
    
    # Check MCP services configured
    for name, env_var in [("jira", "JIRA_URL"), ("confluence", "CONFLUENCE_URL"), ("gitlab", "GITLAB_URL")]:
        if os.getenv(env_var):
            dependencies[f"mcp_{name}"] = "configured"
    
    status = "ok" if dependencies["llm"] == "configured" else "degraded"
    mode = "async" if is_celery_enabled() else "sync"
    
    return HealthResponse(
        status=status, 
        version="0.3.0", 
        mode=mode,
        dependencies=dependencies,
    )


# =============================================================================
# API ENDPOINTS
# =============================================================================

class InvestigateRequest(BaseModel):
    """Request to investigate an incident or issue."""
    query: str = Field(..., description="Description of what to investigate")
    context: Optional[Dict[str, Any]] = Field(None, description="Additional context")


@app.post("/api/v1/investigate")
async def investigate(request: InvestigateRequest, _: None = Depends(check_rate_limit)):
    """
    Investigate an incident using all available tools.
    
    The agent will autonomously:
    - Search for similar past incidents
    - Query Jira for related issues
    - Check Confluence for runbooks
    - Look at recent GitLab changes
    
    Example:
        {"query": "INC-123 - Database connection timeouts affecting checkout"}
    """
    agent = get_agent()
    result = await agent.investigate(request.query, request.context)
    return {"result": result}

@app.post("/api/v1/summarize")
async def summarize_incident(request: SummarizeRequest, _: None = Depends(check_rate_limit)):
    """
    Summarize an incident.
    
    Accepts either structured data or raw text paste.
    
    Examples:
        # Structured
        {"key": "INC-123", "summary": "DB down", "description": "..."}
        
        # Unstructured (raw paste from incident bridge)
        {"content": "[10:00] @oncall: Database is down\\n[10:05] @sre: Investigating..."}
    """
    data = request_to_dict(request)
    
    if request.async_mode and is_celery_enabled():
        from .tasks import summarize_incident as task_fn
        task = task_fn.delay(data, {})
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    
    # Sync mode
    agent = get_agent()
    result = await agent.summarize_incident(data)
    return TaskResponse(
        task_id="sync",
        status=TaskStatus.COMPLETED,
        message="Completed",
        result=result,
    )


@app.post("/api/v1/triage")
async def triage_request(request: TriageRequest, _: None = Depends(check_rate_limit)):
    """
    Triage an incoming request from any source.
    
    Works with tickets, Teams messages, Slack, email, incident bridges, etc.
    Accepts either structured data or raw text paste.
    
    Examples:
        # Structured (from ticket system)
        {"key": "SUP-456", "summary": "Login broken", "source": "jira"}
        
        # Unstructured (paste from Teams)
        {"content": "@SRE-Support our API is returning 500 errors!"}
        
        # Unstructured (paste from incident bridge)
        {"content": "[INCIDENT] Production down, 100% error rate"}
    """
    data = request_to_dict(request)
    
    if request.async_mode and is_celery_enabled():
        from .tasks import triage_ticket as task_fn
        task = task_fn.delay(data, {})
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    
    # Sync mode
    agent = get_agent()
    result = await agent.triage(data)
    return TaskResponse(
        task_id="sync",
        status=TaskStatus.COMPLETED,
        message="Completed",
        result=result,
    )


@app.post("/api/v1/rca")
async def analyze_root_cause(request: RCARequest, _: None = Depends(check_rate_limit)):
    """
    Perform root cause analysis.
    
    Accepts either structured data or raw text paste.
    """
    data = request_to_dict(request)
    
    if request.async_mode and is_celery_enabled():
        from .tasks import analyze_root_cause as task_fn
        task = task_fn.delay(data, request.code_changes, request.related_incidents)
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    
    # Sync mode
    agent = get_agent()
    result = await agent.analyze_root_cause(
        data,
        code_changes=request.code_changes,
        related_incidents=request.related_incidents,
    )
    return TaskResponse(
        task_id="sync",
        status=TaskStatus.COMPLETED,
        message="Completed",
        result=result,
    )


@app.post("/api/v1/chat")
async def chat(request: ChatRequest, _: None = Depends(check_rate_limit)):
    """Chat with the SRE agent."""
    agent = get_agent()
    result = await agent.chat(request.message, request.context)
    return {
        "response": result,
        "conversation_id": request.conversation_id or str(uuid.uuid4()),
    }


@app.get("/api/v1/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Get async task status and result (requires Celery)."""
    if not is_celery_enabled():
        raise HTTPException(400, "Async mode not enabled")
    
    from .tasks import make_celery
    celery = make_celery()
    result = celery.AsyncResult(task_id)
    
    if result.ready():
        if result.successful():
            return {"task_id": task_id, "status": "completed", "result": result.result}
        else:
            return {"task_id": task_id, "status": "failed", "error": str(result.result)}
    elif result.status == "PENDING":
        return {"task_id": task_id, "status": "pending"}
    else:
        return {"task_id": task_id, "status": "processing"}


# =============================================================================
# RAG MANAGEMENT ENDPOINTS
# =============================================================================

class IncidentInput(BaseModel):
    """Input for adding an incident to the knowledge base."""
    key: str = Field(..., description="Unique incident ID")
    summary: str = Field(..., description="Incident title")
    description: Optional[str] = Field(None)
    root_cause: Optional[str] = Field(None, description="Known root cause")
    resolution: Optional[str] = Field(None, description="How it was resolved")
    labels: Optional[List[str]] = Field(None)


class RunbookInput(BaseModel):
    """Input for adding a runbook."""
    id: str = Field(..., description="Unique runbook ID")
    title: str = Field(..., description="Runbook title")
    content: str = Field(..., description="Full runbook content (markdown)")
    tags: Optional[List[str]] = Field(None)


class SearchQuery(BaseModel):
    """Search query input."""
    query: str = Field(..., description="Search text")
    k: int = Field(5, description="Number of results", ge=1, le=20)


@app.get("/api/v1/rag/status")
async def rag_status():
    """Get RAG system status."""
    agent = get_agent()
    
    if not agent.rag_enabled:
        return {
            "enabled": False,
            "message": "RAG not available (install chromadb or set RAG_ENABLED=true)",
        }
    
    return {
        "enabled": True,
        "incidents": agent.incident_kb.count() if agent.incident_kb else 0,
        "runbook_chunks": agent.runbook_store.count() if agent.runbook_store else 0,
        "data_dir": os.getenv("SRE_AGENT_DATA_DIR", "~/.local/share/ai-sre-agent/"),
    }


@app.post("/api/v1/rag/incidents")
async def add_incident_to_kb(incident: IncidentInput):
    """Add an incident to the knowledge base for future similarity searches."""
    agent = get_agent()
    
    if not agent.rag_enabled:
        raise HTTPException(400, "RAG not enabled")
    
    result = agent.add_incident(incident.model_dump(exclude_none=True))
    
    return {
        "status": "added",
        "key": result,
        "total_incidents": agent.incident_kb.count(),
    }


@app.post("/api/v1/rag/runbooks")
async def add_runbook_to_store(runbook: RunbookInput):
    """Add a runbook to the store."""
    agent = get_agent()
    
    if not agent.rag_enabled:
        raise HTTPException(400, "RAG not enabled")
    
    chunk_ids = agent.add_runbook(runbook.model_dump(exclude_none=True))
    
    return {
        "status": "added",
        "id": runbook.id,
        "chunks": len(chunk_ids) if chunk_ids else 0,
        "total_chunks": agent.runbook_store.count(),
    }


@app.post("/api/v1/rag/search/incidents")
async def search_incidents(query: SearchQuery):
    """Search for similar incidents."""
    agent = get_agent()
    
    if not agent.rag_enabled:
        raise HTTPException(400, "RAG not enabled")
    
    results = agent.search_incidents(query.query, k=query.k)
    
    return {
        "query": query.query,
        "count": len(results),
        "results": results,
    }


@app.post("/api/v1/rag/search/runbooks")
async def search_runbooks(query: SearchQuery):
    """Search for relevant runbooks."""
    agent = get_agent()
    
    if not agent.rag_enabled:
        raise HTTPException(400, "RAG not enabled")
    
    results = agent.search_runbooks(query.query, k=query.k)
    
    return {
        "query": query.query,
        "count": len(results),
        "results": results,
    }


@app.get("/api/v1/rag/incidents")
async def list_incidents(limit: int = 50):
    """List all incidents in the knowledge base."""
    agent = get_agent()
    
    if not agent.rag_enabled or not agent.incident_kb:
        raise HTTPException(400, "RAG not enabled")
    
    incidents = agent.incident_kb.list_all(limit=limit)
    
    return {
        "count": len(incidents),
        "total": agent.incident_kb.count(),
        "incidents": incidents,
    }


# =============================================================================
# WEBHOOK ENDPOINTS
# =============================================================================

@app.post("/webhooks/jira")
async def jira_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Handle Jira webhooks."""
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    event = payload.get("webhookEvent", "")
    issue = payload.get("issue", {})
    
    if event not in ["jira:issue_created", "jira:issue_updated"]:
        return {"status": "ignored", "event": event}
    
    fields = issue.get("fields", {})
    data = {
        "key": issue.get("key", "UNKNOWN"),
        "summary": fields.get("summary", ""),
        "description": fields.get("description", ""),
        "status": fields.get("status", {}).get("name"),
        "priority": fields.get("priority", {}).get("name"),
        "labels": fields.get("labels", []),
        "source": "jira",
    }
    
    agent = get_agent()
    
    # Determine if incident or support request
    is_incident = (
        fields.get("issuetype", {}).get("name", "").lower() == "incident"
        or data["key"].startswith("INC-")
    )
    
    if is_incident:
        result = await agent.summarize_incident(data)
    else:
        result = await agent.triage(data)
    
    return {"status": "processed", "issue_key": data["key"], "result": result}


@app.post("/webhooks/teams")
async def teams_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Handle MS Teams webhooks (incoming messages)."""
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    # Extract message from Teams payload
    message_text = payload.get("text", "")
    sender = payload.get("from", {}).get("name", "Unknown")
    channel = payload.get("channelData", {}).get("channel", {}).get("name", "Unknown")
    
    data = {
        "message": message_text,
        "reporter": sender,
        "source": "teams",
        "channel": channel,
    }
    
    agent = get_agent()
    result = await agent.triage(data)
    
    return {"status": "processed", "result": result}


@app.post("/webhooks/pagerduty")
async def pagerduty_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Handle PagerDuty webhooks."""
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    event = payload.get("event", {})
    event_type = event.get("event_type", "")
    
    if event_type != "incident.triggered":
        return {"status": "ignored", "event_type": event_type}
    
    incident = event.get("data", {})
    data = {
        "key": incident.get("id", f"PD-{uuid.uuid4().hex[:8]}"),
        "summary": incident.get("title", ""),
        "description": incident.get("description", ""),
        "status": "triggered",
        "priority": incident.get("urgency", "high"),
        "source": "pagerduty",
    }
    
    agent = get_agent()
    result = await agent.summarize_incident(data)
    
    return {"status": "processed", "result": result}


@app.post("/webhooks/generic")
async def generic_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """
    Generic webhook for custom integrations.
    
    Payload format:
        {"action": "triage|summarize|rca|chat", "data": {...} or "content": "..."}
    """
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    action = payload.get("action", "triage")
    data = payload.get("data") or payload.get("content") or payload
    
    agent = get_agent()
    
    if action == "summarize":
        result = await agent.summarize_incident(data)
    elif action == "triage":
        result = await agent.triage(data)
    elif action == "rca":
        result = await agent.analyze_root_cause(data)
    elif action == "chat":
        message = data.get("message") if isinstance(data, dict) else str(data)
        result = await agent.chat(message)
    else:
        raise HTTPException(400, f"Unknown action: {action}")
    
    return {"status": "processed", "action": action, "result": result}


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "agent.server:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("DEBUG", "").lower() == "true",
    )
