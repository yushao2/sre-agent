"""
Production HTTP Server
======================

FastAPI server for production deployment. Provides:
- REST API for all agent operations
- Webhook endpoints for Jira, PagerDuty, etc.
- Health checks for Kubernetes
- Rate limiting via Redis

Usage:
    # Run directly
    python -m agent.server
    
    # With uvicorn
    uvicorn agent.server:app --host 0.0.0.0 --port 8000
"""

import json
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Optional Redis import
try:
    import redis
except ImportError:
    redis = None  # type: ignore


# =============================================================================
# PYDANTIC MODELS
# =============================================================================

class TaskStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class IncidentData(BaseModel):
    key: str = Field(..., description="Incident key (e.g., INC-123)")
    summary: str = Field(..., description="Incident title")
    description: Optional[str] = Field(None)
    status: Optional[str] = Field(None)
    priority: Optional[str] = Field(None)
    assignee: Optional[Dict[str, Any]] = Field(None)
    labels: Optional[List[str]] = Field(default_factory=list)
    comments: Optional[Dict[str, Any]] = Field(None)


class TicketData(BaseModel):
    key: str
    summary: str
    description: Optional[str] = None
    reporter: Optional[Dict[str, Any]] = None
    labels: Optional[List[str]] = Field(default_factory=list)


class SummarizeRequest(BaseModel):
    incident: IncidentData
    format: str = Field("markdown")
    async_mode: bool = Field(True)


class TriageRequest(BaseModel):
    ticket: TicketData
    async_mode: bool = Field(True)


class RCARequest(BaseModel):
    incident: IncidentData
    code_changes: Optional[List[Dict[str, Any]]] = None
    related_incidents: Optional[List[Dict[str, Any]]] = None
    async_mode: bool = Field(True)


class ChatRequest(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None
    conversation_id: Optional[str] = None
    async_mode: bool = Field(False)


class TaskResponse(BaseModel):
    task_id: str
    status: TaskStatus
    message: str
    result_url: Optional[str] = None


class HealthResponse(BaseModel):
    status: str
    version: str
    dependencies: Dict[str, str]


# =============================================================================
# HELPERS
# =============================================================================

_redis_client = None


def get_redis():
    """Get Redis client."""
    global _redis_client
    if redis is None:
        return None
    if _redis_client is None:
        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        try:
            _redis_client = redis.from_url(redis_url, decode_responses=True)
            _redis_client.ping()
        except Exception:
            _redis_client = None
    return _redis_client


def get_celery():
    """Get Celery app."""
    from .tasks import celery
    return celery


async def check_rate_limit(request: Request, x_api_key: Optional[str] = Header(None)):
    """Rate limiting dependency."""
    redis_client = get_redis()
    if not redis_client:
        return
    
    client_id = x_api_key or (request.client.host if request.client else "unknown")
    key = f"ratelimit:{client_id}:{datetime.utcnow().minute}"
    
    try:
        count = redis_client.incr(key)
        if count == 1:
            redis_client.expire(key, 60)
        if count > 60:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        request.state.rate_limit_remaining = max(0, 60 - count)
    except HTTPException:
        raise
    except Exception:
        pass


# =============================================================================
# LIFESPAN
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown."""
    print("=" * 60)
    print("Starting AI SRE Agent API Server")
    print("=" * 60)
    
    llm_base_url = os.getenv("LLM_BASE_URL")
    if not llm_base_url:
        print("⚠️  WARNING: LLM_BASE_URL not set")
    else:
        print(f"✓ LLM server: {llm_base_url}")
    
    if os.getenv("LLM_API_KEY"):
        print("✓ LLM API key configured")
    
    if get_redis():
        print("✓ Redis connected")
    else:
        print("⚠️  Redis not available")
    
    print("=" * 60)
    yield
    print("Shutting down...")


# =============================================================================
# APP
# =============================================================================

app = FastAPI(
    title="AI SRE Agent API",
    description="Production API for AI-powered incident management",
    version="0.3.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =============================================================================
# HEALTH ENDPOINTS
# =============================================================================

@app.get("/", include_in_schema=False)
async def root():
    return {"name": "AI SRE Agent", "version": "0.3.0", "docs": "/docs"}


@app.get("/health/live")
async def health_live():
    """Kubernetes liveness probe."""
    return {"status": "ok"}


@app.get("/health/ready", response_model=HealthResponse)
async def health_ready():
    """Kubernetes readiness probe."""
    dependencies = {
        "redis": "connected" if get_redis() else "disconnected",
        "llm": "configured" if os.getenv("LLM_BASE_URL") else "not configured",
    }
    status = "ok" if dependencies["llm"] == "configured" else "degraded"
    return HealthResponse(status=status, version="0.3.0", dependencies=dependencies)


# =============================================================================
# API ENDPOINTS
# =============================================================================

@app.post("/api/v1/summarize", response_model=TaskResponse)
async def summarize_incident(request: SummarizeRequest, _: None = Depends(check_rate_limit)):
    """Summarize an incident."""
    from .tasks import summarize_incident as task_fn
    
    incident_dict = request.incident.model_dump()
    
    if request.async_mode:
        task = task_fn.delay(incident_dict, {"format": request.format})
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    else:
        result = task_fn.apply(args=[incident_dict, {}]).get(timeout=120)
        return TaskResponse(task_id="sync", status=TaskStatus.COMPLETED, message="Completed")


@app.post("/api/v1/triage", response_model=TaskResponse)
async def triage_ticket(request: TriageRequest, _: None = Depends(check_rate_limit)):
    """Triage a support ticket."""
    from .tasks import triage_ticket as task_fn
    
    ticket_dict = request.ticket.model_dump()
    
    if request.async_mode:
        task = task_fn.delay(ticket_dict, {})
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    else:
        result = task_fn.apply(args=[ticket_dict, {}]).get(timeout=120)
        return TaskResponse(task_id="sync", status=TaskStatus.COMPLETED, message="Completed")


@app.post("/api/v1/rca", response_model=TaskResponse)
async def analyze_root_cause(request: RCARequest, _: None = Depends(check_rate_limit)):
    """Root cause analysis."""
    from .tasks import analyze_root_cause as task_fn
    
    incident_dict = request.incident.model_dump()
    
    if request.async_mode:
        task = task_fn.delay(incident_dict, request.code_changes, request.related_incidents)
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    else:
        result = task_fn.apply(args=[incident_dict, None, None]).get(timeout=120)
        return TaskResponse(task_id="sync", status=TaskStatus.COMPLETED, message="Completed")


@app.post("/api/v1/chat")
async def chat(request: ChatRequest, _: None = Depends(check_rate_limit)):
    """Chat with the SRE agent."""
    from .tasks import chat_completion as task_fn
    
    if request.async_mode:
        task = task_fn.delay(request.message, request.context, request.conversation_id)
        return TaskResponse(
            task_id=task.id,
            status=TaskStatus.PENDING,
            message="Task queued",
            result_url=f"/api/v1/tasks/{task.id}",
        )
    else:
        result = task_fn.apply(args=[request.message, request.context, None]).get(timeout=60)
        return {"response": result.get("response"), "conversation_id": request.conversation_id}


@app.get("/api/v1/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Get task status and result."""
    from .tasks import celery
    
    result = celery.AsyncResult(task_id)
    
    if result.ready():
        if result.successful():
            return {"task_id": task_id, "status": "completed", "result": result.result}
        else:
            return {"task_id": task_id, "status": "failed", "error": str(result.result)}
    elif result.status == "PENDING":
        return {"task_id": task_id, "status": "pending"}
    else:
        return {"task_id": task_id, "status": "processing"}


# =============================================================================
# WEBHOOK ENDPOINTS
# =============================================================================

@app.post("/webhooks/jira")
async def jira_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Handle Jira webhooks."""
    from .tasks import summarize_incident, triage_ticket
    
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    event = payload.get("webhookEvent", "")
    issue = payload.get("issue", {})
    issue_key = issue.get("key", "UNKNOWN")
    
    if event not in ["jira:issue_created", "jira:issue_updated"]:
        return {"status": "ignored", "event": event}
    
    fields = issue.get("fields", {})
    data = {
        "key": issue_key,
        "summary": fields.get("summary", ""),
        "description": fields.get("description", ""),
        "status": fields.get("status", {}).get("name"),
        "priority": fields.get("priority", {}).get("name"),
        "labels": fields.get("labels", []),
    }
    
    is_incident = (
        fields.get("issuetype", {}).get("name", "").lower() == "incident"
        or issue_key.startswith("INC-")
    )
    
    if is_incident:
        task = summarize_incident.delay(data, {})
    else:
        task = triage_ticket.delay(data, {})
    
    return {"status": "queued", "task_id": task.id, "issue_key": issue_key}


@app.post("/webhooks/pagerduty")
async def pagerduty_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Handle PagerDuty webhooks."""
    from .tasks import summarize_incident
    
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    event = payload.get("event", {})
    event_type = event.get("event_type", "")
    
    if event_type != "incident.triggered":
        return {"status": "ignored", "event_type": event_type}
    
    incident = event.get("data", {})
    data = {
        "key": incident.get("id", f"PD-{uuid.uuid4().hex[:8]}"),
        "summary": incident.get("title", ""),
        "description": incident.get("description", ""),
        "status": "triggered",
        "priority": incident.get("urgency", "high"),
    }
    
    task = summarize_incident.delay(data, {})
    return {"status": "queued", "task_id": task.id}


@app.post("/webhooks/generic")
async def generic_webhook(request: Request, _: None = Depends(check_rate_limit)):
    """Generic webhook for custom integrations."""
    from .tasks import summarize_incident, triage_ticket, analyze_root_cause, chat_completion
    
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(400, "Invalid JSON")
    
    action = payload.get("action", "")
    data = payload.get("data", {})
    
    task_map = {
        "summarize": lambda: summarize_incident.delay(data, {}),
        "triage": lambda: triage_ticket.delay(data, {}),
        "rca": lambda: analyze_root_cause.delay(data, None, None),
        "chat": lambda: chat_completion.delay(data.get("message", ""), data.get("context")),
    }
    
    if action not in task_map:
        raise HTTPException(400, f"Unknown action: {action}")
    
    task = task_map[action]()
    return {"status": "queued", "task_id": task.id, "action": action}


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "agent.server:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("DEBUG", "").lower() == "true",
    )
