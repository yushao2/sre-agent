"""
CLI Entry Point
===============

This module provides the main CLI entry point installed as 'sre-agent'.

Usage:
    sre-agent interactive    # Start interactive chat
    sre-agent chat "..."     # Quick chat
    sre-agent demo           # Run demo
"""

from .local import main

if __name__ == "__main__":
    main()
