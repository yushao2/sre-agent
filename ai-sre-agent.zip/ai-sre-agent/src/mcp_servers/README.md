# MCP Servers

Model Context Protocol (MCP) servers providing **read-only** access to external systems.

## Available Servers

| Server | Package | External System |
|--------|---------|-----------------|
| Jira | `mcp_servers.jira` | Jira Data Center |
| Confluence | `mcp_servers.confluence` | Confluence Data Center |
| GitLab | `mcp_servers.gitlab` | GitLab (self-hosted) |

## Transport Modes

All servers support two transport modes:

### 1. Stdio Mode (Local Development)

Standard MCP protocol over stdin/stdout. Used when running locally.

```bash
# Run directly
uv run mcp-jira

# Or as Python module
uv run python -m mcp_servers.jira.server
```

### 2. Unix Socket Mode (Kubernetes)

MCP protocol over Unix sockets. Used in Kubernetes sidecar pattern.

```bash
# Specify socket path via argument
uv run mcp-jira --socket /sockets/jira.sock

# Or via environment variable
export MCP_SOCKET=/sockets/jira.sock
uv run mcp-jira
```

## Kubernetes Sidecar Architecture

In Kubernetes, MCP servers run as sidecars in the same pod as the agent:

```
┌─────────────────────────────────────────────────────────────────┐
│                         Kubernetes Pod                           │
│                                                                  │
│  ┌──────────────────┐     Unix Socket      ┌──────────────────┐ │
│  │   Main Container │   /sockets/jira.sock │  Sidecar: Jira   │ │
│  │   (SRE Agent)    │◄───────────────────►│  MCP Server      │ │
│  │                  │                      └──────────────────┘ │
│  │                  │   /sockets/conf.sock ┌──────────────────┐ │
│  │                  │◄───────────────────►│  Sidecar: Conf   │ │
│  │                  │                      └──────────────────┘ │
│  │                  │   /sockets/gl.sock   ┌──────────────────┐ │
│  │                  │◄───────────────────►│  Sidecar: GitLab │ │
│  └──────────────────┘                      └──────────────────┘ │
│                                                                  │
│           Shared Volume: emptyDir at /sockets                    │
└─────────────────────────────────────────────────────────────────┘
```

**Benefits:**
- No custom HTTP transport needed
- Uses MCP's native stdio protocol
- Unix sockets are fast (no network overhead)
- Secure (pod-local, no network exposure)
- Same code works locally and in K8s

See [docs/MCP_STDIO_KUBERNETES.md](../../docs/MCP_STDIO_KUBERNETES.md) for details.

## Configuration

### Jira Data Center

| Variable | Description |
|----------|-------------|
| `JIRA_URL` | Jira server URL (e.g., `https://jira.company.com`) |
| `JIRA_USERNAME` | Your Jira username |
| `JIRA_TOKEN` | Personal Access Token (PAT) |
| `JIRA_VERIFY_SSL` | Verify SSL certs (default: `true`) |

**Available Tools:**
- `search_issues` - Search issues using JQL
- `get_issue` - Get issue details by key
- `get_issue_comments` - Get comments on an issue
- `list_projects` - List accessible projects

### Confluence Data Center

| Variable | Description |
|----------|-------------|
| `CONFLUENCE_URL` | Confluence server URL |
| `CONFLUENCE_USERNAME` | Your Confluence username |
| `CONFLUENCE_TOKEN` | Personal Access Token |
| `CONFLUENCE_VERIFY_SSL` | Verify SSL certs (default: `true`) |

**Available Tools:**
- `search_pages` - Search pages by text or CQL
- `get_page` - Get page content by ID
- `get_page_by_title` - Get page by space and title
- `list_spaces` - List accessible spaces

### GitLab (Self-Hosted)

| Variable | Description |
|----------|-------------|
| `GITLAB_URL` | GitLab server URL (e.g., `https://gitlab.company.com`) |
| `GITLAB_TOKEN` | Personal Access Token with `read_api` scope |
| `GITLAB_VERIFY_SSL` | Verify SSL certs (default: `true`) |

**Available Tools:**
- `list_projects` - List accessible projects
- `get_project` - Get project details
- `list_merge_requests` - List MRs for a project
- `get_merge_request` - Get MR details with changes
- `list_pipelines` - List pipelines for a project
- `get_file_content` - Get file content from repo

## Using from Agent Code

The agent auto-detects MCP servers based on environment:

```python
from agent.mcp_client import MCPClientManager

async with MCPClientManager() as manager:
    # Search Jira
    issues = await manager.call_tool("jira", "search_issues", {
        "jql": "project = INC ORDER BY created DESC",
        "max_results": 10,
    })
    
    # Search Confluence
    pages = await manager.call_tool("confluence", "search_pages", {
        "query": "runbook database",
        "space_key": "OPS",
    })
    
    # List GitLab MRs
    mrs = await manager.call_tool("gitlab", "list_merge_requests", {
        "project_id": 123,
        "state": "opened",
    })
```

## Socket Bridge Implementation

The `socket_bridge.py` module provides the Unix socket wrapper:

```python
from mcp_servers.socket_bridge import run_with_socket

# In your MCP server:
if __name__ == "__main__":
    run_with_socket(server)  # Auto-detects stdio vs socket mode
```

Key components:
- `UnixSocketMCPServer` - Wraps MCP server for socket communication
- `SocketReadStream` / `SocketWriteStream` - Stream adapters
- `run_with_socket()` - Entry point with auto-detection

## Security Notes

1. **Read-Only**: All servers are intentionally read-only
2. **Tokens**: Use Personal Access Tokens with minimal required permissions
3. **SSL**: Keep `VERIFY_SSL=true` in production
4. **Network**: In K8s, socket files are pod-local (not exposed)
5. **Secrets**: Store credentials in Kubernetes Secrets

## Adding New MCP Servers

1. Create directory: `src/mcp_servers/yourservice/`
2. Implement `server.py` with MCP tools
3. Add `main_sync()` entry point using `run_with_socket()`
4. Add to `pyproject.toml` entry points
5. Add to Helm chart as sidecar
