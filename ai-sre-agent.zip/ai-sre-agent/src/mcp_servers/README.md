# MCP Servers

Model Context Protocol (MCP) servers that provide **read-only** access to external systems.

## Overview

These MCP servers allow the AI SRE Agent to query information from:
- **Jira Data Center** - Issues, projects, comments
- **Confluence Data Center** - Pages, spaces, search
- **GitLab (self-hosted)** - Projects, merge requests, pipelines

All servers are **read-only** by design - they cannot create, update, or delete anything.

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   AI SRE Agent  │────▶│   MCP Server    │────▶│  External API   │
│                 │◀────│  (read-only)    │◀────│  (Jira, etc.)   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │
        │    stdio (local)      │    HTTP (Jira/Confluence/GitLab API)
        │    or HTTP (prod)     │
```

## Running Modes

### Local Development (stdio)

MCP servers communicate via stdin/stdout. This is ideal for local development.

```bash
# Run Jira MCP server
export JIRA_URL=https://jira.company.com
export JIRA_USERNAME=your-username
export JIRA_TOKEN=your-token
python -m mcp_servers.jira.server

# The server reads from stdin and writes to stdout
# It's designed to be spawned by an MCP client
```

### Production (HTTP)

For production, run as HTTP servers behind a load balancer.

```bash
# Run with uvicorn (HTTP mode would need additional wrapper)
# See docker-compose.yml for production setup
```

## Jira Data Center

### Configuration

| Variable | Description |
|----------|-------------|
| `JIRA_URL` | Jira server URL (e.g., `https://jira.company.com`) |
| `JIRA_USERNAME` | Your Jira username |
| `JIRA_TOKEN` | Personal Access Token (PAT) |
| `JIRA_VERIFY_SSL` | Verify SSL certs (default: `true`) |

### Available Tools (Read-Only)

| Tool | Description |
|------|-------------|
| `search_issues` | Search issues with JQL |
| `get_issue` | Get issue details by key |
| `get_issue_comments` | Get comments on an issue |
| `list_projects` | List accessible projects |

### Example Usage

```python
# Search for recent incidents
result = await jira.search_issues(
    jql="project = INC AND created >= -7d ORDER BY created DESC",
    max_results=10
)

# Get specific issue
issue = await jira.get_issue("INC-123")

# Get comments
comments = await jira.get_issue_comments("INC-123")
```

## Confluence Data Center

### Configuration

| Variable | Description |
|----------|-------------|
| `CONFLUENCE_URL` | Confluence server URL |
| `CONFLUENCE_USERNAME` | Your Confluence username |
| `CONFLUENCE_TOKEN` | Personal Access Token |
| `CONFLUENCE_VERIFY_SSL` | Verify SSL certs (default: `true`) |

### Available Tools (Read-Only)

| Tool | Description |
|------|-------------|
| `search_pages` | Search pages by text/CQL |
| `get_page` | Get page content by ID |
| `get_page_by_title` | Get page by space and title |
| `list_spaces` | List accessible spaces |

### Example Usage

```python
# Search runbooks
results = await confluence.search_pages(
    query="database troubleshooting",
    space_key="OPS"
)

# Get page content
page = await confluence.get_page(page_id="12345")
```

## GitLab (Self-Hosted)

### Configuration

| Variable | Description |
|----------|-------------|
| `GITLAB_URL` | GitLab server URL (e.g., `https://gitlab.company.com`) |
| `GITLAB_TOKEN` | Personal Access Token with `read_api` scope |
| `GITLAB_VERIFY_SSL` | Verify SSL certs (default: `true`) |

### Available Tools (Read-Only)

| Tool | Description |
|------|-------------|
| `list_projects` | List accessible projects |
| `get_project` | Get project details |
| `list_merge_requests` | List MRs for a project |
| `get_merge_request` | Get MR details |
| `list_pipelines` | List pipelines for a project |
| `get_file_content` | Get file content from repo |

### Example Usage

```python
# List recent MRs
mrs = await gitlab.list_merge_requests(
    project_id=123,
    state="merged",
    per_page=10
)

# Get file content
content = await gitlab.get_file_content(
    project_id=123,
    file_path="README.md",
    ref="main"
)
```

## Security Notes

1. **Read-Only**: All servers are intentionally read-only
2. **Tokens**: Use Personal Access Tokens, not passwords
3. **Minimum Scope**: Use tokens with minimum required permissions
4. **SSL**: Keep `VERIFY_SSL=true` in production
5. **Network**: Run MCP servers in same network as target systems

## Adding New MCP Servers

To add a new MCP server:

1. Create directory: `src/mcp_servers/yourservice/`
2. Create `server.py` with MCP tools
3. Create `__init__.py` with exports
4. Add to `pyproject.toml` dependencies
5. Add to `docker-compose.yml` and Helm chart

See existing servers for implementation patterns.
