"""
Jira Data Center MCP Server (Read-Only)
=======================================

MCP server providing read-only access to Jira Data Center.

This server is designed for Jira Data Center (on-premise), NOT Jira Cloud.
For Jira Cloud, the API endpoints and authentication may differ.

Configuration:
    JIRA_URL: Jira server URL (e.g., https://jira.company.com)
    JIRA_USERNAME: Your Jira username
    JIRA_TOKEN: Personal Access Token (PAT)
    JIRA_VERIFY_SSL: Verify SSL certificates (default: true)

Usage:
    # Run as stdio server (for local development)
    python -m mcp_servers.jira.server
    
    # The server reads MCP requests from stdin and writes responses to stdout

Available Tools (all read-only):
    - search_issues: Search issues using JQL
    - get_issue: Get issue details by key
    - get_issue_comments: Get comments on an issue
    - list_projects: List accessible projects

Security:
    - All operations are READ-ONLY
    - No create, update, or delete operations
    - Uses Personal Access Token authentication
"""

import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

# MCP SDK imports
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    print("ERROR: mcp package not installed. Install with: pip install mcp", file=sys.stderr)
    sys.exit(1)

# Atlassian API client
try:
    from atlassian import Jira
except ImportError:
    print("ERROR: atlassian-python-api not installed. Install with: pip install atlassian-python-api", file=sys.stderr)
    sys.exit(1)


# Set up logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


# =============================================================================
# JIRA CLIENT
# =============================================================================

def create_jira_client() -> Jira:
    """
    Create a Jira client from environment variables.
    
    Required environment variables:
        JIRA_URL: Jira server URL
        JIRA_USERNAME: Your username
        JIRA_TOKEN: Personal Access Token
    
    Optional:
        JIRA_VERIFY_SSL: Set to 'false' for self-signed certs
    
    Returns:
        Configured Jira client
    """
    url = os.getenv("JIRA_URL")
    username = os.getenv("JIRA_USERNAME")
    token = os.getenv("JIRA_TOKEN")
    verify_ssl = os.getenv("JIRA_VERIFY_SSL", "true").lower() != "false"
    
    if not url:
        raise ValueError("JIRA_URL environment variable is required")
    if not username:
        raise ValueError("JIRA_USERNAME environment variable is required")
    if not token:
        raise ValueError("JIRA_TOKEN environment variable is required")
    
    logger.info(f"Connecting to Jira: {url}")
    
    # Create Jira client for Data Center
    # Uses Personal Access Token authentication
    return Jira(
        url=url,
        username=username,
        password=token,  # PAT is used as password
        verify_ssl=verify_ssl,
    )


# Global client instance (lazy initialized)
_jira_client: Optional[Jira] = None


def get_jira() -> Jira:
    """Get or create the Jira client."""
    global _jira_client
    if _jira_client is None:
        _jira_client = create_jira_client()
    return _jira_client


# =============================================================================
# MCP TOOL IMPLEMENTATIONS (READ-ONLY)
# =============================================================================

async def search_issues(
    jql: str,
    max_results: int = 50,
    fields: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Search for issues using JQL (Jira Query Language).
    
    READ-ONLY operation.
    
    Args:
        jql: JQL query string (e.g., "project = INC AND status = Open")
        max_results: Maximum number of results (default: 50, max: 100)
        fields: List of fields to return (default: key, summary, status, priority)
    
    Returns:
        Dict with 'issues' list and 'total' count
    
    Example JQL queries:
        - "project = INC ORDER BY created DESC"
        - "assignee = currentUser() AND status != Done"
        - "labels = incident AND created >= -7d"
    """
    jira = get_jira()
    
    # Limit max results for safety
    max_results = min(max_results, 100)
    
    # Default fields if not specified
    if not fields:
        fields = ["key", "summary", "status", "priority", "assignee", "created", "updated"]
    
    logger.info(f"Searching issues: {jql[:100]}...")
    
    try:
        # Use JQL search
        results = jira.jql(jql, limit=max_results, fields=fields)
        
        issues = []
        for issue in results.get("issues", []):
            issue_data = {
                "key": issue.get("key"),
                "self": issue.get("self"),
            }
            
            # Extract fields
            fields_data = issue.get("fields", {})
            for field in fields:
                if field in fields_data:
                    value = fields_data[field]
                    # Handle nested objects (status, priority, assignee)
                    if isinstance(value, dict):
                        if "name" in value:
                            value = value["name"]
                        elif "displayName" in value:
                            value = value["displayName"]
                    issue_data[field] = value
            
            issues.append(issue_data)
        
        return {
            "issues": issues,
            "total": results.get("total", len(issues)),
            "max_results": max_results,
        }
        
    except Exception as e:
        logger.error(f"Search failed: {e}")
        return {"error": str(e), "issues": [], "total": 0}


async def get_issue(issue_key: str) -> Dict[str, Any]:
    """
    Get detailed information about a specific issue.
    
    READ-ONLY operation.
    
    Args:
        issue_key: Issue key (e.g., "INC-123", "PROJ-456")
    
    Returns:
        Dict with issue details including all fields
    """
    jira = get_jira()
    
    logger.info(f"Getting issue: {issue_key}")
    
    try:
        issue = jira.issue(issue_key)
        
        fields = issue.get("fields", {})
        
        return {
            "key": issue.get("key"),
            "id": issue.get("id"),
            "self": issue.get("self"),
            "summary": fields.get("summary"),
            "description": fields.get("description"),
            "status": fields.get("status", {}).get("name"),
            "priority": fields.get("priority", {}).get("name") if fields.get("priority") else None,
            "assignee": fields.get("assignee", {}).get("displayName") if fields.get("assignee") else None,
            "reporter": fields.get("reporter", {}).get("displayName") if fields.get("reporter") else None,
            "created": fields.get("created"),
            "updated": fields.get("updated"),
            "resolved": fields.get("resolutiondate"),
            "labels": fields.get("labels", []),
            "components": [c.get("name") for c in fields.get("components", [])],
            "issue_type": fields.get("issuetype", {}).get("name"),
            "project": fields.get("project", {}).get("key"),
        }
        
    except Exception as e:
        logger.error(f"Get issue failed: {e}")
        return {"error": str(e), "key": issue_key}


async def get_issue_comments(
    issue_key: str,
    max_results: int = 50,
) -> Dict[str, Any]:
    """
    Get comments on an issue.
    
    READ-ONLY operation.
    
    Args:
        issue_key: Issue key (e.g., "INC-123")
        max_results: Maximum comments to return
    
    Returns:
        Dict with 'comments' list
    """
    jira = get_jira()
    
    logger.info(f"Getting comments for: {issue_key}")
    
    try:
        comments_data = jira.issue_get_comments(issue_key)
        
        comments = []
        for comment in comments_data.get("comments", [])[:max_results]:
            comments.append({
                "id": comment.get("id"),
                "author": comment.get("author", {}).get("displayName"),
                "body": comment.get("body"),
                "created": comment.get("created"),
                "updated": comment.get("updated"),
            })
        
        return {
            "issue_key": issue_key,
            "comments": comments,
            "total": comments_data.get("total", len(comments)),
        }
        
    except Exception as e:
        logger.error(f"Get comments failed: {e}")
        return {"error": str(e), "issue_key": issue_key, "comments": []}


async def list_projects(max_results: int = 50) -> Dict[str, Any]:
    """
    List accessible Jira projects.
    
    READ-ONLY operation.
    
    Args:
        max_results: Maximum projects to return
    
    Returns:
        Dict with 'projects' list
    """
    jira = get_jira()
    
    logger.info("Listing projects")
    
    try:
        projects_data = jira.projects()
        
        projects = []
        for project in projects_data[:max_results]:
            projects.append({
                "key": project.get("key"),
                "name": project.get("name"),
                "id": project.get("id"),
                "project_type": project.get("projectTypeKey"),
            })
        
        return {
            "projects": projects,
            "total": len(projects_data),
        }
        
    except Exception as e:
        logger.error(f"List projects failed: {e}")
        return {"error": str(e), "projects": []}


# =============================================================================
# MCP SERVER SETUP
# =============================================================================

# Create MCP server
server = Server("jira-mcp-server")


@server.list_tools()
async def list_tools() -> List[Tool]:
    """List available tools."""
    return [
        Tool(
            name="search_issues",
            description="Search for Jira issues using JQL. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "jql": {
                        "type": "string",
                        "description": "JQL query string",
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum results (default: 50, max: 100)",
                        "default": 50,
                    },
                },
                "required": ["jql"],
            },
        ),
        Tool(
            name="get_issue",
            description="Get detailed information about a Jira issue. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "issue_key": {
                        "type": "string",
                        "description": "Issue key (e.g., INC-123)",
                    },
                },
                "required": ["issue_key"],
            },
        ),
        Tool(
            name="get_issue_comments",
            description="Get comments on a Jira issue. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "issue_key": {
                        "type": "string",
                        "description": "Issue key (e.g., INC-123)",
                    },
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum comments to return",
                        "default": 50,
                    },
                },
                "required": ["issue_key"],
            },
        ),
        Tool(
            name="list_projects",
            description="List accessible Jira projects. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "max_results": {
                        "type": "integer",
                        "description": "Maximum projects to return",
                        "default": 50,
                    },
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Handle tool calls."""
    try:
        if name == "search_issues":
            result = await search_issues(
                jql=arguments["jql"],
                max_results=arguments.get("max_results", 50),
            )
        elif name == "get_issue":
            result = await get_issue(issue_key=arguments["issue_key"])
        elif name == "get_issue_comments":
            result = await get_issue_comments(
                issue_key=arguments["issue_key"],
                max_results=arguments.get("max_results", 50),
            )
        elif name == "list_projects":
            result = await list_projects(
                max_results=arguments.get("max_results", 50),
            )
        else:
            result = {"error": f"Unknown tool: {name}"}
        
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
        
    except Exception as e:
        logger.error(f"Tool {name} failed: {e}")
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

async def main():
    """Run the MCP server in stdio mode."""
    logger.info("Starting Jira MCP Server (READ-ONLY)")
    logger.info(f"Jira URL: {os.getenv('JIRA_URL', 'not set')}")
    
    # Validate configuration
    try:
        get_jira()
        logger.info("Jira connection successful")
    except Exception as e:
        logger.error(f"Jira connection failed: {e}")
        sys.exit(1)
    
    # Run stdio server
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main_sync():
    """
    Entry point that supports both stdio and Unix socket modes.
    
    Usage:
        # Stdio mode (local development)
        mcp-jira
        
        # Socket mode (Kubernetes sidecar)
        mcp-jira --socket /sockets/jira.sock
    """
    from mcp_servers.socket_bridge import run_with_socket
    run_with_socket(server)


if __name__ == "__main__":
    # Check if socket mode is requested
    if "--socket" in sys.argv or os.getenv("MCP_SOCKET"):
        main_sync()
    else:
        asyncio.run(main())
