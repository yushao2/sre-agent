"""
Jira Data Center MCP Server (Read-Only)
=======================================

Provides read-only access to Jira Data Center.

Usage:
    python -m mcp_servers.jira.server
"""

from .server import server, search_issues, get_issue, get_issue_comments, list_projects

__all__ = ["server", "search_issues", "get_issue", "get_issue_comments", "list_projects"]
