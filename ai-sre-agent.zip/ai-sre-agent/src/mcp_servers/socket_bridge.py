"""
MCP Socket Bridge
=================

Bridges MCP stdio protocol to Unix sockets for Kubernetes sidecar deployment.

This module provides:
- UnixSocketMCPServer: Wraps an MCP server to listen on a Unix socket
- Automatic cleanup of socket files
- Graceful shutdown handling

Architecture:
    ┌─────────────────┐
    │  MCP Server     │
    │  (stdio-based)  │
    └────────┬────────┘
             │ stdin/stdout
             ▼
    ┌─────────────────┐
    │  Socket Bridge  │
    │                 │
    └────────┬────────┘
             │ Unix Socket
             ▼
    ┌─────────────────┐
    │  Agent Client   │
    └─────────────────┘

Usage:
    # In MCP server (e.g., jira/server.py)
    from mcp_servers.socket_bridge import run_with_socket
    
    if __name__ == "__main__":
        # Checks for --socket argument or MCP_SOCKET env var
        run_with_socket(server)

The bridge:
1. Creates a Unix socket at the specified path
2. Accepts connections (one at a time for MCP's stateful protocol)
3. Bridges socket I/O to MCP server's stdin/stdout handlers
4. Handles reconnection and cleanup
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class UnixSocketMCPServer:
    """
    Wraps an MCP server to communicate over a Unix socket instead of stdio.
    
    This enables MCP servers to run as Kubernetes sidecars while maintaining
    the stdio protocol that MCP expects.
    
    Attributes:
        socket_path: Path to the Unix socket file
        server: The MCP Server instance
    """
    
    def __init__(
        self,
        server,  # mcp.server.Server instance
        socket_path: str,
    ):
        """
        Initialize the socket bridge.
        
        Args:
            server: MCP Server instance
            socket_path: Path where the Unix socket will be created
        """
        self.server = server
        self.socket_path = Path(socket_path)
        self._unix_server: Optional[asyncio.AbstractServer] = None
        self._shutdown_event = asyncio.Event()
        
    async def start(self):
        """
        Start the Unix socket server.
        
        Creates the socket file and begins accepting connections.
        Only one connection is handled at a time (MCP is stateful).
        """
        # Clean up any existing socket file
        if self.socket_path.exists():
            self.socket_path.unlink()
        
        # Ensure parent directory exists
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Starting MCP server on Unix socket: {self.socket_path}")
        
        # Create Unix socket server
        self._unix_server = await asyncio.start_unix_server(
            self._handle_connection,
            path=str(self.socket_path),
        )
        
        # Set socket permissions (readable/writable by owner and group)
        os.chmod(self.socket_path, 0o660)
        
        logger.info(f"MCP server listening on {self.socket_path}")
        
        # Wait for shutdown
        await self._shutdown_event.wait()
    
    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ):
        """
        Handle an incoming connection.
        
        Bridges the socket streams to the MCP server's protocol handlers.
        """
        peer = writer.get_extra_info("peername") or "unknown"
        logger.info(f"New connection from {peer}")
        
        try:
            # Create stream adapters that match what MCP expects
            read_stream = SocketReadStream(reader)
            write_stream = SocketWriteStream(writer)
            
            # Run the MCP server with these streams
            init_options = self.server.create_initialization_options()
            await self.server.run(read_stream, write_stream, init_options)
            
        except asyncio.CancelledError:
            logger.info(f"Connection from {peer} cancelled")
        except Exception as e:
            logger.error(f"Error handling connection from {peer}: {e}")
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            logger.info(f"Connection from {peer} closed")
    
    async def stop(self):
        """Stop the server and clean up."""
        logger.info("Stopping MCP server...")
        
        self._shutdown_event.set()
        
        if self._unix_server:
            self._unix_server.close()
            await self._unix_server.wait_closed()
        
        # Clean up socket file
        if self.socket_path.exists():
            self.socket_path.unlink()
        
        logger.info("MCP server stopped")


class SocketReadStream:
    """
    Adapts asyncio.StreamReader to MCP's expected read stream interface.
    
    MCP expects a stream with recv() method that returns bytes.
    """
    
    def __init__(self, reader: asyncio.StreamReader):
        self._reader = reader
    
    async def recv(self) -> bytes:
        """Read a chunk of data from the socket."""
        try:
            # Read up to 64KB at a time
            data = await self._reader.read(65536)
            if not data:
                raise EOFError("Connection closed")
            return data
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.debug(f"Read error: {e}")
            raise


class SocketWriteStream:
    """
    Adapts asyncio.StreamWriter to MCP's expected write stream interface.
    
    MCP expects a stream with send() method that accepts bytes.
    """
    
    def __init__(self, writer: asyncio.StreamWriter):
        self._writer = writer
    
    async def send(self, data: bytes):
        """Write data to the socket."""
        try:
            self._writer.write(data)
            await self._writer.drain()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.debug(f"Write error: {e}")
            raise


def get_socket_path_from_args() -> Optional[str]:
    """
    Get socket path from command line arguments or environment.
    
    Checks:
    1. --socket <path> argument
    2. MCP_SOCKET environment variable
    
    Returns:
        Socket path if specified, None for stdio mode
    """
    # Check command line args
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--socket" and i + 1 < len(args):
            return args[i + 1]
        if arg.startswith("--socket="):
            return arg.split("=", 1)[1]
    
    # Check environment
    return os.getenv("MCP_SOCKET")


async def run_server_with_socket(server, socket_path: str):
    """
    Run an MCP server on a Unix socket with signal handling.
    
    Args:
        server: MCP Server instance
        socket_path: Path for the Unix socket
    """
    socket_server = UnixSocketMCPServer(server, socket_path)
    
    # Set up signal handlers
    loop = asyncio.get_event_loop()
    
    def handle_signal():
        logger.info("Received shutdown signal")
        asyncio.create_task(socket_server.stop())
    
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, handle_signal)
    
    try:
        await socket_server.start()
    finally:
        # Remove signal handlers
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.remove_signal_handler(sig)


def run_with_socket(server):
    """
    Main entry point for MCP servers that support both stdio and socket modes.
    
    Automatically detects mode based on --socket argument or MCP_SOCKET env var.
    
    Usage in MCP server:
        from mcp_servers.socket_bridge import run_with_socket
        
        if __name__ == "__main__":
            run_with_socket(server)
    
    Args:
        server: MCP Server instance
    """
    socket_path = get_socket_path_from_args()
    
    if socket_path:
        # Socket mode for Kubernetes
        logger.info(f"Running in socket mode: {socket_path}")
        asyncio.run(run_server_with_socket(server, socket_path))
    else:
        # Stdio mode for local development
        logger.info("Running in stdio mode")
        from mcp.server.stdio import stdio_server
        
        async def run_stdio():
            async with stdio_server() as (read_stream, write_stream):
                init_options = server.create_initialization_options()
                await server.run(read_stream, write_stream, init_options)
        
        asyncio.run(run_stdio())
