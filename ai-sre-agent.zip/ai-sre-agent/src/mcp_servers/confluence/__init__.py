"""
Confluence Data Center MCP Server (Read-Only)
"""
from .server import server, search_pages, get_page, get_page_by_title, list_spaces

__all__ = ["server", "search_pages", "get_page", "get_page_by_title", "list_spaces"]
