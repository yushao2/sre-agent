"""
Confluence Data Center MCP Server (Read-Only)
=============================================

MCP server providing read-only access to Confluence Data Center.

Configuration:
    CONFLUENCE_URL: Confluence server URL
    CONFLUENCE_USERNAME: Your username
    CONFLUENCE_TOKEN: Personal Access Token
    CONFLUENCE_VERIFY_SSL: Verify SSL certs (default: true)

Usage:
    python -m mcp_servers.confluence.server

Available Tools (all read-only):
    - search_pages: Search pages by text or CQL
    - get_page: Get page content by ID
    - get_page_by_title: Get page by space and title
    - list_spaces: List accessible spaces
"""

import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    print("ERROR: mcp package not installed", file=sys.stderr)
    sys.exit(1)

try:
    from atlassian import Confluence
except ImportError:
    print("ERROR: atlassian-python-api not installed", file=sys.stderr)
    sys.exit(1)


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


# =============================================================================
# CONFLUENCE CLIENT
# =============================================================================

def create_confluence_client() -> Confluence:
    """Create Confluence client from environment."""
    url = os.getenv("CONFLUENCE_URL")
    username = os.getenv("CONFLUENCE_USERNAME")
    token = os.getenv("CONFLUENCE_TOKEN")
    verify_ssl = os.getenv("CONFLUENCE_VERIFY_SSL", "true").lower() != "false"
    
    if not url:
        raise ValueError("CONFLUENCE_URL is required")
    if not username:
        raise ValueError("CONFLUENCE_USERNAME is required")
    if not token:
        raise ValueError("CONFLUENCE_TOKEN is required")
    
    logger.info(f"Connecting to Confluence: {url}")
    
    return Confluence(
        url=url,
        username=username,
        password=token,
        verify_ssl=verify_ssl,
    )


_confluence_client: Optional[Confluence] = None


def get_confluence() -> Confluence:
    """Get or create Confluence client."""
    global _confluence_client
    if _confluence_client is None:
        _confluence_client = create_confluence_client()
    return _confluence_client


# =============================================================================
# TOOL IMPLEMENTATIONS (READ-ONLY)
# =============================================================================

async def search_pages(
    query: str,
    space_key: Optional[str] = None,
    max_results: int = 25,
) -> Dict[str, Any]:
    """
    Search for Confluence pages.
    
    READ-ONLY operation.
    
    Args:
        query: Search text or CQL query
        space_key: Limit to specific space (optional)
        max_results: Maximum results (default: 25, max: 100)
    """
    confluence = get_confluence()
    max_results = min(max_results, 100)
    
    logger.info(f"Searching pages: {query[:50]}...")
    
    try:
        # Build CQL query
        cql = f'text ~ "{query}"'
        if space_key:
            cql = f'space = "{space_key}" AND {cql}'
        
        results = confluence.cql(cql, limit=max_results)
        
        pages = []
        for result in results.get("results", []):
            content = result.get("content", result)
            pages.append({
                "id": content.get("id"),
                "title": content.get("title"),
                "type": content.get("type"),
                "space_key": content.get("space", {}).get("key"),
                "url": content.get("_links", {}).get("webui"),
            })
        
        return {
            "pages": pages,
            "total": results.get("totalSize", len(pages)),
        }
        
    except Exception as e:
        logger.error(f"Search failed: {e}")
        return {"error": str(e), "pages": []}


async def get_page(page_id: str, expand: str = "body.storage") -> Dict[str, Any]:
    """
    Get a Confluence page by ID.
    
    READ-ONLY operation.
    
    Args:
        page_id: Page ID
        expand: Fields to expand (default: body.storage)
    """
    confluence = get_confluence()
    
    logger.info(f"Getting page: {page_id}")
    
    try:
        page = confluence.get_page_by_id(page_id, expand=expand)
        
        return {
            "id": page.get("id"),
            "title": page.get("title"),
            "type": page.get("type"),
            "space_key": page.get("space", {}).get("key"),
            "version": page.get("version", {}).get("number"),
            "content": page.get("body", {}).get("storage", {}).get("value"),
            "url": page.get("_links", {}).get("webui"),
            "created": page.get("history", {}).get("createdDate"),
            "updated": page.get("version", {}).get("when"),
        }
        
    except Exception as e:
        logger.error(f"Get page failed: {e}")
        return {"error": str(e), "page_id": page_id}


async def get_page_by_title(
    space_key: str,
    title: str,
) -> Dict[str, Any]:
    """
    Get a page by space and title.
    
    READ-ONLY operation.
    
    Args:
        space_key: Space key (e.g., "OPS")
        title: Page title (exact match)
    """
    confluence = get_confluence()
    
    logger.info(f"Getting page: {space_key}/{title}")
    
    try:
        page = confluence.get_page_by_title(space_key, title, expand="body.storage")
        
        if not page:
            return {"error": "Page not found", "space_key": space_key, "title": title}
        
        return {
            "id": page.get("id"),
            "title": page.get("title"),
            "space_key": space_key,
            "content": page.get("body", {}).get("storage", {}).get("value"),
            "version": page.get("version", {}).get("number"),
        }
        
    except Exception as e:
        logger.error(f"Get page by title failed: {e}")
        return {"error": str(e)}


async def list_spaces(max_results: int = 50) -> Dict[str, Any]:
    """
    List accessible Confluence spaces.
    
    READ-ONLY operation.
    """
    confluence = get_confluence()
    
    logger.info("Listing spaces")
    
    try:
        spaces_data = confluence.get_all_spaces(limit=max_results)
        
        spaces = []
        for space in spaces_data.get("results", []):
            spaces.append({
                "key": space.get("key"),
                "name": space.get("name"),
                "type": space.get("type"),
                "url": space.get("_links", {}).get("webui"),
            })
        
        return {"spaces": spaces, "total": len(spaces)}
        
    except Exception as e:
        logger.error(f"List spaces failed: {e}")
        return {"error": str(e), "spaces": []}


# =============================================================================
# MCP SERVER
# =============================================================================

server = Server("confluence-mcp-server")


@server.list_tools()
async def list_tools() -> List[Tool]:
    """List available tools."""
    return [
        Tool(
            name="search_pages",
            description="Search Confluence pages. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "space_key": {"type": "string", "description": "Space key (optional)"},
                    "max_results": {"type": "integer", "default": 25},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_page",
            description="Get Confluence page by ID. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "page_id": {"type": "string", "description": "Page ID"},
                },
                "required": ["page_id"],
            },
        ),
        Tool(
            name="get_page_by_title",
            description="Get Confluence page by space and title. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "space_key": {"type": "string", "description": "Space key"},
                    "title": {"type": "string", "description": "Page title"},
                },
                "required": ["space_key", "title"],
            },
        ),
        Tool(
            name="list_spaces",
            description="List Confluence spaces. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "max_results": {"type": "integer", "default": 50},
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Handle tool calls."""
    try:
        if name == "search_pages":
            result = await search_pages(
                query=arguments["query"],
                space_key=arguments.get("space_key"),
                max_results=arguments.get("max_results", 25),
            )
        elif name == "get_page":
            result = await get_page(page_id=arguments["page_id"])
        elif name == "get_page_by_title":
            result = await get_page_by_title(
                space_key=arguments["space_key"],
                title=arguments["title"],
            )
        elif name == "list_spaces":
            result = await list_spaces(max_results=arguments.get("max_results", 50))
        else:
            result = {"error": f"Unknown tool: {name}"}
        
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
        
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


async def main():
    """Run the MCP server."""
    logger.info("Starting Confluence MCP Server (READ-ONLY)")
    
    try:
        get_confluence()
        logger.info("Confluence connection successful")
    except Exception as e:
        logger.error(f"Confluence connection failed: {e}")
        sys.exit(1)
    
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
