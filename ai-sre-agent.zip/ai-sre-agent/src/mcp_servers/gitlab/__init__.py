"""
GitLab Self-Hosted MCP Server (Read-Only)
"""
from .server import (
    server,
    list_projects,
    get_project,
    list_merge_requests,
    get_merge_request,
    list_pipelines,
    get_file_content,
)

__all__ = [
    "server",
    "list_projects",
    "get_project", 
    "list_merge_requests",
    "get_merge_request",
    "list_pipelines",
    "get_file_content",
]
