"""
GitLab Self-Hosted MCP Server (Read-Only)
=========================================

MCP server providing read-only access to self-hosted GitLab instances.

Configuration:
    GITLAB_URL: GitLab server URL (e.g., https://gitlab.company.com)
    GITLAB_TOKEN: Personal Access Token with read_api scope
    GITLAB_VERIFY_SSL: Verify SSL certs (default: true)

Usage:
    python -m mcp_servers.gitlab.server

Available Tools (all read-only):
    - list_projects: List accessible projects
    - get_project: Get project details
    - list_merge_requests: List MRs for a project
    - get_merge_request: Get MR details with changes
    - list_pipelines: List pipelines for a project
    - get_file_content: Get file content from repository
"""

import asyncio
import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    print("ERROR: mcp package not installed", file=sys.stderr)
    sys.exit(1)

try:
    import gitlab
except ImportError:
    print("ERROR: python-gitlab not installed. Install with: pip install python-gitlab", file=sys.stderr)
    sys.exit(1)


logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)


# =============================================================================
# GITLAB CLIENT
# =============================================================================

def create_gitlab_client() -> gitlab.Gitlab:
    """Create GitLab client from environment."""
    url = os.getenv("GITLAB_URL")
    token = os.getenv("GITLAB_TOKEN")
    verify_ssl = os.getenv("GITLAB_VERIFY_SSL", "true").lower() != "false"
    
    if not url:
        raise ValueError("GITLAB_URL is required")
    if not token:
        raise ValueError("GITLAB_TOKEN is required")
    
    logger.info(f"Connecting to GitLab: {url}")
    
    gl = gitlab.Gitlab(
        url=url,
        private_token=token,
        ssl_verify=verify_ssl,
    )
    
    # Test authentication
    gl.auth()
    
    return gl


_gitlab_client: Optional[gitlab.Gitlab] = None


def get_gitlab() -> gitlab.Gitlab:
    """Get or create GitLab client."""
    global _gitlab_client
    if _gitlab_client is None:
        _gitlab_client = create_gitlab_client()
    return _gitlab_client


# =============================================================================
# TOOL IMPLEMENTATIONS (READ-ONLY)
# =============================================================================

async def list_projects(
    search: Optional[str] = None,
    owned: bool = False,
    membership: bool = True,
    per_page: int = 20,
) -> Dict[str, Any]:
    """
    List GitLab projects.
    
    READ-ONLY operation.
    
    Args:
        search: Search query (optional)
        owned: Only owned projects
        membership: Only projects with membership
        per_page: Results per page (max: 100)
    """
    gl = get_gitlab()
    per_page = min(per_page, 100)
    
    logger.info(f"Listing projects (search={search})")
    
    try:
        kwargs = {
            "per_page": per_page,
            "owned": owned,
            "membership": membership,
        }
        if search:
            kwargs["search"] = search
        
        projects = gl.projects.list(**kwargs)
        
        result = []
        for project in projects:
            result.append({
                "id": project.id,
                "name": project.name,
                "path_with_namespace": project.path_with_namespace,
                "description": project.description,
                "web_url": project.web_url,
                "default_branch": getattr(project, "default_branch", None),
                "visibility": project.visibility,
            })
        
        return {"projects": result, "total": len(result)}
        
    except Exception as e:
        logger.error(f"List projects failed: {e}")
        return {"error": str(e), "projects": []}


async def get_project(project_id: int) -> Dict[str, Any]:
    """
    Get project details.
    
    READ-ONLY operation.
    
    Args:
        project_id: Project ID or path (e.g., 123 or "group/project")
    """
    gl = get_gitlab()
    
    logger.info(f"Getting project: {project_id}")
    
    try:
        project = gl.projects.get(project_id)
        
        return {
            "id": project.id,
            "name": project.name,
            "path_with_namespace": project.path_with_namespace,
            "description": project.description,
            "web_url": project.web_url,
            "default_branch": getattr(project, "default_branch", None),
            "visibility": project.visibility,
            "created_at": project.created_at,
            "last_activity_at": project.last_activity_at,
            "open_issues_count": getattr(project, "open_issues_count", None),
            "topics": getattr(project, "topics", []),
        }
        
    except Exception as e:
        logger.error(f"Get project failed: {e}")
        return {"error": str(e), "project_id": project_id}


async def list_merge_requests(
    project_id: int,
    state: str = "opened",
    per_page: int = 20,
) -> Dict[str, Any]:
    """
    List merge requests for a project.
    
    READ-ONLY operation.
    
    Args:
        project_id: Project ID
        state: MR state (opened, closed, merged, all)
        per_page: Results per page
    """
    gl = get_gitlab()
    per_page = min(per_page, 100)
    
    logger.info(f"Listing MRs for project {project_id} (state={state})")
    
    try:
        project = gl.projects.get(project_id)
        mrs = project.mergerequests.list(state=state, per_page=per_page)
        
        result = []
        for mr in mrs:
            result.append({
                "iid": mr.iid,
                "title": mr.title,
                "state": mr.state,
                "author": mr.author.get("name") if mr.author else None,
                "source_branch": mr.source_branch,
                "target_branch": mr.target_branch,
                "web_url": mr.web_url,
                "created_at": mr.created_at,
                "updated_at": mr.updated_at,
                "merged_at": getattr(mr, "merged_at", None),
            })
        
        return {"merge_requests": result, "total": len(result)}
        
    except Exception as e:
        logger.error(f"List MRs failed: {e}")
        return {"error": str(e), "merge_requests": []}


async def get_merge_request(
    project_id: int,
    mr_iid: int,
) -> Dict[str, Any]:
    """
    Get merge request details including changes.
    
    READ-ONLY operation.
    
    Args:
        project_id: Project ID
        mr_iid: MR internal ID (not global ID)
    """
    gl = get_gitlab()
    
    logger.info(f"Getting MR {mr_iid} from project {project_id}")
    
    try:
        project = gl.projects.get(project_id)
        mr = project.mergerequests.get(mr_iid)
        
        # Get changes (diff)
        changes = mr.changes()
        
        return {
            "iid": mr.iid,
            "title": mr.title,
            "description": mr.description,
            "state": mr.state,
            "author": mr.author.get("name") if mr.author else None,
            "source_branch": mr.source_branch,
            "target_branch": mr.target_branch,
            "web_url": mr.web_url,
            "created_at": mr.created_at,
            "merged_at": getattr(mr, "merged_at", None),
            "changes_count": changes.get("changes_count"),
            "files_changed": [c.get("new_path") for c in changes.get("changes", [])[:20]],
        }
        
    except Exception as e:
        logger.error(f"Get MR failed: {e}")
        return {"error": str(e)}


async def list_pipelines(
    project_id: int,
    status: Optional[str] = None,
    ref: Optional[str] = None,
    per_page: int = 20,
) -> Dict[str, Any]:
    """
    List pipelines for a project.
    
    READ-ONLY operation.
    
    Args:
        project_id: Project ID
        status: Filter by status (running, success, failed, etc.)
        ref: Filter by branch/tag
        per_page: Results per page
    """
    gl = get_gitlab()
    per_page = min(per_page, 100)
    
    logger.info(f"Listing pipelines for project {project_id}")
    
    try:
        project = gl.projects.get(project_id)
        
        kwargs = {"per_page": per_page}
        if status:
            kwargs["status"] = status
        if ref:
            kwargs["ref"] = ref
        
        pipelines = project.pipelines.list(**kwargs)
        
        result = []
        for pipeline in pipelines:
            result.append({
                "id": pipeline.id,
                "status": pipeline.status,
                "ref": pipeline.ref,
                "sha": pipeline.sha[:8],
                "web_url": pipeline.web_url,
                "created_at": pipeline.created_at,
                "updated_at": pipeline.updated_at,
            })
        
        return {"pipelines": result, "total": len(result)}
        
    except Exception as e:
        logger.error(f"List pipelines failed: {e}")
        return {"error": str(e), "pipelines": []}


async def get_file_content(
    project_id: int,
    file_path: str,
    ref: str = "main",
) -> Dict[str, Any]:
    """
    Get file content from repository.
    
    READ-ONLY operation.
    
    Args:
        project_id: Project ID
        file_path: Path to file (e.g., "src/main.py")
        ref: Branch, tag, or commit SHA (default: main)
    """
    gl = get_gitlab()
    
    logger.info(f"Getting file {file_path} from project {project_id}")
    
    try:
        project = gl.projects.get(project_id)
        
        file = project.files.get(file_path=file_path, ref=ref)
        
        # Decode content (base64)
        import base64
        content = base64.b64decode(file.content).decode("utf-8")
        
        return {
            "file_path": file_path,
            "ref": ref,
            "size": file.size,
            "content": content if len(content) < 50000 else content[:50000] + "\n... (truncated)",
        }
        
    except Exception as e:
        logger.error(f"Get file failed: {e}")
        return {"error": str(e), "file_path": file_path}


# =============================================================================
# MCP SERVER
# =============================================================================

server = Server("gitlab-mcp-server")


@server.list_tools()
async def list_tools() -> List[Tool]:
    """List available tools."""
    return [
        Tool(
            name="list_projects",
            description="List GitLab projects. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "search": {"type": "string", "description": "Search query"},
                    "owned": {"type": "boolean", "default": False},
                    "per_page": {"type": "integer", "default": 20},
                },
            },
        ),
        Tool(
            name="get_project",
            description="Get GitLab project details. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "integer", "description": "Project ID"},
                },
                "required": ["project_id"],
            },
        ),
        Tool(
            name="list_merge_requests",
            description="List merge requests. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "integer"},
                    "state": {"type": "string", "default": "opened"},
                    "per_page": {"type": "integer", "default": 20},
                },
                "required": ["project_id"],
            },
        ),
        Tool(
            name="get_merge_request",
            description="Get merge request details. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "integer"},
                    "mr_iid": {"type": "integer", "description": "MR internal ID"},
                },
                "required": ["project_id", "mr_iid"],
            },
        ),
        Tool(
            name="list_pipelines",
            description="List CI/CD pipelines. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "integer"},
                    "status": {"type": "string"},
                    "ref": {"type": "string"},
                    "per_page": {"type": "integer", "default": 20},
                },
                "required": ["project_id"],
            },
        ),
        Tool(
            name="get_file_content",
            description="Get file content from repository. READ-ONLY.",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_id": {"type": "integer"},
                    "file_path": {"type": "string"},
                    "ref": {"type": "string", "default": "main"},
                },
                "required": ["project_id", "file_path"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    """Handle tool calls."""
    try:
        if name == "list_projects":
            result = await list_projects(
                search=arguments.get("search"),
                owned=arguments.get("owned", False),
                per_page=arguments.get("per_page", 20),
            )
        elif name == "get_project":
            result = await get_project(project_id=arguments["project_id"])
        elif name == "list_merge_requests":
            result = await list_merge_requests(
                project_id=arguments["project_id"],
                state=arguments.get("state", "opened"),
                per_page=arguments.get("per_page", 20),
            )
        elif name == "get_merge_request":
            result = await get_merge_request(
                project_id=arguments["project_id"],
                mr_iid=arguments["mr_iid"],
            )
        elif name == "list_pipelines":
            result = await list_pipelines(
                project_id=arguments["project_id"],
                status=arguments.get("status"),
                ref=arguments.get("ref"),
                per_page=arguments.get("per_page", 20),
            )
        elif name == "get_file_content":
            result = await get_file_content(
                project_id=arguments["project_id"],
                file_path=arguments["file_path"],
                ref=arguments.get("ref", "main"),
            )
        else:
            result = {"error": f"Unknown tool: {name}"}
        
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
        
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


async def main():
    """Run the MCP server."""
    logger.info("Starting GitLab MCP Server (READ-ONLY)")
    
    try:
        gl = get_gitlab()
        logger.info(f"GitLab connection successful (user: {gl.user.username})")
    except Exception as e:
        logger.error(f"GitLab connection failed: {e}")
        sys.exit(1)
    
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
