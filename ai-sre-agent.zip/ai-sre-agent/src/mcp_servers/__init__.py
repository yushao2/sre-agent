"""
MCP Servers Package
===================

Model Context Protocol servers for external system integration.

All servers are READ-ONLY by design.

Available servers:
- jira: Jira Data Center integration
- confluence: Confluence Data Center integration  
- gitlab: GitLab (self-hosted) integration
"""

__version__ = "0.3.0"
