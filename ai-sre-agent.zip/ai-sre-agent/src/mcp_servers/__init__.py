"""
MCP Servers Package
===================

Model Context Protocol servers for external system integration.

All servers are READ-ONLY by design.

Available servers:
- jira: Jira Data Center integration
- confluence: Confluence Data Center integration  
- gitlab: GitLab (self-hosted) integration

Transport modes:
- stdio: For local development (default)
- Unix socket: For Kubernetes sidecar pattern

See README.md for architecture details.
"""

__version__ = "0.3.0"

from .socket_bridge import (
    UnixSocketMCPServer,
    run_with_socket,
    get_socket_path_from_args,
)

__all__ = [
    "UnixSocketMCPServer",
    "run_with_socket", 
    "get_socket_path_from_args",
]
